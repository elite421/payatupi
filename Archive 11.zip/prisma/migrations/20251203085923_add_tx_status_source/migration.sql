-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "statusSource" TEXT;
