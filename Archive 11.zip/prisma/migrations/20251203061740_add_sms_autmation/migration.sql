-- AlterTable
ALTER TABLE "CheckoutSettings" ADD COLUMN     "smsAutomation" BOOLEAN NOT NULL DEFAULT false;
