"use client"

import { useEffect, useState } from 'react'
import { usePathname, useRouter } from 'next/navigation'

type Sub = { plan: string; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null }

export default function AccountGate({ children }: { children: React.ReactNode }){
  const pathname = usePathname()
  const router = useRouter()
  const [checked, setChecked] = useState(false)

  useEffect(() => {
    let active = true
    async function run(){
      try {
        const isSubscriptionPage = pathname?.startsWith('/account/subscription')
        const isKycPage = pathname?.startsWith('/account/kyc')
        const isSupportPage = pathname?.startsWith('/account/support')
        const isContactPage = pathname?.startsWith('/account/contact')
        const isProfilePage = pathname?.startsWith('/account/profile')
        // Allow access to subscription, kyc, support, contact and profile unconditionally
        if (isSubscriptionPage || isKycPage || isSupportPage || isContactPage || isProfilePage) { setChecked(true); return }
        const r = await fetch('/api/subscription', { cache: 'no-store' })
        if (r.status === 401) { setChecked(true); return }
        if (!r.ok) { setChecked(true); return }
        const sub: Sub | null = await r.json()
        const end = sub?.currentPeriodEnd ? new Date(sub.currentPeriodEnd) : null
        const paid = !!sub && sub.plan !== 'FREE'
        const isActive = !!(sub && paid && sub.status === 'ACTIVE' && (!end || end.getTime() > Date.now()))
        if (!isActive) router.replace('/account/subscription')
      } catch {}
      if (active) setChecked(true)
    }
    run()
    return () => { active = false }
  }, [pathname, router])

  if (!checked) return null
  return <>{children}</>
}
