"use client"

import { useEffect, useRef } from 'react'
import { signOut, getSession, useSession } from 'next-auth/react'

const IDLE_TIMEOUT_MS = 10 * 60 * 1000 // 10 minutes
const REFRESH_THROTTLE_MS = 60 * 1000 // refresh session at most once a minute on activity

export default function IdleLogout(){
  const { status } = useSession()
  const timerRef = useRef<number | null>(null)
  const lastRefreshRef = useRef<number>(0)

  useEffect(() => {
    if (status !== 'authenticated') return

    const clear = () => {
      if (timerRef.current) {
        window.clearTimeout(timerRef.current)
        timerRef.current = null
      }
    }

    const resetTimer = () => {
      clear()
      timerRef.current = window.setTimeout(async () => {
        try {
          await signOut({ callbackUrl: '/login' })
        } catch {}
      }, IDLE_TIMEOUT_MS)

      const now = Date.now()
      if (now - lastRefreshRef.current > REFRESH_THROTTLE_MS) {
        lastRefreshRef.current = now
        // Refresh the session token (rolling) only on activity
        getSession().catch(() => {})
      }
    }

    const handler = () => {
      if (document.hidden) return
      resetTimer()
    }

    const winEvents: Array<keyof WindowEventMap> = [
      'mousemove',
      'mousedown',
      'keydown',
      'scroll',
      'touchstart',
    ]

    winEvents.forEach((e) => window.addEventListener(e, handler, { passive: true }))
    document.addEventListener('visibilitychange', handler)
    resetTimer()

    return () => {
      winEvents.forEach((e) => window.removeEventListener(e, handler as any))
      document.removeEventListener('visibilitychange', handler)
      clear()
    }
  }, [status])

  return null
}
