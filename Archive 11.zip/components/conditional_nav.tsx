"use client"

import { usePathname } from "next/navigation"
import Navbar from "./Navbaar"
import Footer from "./Footer"

export default function ConditionalLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const isAccountRoute = pathname?.startsWith('/account')
  const isPayRoute = pathname?.startsWith('/pay')
  const hideChrome = isAccountRoute || isPayRoute

  return (
    <>
      {!hideChrome && <Navbar />}
      <div className={`flex flex-col min-h-screen ${hideChrome ? 'w-full' : 'flex-1'}`}>
        <main className="flex-1">
          {children}
        </main>
        {!hideChrome && <Footer />}
      </div>
    </>
  )
}