"use client"

import { useEffect, useMemo, useRef, useState } from 'react'

export default function BillRedirectTimer({ paymentId, seconds = 30 }: { paymentId: string; seconds?: number }){
  const [targetUrl, setTargetUrl] = useState<string | null>(null)
  const [remaining, setRemaining] = useState<number>(seconds)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    try {
      if (typeof window !== 'undefined' && window.sessionStorage) {
        const key = `payatupi:redirect:${paymentId}`
        const v = window.sessionStorage.getItem(key)
        if (v && /^https?:\/\//i.test(v)) setTargetUrl(v)
        try { window.sessionStorage.removeItem(key) } catch {}
      }
    } catch {}
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current as any)
        timerRef.current = null
      }
    }
  }, [paymentId])

  useEffect(() => {
    if (!targetUrl) return
    if (timerRef.current) {
      clearInterval(timerRef.current as any)
      timerRef.current = null
    }
    setRemaining(seconds)
    timerRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          if (timerRef.current) {
            clearInterval(timerRef.current as any)
            timerRef.current = null
          }
          try {
            if (typeof window !== 'undefined') window.location.href = targetUrl
          } catch {}
          return 0
        }
        return r - 1
      })
    }, 1000) as any
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current as any)
        timerRef.current = null
      }
    }
  }, [targetUrl, seconds])

  if (!targetUrl) return null

  return (
    <div className="ml-auto flex items-center gap-2 rounded-lg bg-white/10 px-3 py-1 text-xs">
      <span>Redirecting in</span>
      <span className="font-mono">{remaining}s</span>
      <a
        href={targetUrl}
        className="ml-2 rounded-md bg-white/20 px-2 py-1 hover:bg-white/30"
      >Go now</a>
    </div>
  )
}
