"use client"

import React from 'react'

export default function DownloadQRButton({
  qrUrl,
  publicId,
  paymentId,
  themeColor = '#366870',
}: {
  qrUrl: string
  publicId?: string | null
  paymentId?: string | null
  themeColor?: string
}) {
  async function onClick() {
    const filename = `upi-qr${publicId ? '-' + publicId : ''}${paymentId ? '-' + paymentId : ''}.png`
    try {
      const res = await fetch(qrUrl, { cache: 'no-store' })
      if (!res.ok) throw new Error('fetch_failed')
      const blob = await res.blob()
      const imgUrl = URL.createObjectURL(blob)
      const img = new Image()
      img.src = imgUrl
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve()
        img.onerror = () => reject(new Error('img_load_failed'))
      })

      const pad = 12
      const lines = [
        publicId ? `Public ID: ${publicId}` : null,
        paymentId ? `Payment ID: ${paymentId}` : null,
      ].filter(Boolean) as string[]
      const lineHeight = 20
      const textBoxHeight = lines.length > 0 ? pad + lines.length * lineHeight + pad : 0

      const width = Math.max(img.width, 200)
      const height = img.height + textBoxHeight
      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      const ctx = canvas.getContext('2d')!

      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, 0, width, height)

      const ix = Math.floor((width - img.width) / 2)
      ctx.drawImage(img, ix, 0)

      if (lines.length > 0) {
        ctx.fillStyle = '#111827'
        ctx.font = '14px system-ui, -apple-system, Segoe UI, Roboto, Arial'
        let y = img.height + pad + 14
        for (const line of lines) {
          ctx.fillText(line, pad, y)
          y += lineHeight
        }
      }

      const outBlob: Blob = await new Promise((resolve) => canvas.toBlob((b) => resolve(b || blob), 'image/png'))
      URL.revokeObjectURL(imgUrl)

      const url = URL.createObjectURL(outBlob)
      const a = document.createElement('a')
      a.href = url
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 2000)
    } catch {
      const a = document.createElement('a')
      a.href = qrUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
    }
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex items-center gap-2 px-3 py-2 rounded-md text-white shadow hover:opacity-90"
      style={{ backgroundColor: themeColor }}
    >
      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16" />
      </svg>
    </button>
  )
}
