"use client"

import { SessionProvider } from 'next-auth/react'
import { ToastProvider } from '@/components/Toast'
import IdleLogout from '@/components/IdleLogout'
import LoginToastOnce from '@/components/LoginToastOnce'

export default function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <ToastProvider>
        {children}
        <IdleLogout />
        <LoginToastOnce />
      </ToastProvider>
    </SessionProvider>
  )
}
