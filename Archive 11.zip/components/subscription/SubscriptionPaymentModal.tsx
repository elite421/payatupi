"use client"

import { useMemo, useState, ChangeEvent } from 'react'

export default function SubscriptionPaymentModal({ plan, onClose, onSubmitted }: { plan: 'PRO'|'BUSINESS', onClose: ()=>void, onSubmitted: ()=>void }){
  const [utr, setUtr] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [errUtr, setErrUtr] = useState('')

  const platformUpi = process.env.NEXT_PUBLIC_PLATFORM_UPI_ID || ''
  const platformName = process.env.NEXT_PUBLIC_PLATFORM_NAME || 'Payatme'

  const upiQr = useMemo(() => {
    if (!platformUpi) return ''
    const upi = `upi://pay?pa=${encodeURIComponent(platformUpi)}&pn=${encodeURIComponent(platformName)}&am=${encodeURIComponent(plan === 'PRO' ? '300' : '2250')}&tn=${encodeURIComponent(`SUB-${plan}`)}&cu=INR`
    return `https://quickchart.io/qr?size=160&text=${encodeURIComponent(upi)}`
  }, [platformUpi, platformName, plan])

  function onFileChange(e: ChangeEvent<HTMLInputElement>){
    const f = e.target.files?.[0] || null
    setFile(f)
  }

  async function submit(){
    setErrUtr('')
    setMsg(null)
    const trimmed = utr.trim()
    if (!trimmed || trimmed.length < 6) { setErrUtr('Enter a valid UTR'); return }
    const fd = new FormData()
    fd.append('plan', plan)
    fd.append('utr', trimmed)
    if (file) fd.append('screenshot', file)
    setSubmitting(true)
    try {
      const r = await fetch('/api/subscription/payment', { method: 'POST', body: fd })
      if (r.ok) {
        setMsg('Submitted for verification. Admin will activate once verified.')
        setUtr('')
        setFile(null)
        onSubmitted()
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setMsg(d.error || 'Failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="glass w-full max-w-lg rounded-xl p-6">
        <div className="flex items-center justify-between -mx-6 -mt-6 px-6 py-4 border-b border-[#366870] bg-[#366870] text-white rounded-t-xl">
          <div className="text-lg font-semibold">Pay Subscription ({plan})</div>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/10 text-white">✕</button>
        </div>
        <div className="mt-3 text-sm text-slate-600">
          Pay to platform UPI and submit the UTR/screenshot. Admin will verify and activate your plan.
        </div>
        <div className="mt-4 flex items-center gap-4">
          <div className="rounded-md border p-3">
            {upiQr ? <img src={upiQr} alt="UPI QR" className="h-32 w-32" /> : <div className="text-xs text-slate-600">Configure NEXT_PUBLIC_PLATFORM_UPI_ID</div>}
          </div>
          <div className="text-xs text-slate-600">
            <div>UPI ID: <span className="font-medium">{platformUpi || '—'}</span></div>
            <div>Plan Amount: <span className="font-medium">₹ {plan==='PRO' ? 300 : 2250}</span></div>
          </div>
        </div>
        <div className="mt-4">
          <label className="mb-1 block text-sm text-slate-700">UTR</label>
          <input value={utr} onChange={e=>setUtr(e.target.value)} className="w-full rounded-md border px-3 py-2" placeholder="Enter UTR" />
          {errUtr && <div className="text-xs text-red-600 mt-1">{errUtr}</div>}
        </div>
        <div className="mt-3">
          <label className="mb-1 block text-sm text-slate-700">Screenshot (optional)</label>
          <input type="file" accept="image/*" onChange={onFileChange} className="block w-full text-sm rounded-md border px-3 py-2 bg-white" />
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onClose} className="rounded-md bg-slate-100 px-4 py-2">Cancel</button>
          <button disabled={submitting} onClick={submit} className="rounded-md bg-slate-900 text-white px-4 py-2">{submitting ? 'Submitting...' : 'Submit'}</button>
        </div>
        {msg && <div className="mt-2 text-sm text-slate-600">{msg}</div>}
      </div>
    </div>
  )
}
