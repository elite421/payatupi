import { prisma } from '@/lib/prisma'

export function isValidPublicId(input: string): boolean {
  const s = String(input || '').trim()
  if (!/^[A-Za-z0-9]{1,7}$/.test(s)) return false
  return /[A-Za-z]/.test(s) && /[0-9]/.test(s)
}

function normalize(input: string): string {
  return String(input || '').trim().toUpperCase()
}

function randomMix7(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let out = ''
  let hasAlpha = false
  let hasDigit = false
  for (let i = 0; i < 7; i++) {
    const idx = Math.floor(Math.random() * chars.length)
    const ch = chars[idx]
    if (/[A-Z]/.test(ch)) hasAlpha = true
    if (/[0-9]/.test(ch)) hasDigit = true
    out += ch
  }
  if (!(hasAlpha && hasDigit)) return randomMix7()
  return out
}

export async function generateUniquePublicId(): Promise<string> {
  for (let i = 0; i < 50; i++) {
    const candidate = randomMix7()
    const exists = await (prisma as any).user.findUnique({ where: { publicId: candidate }, select: { id: true } })
    if (!exists) return candidate
  }
  throw new Error('Failed to generate unique publicId')
}

export async function ensureUserPublicId(userId: string): Promise<string> {
  const user = await (prisma as any).user.findUnique({ where: { id: userId }, select: { publicId: true } })
  if (user?.publicId && isValidPublicId(user.publicId)) return normalize(user.publicId)
  const pub = await generateUniquePublicId()
  await (prisma as any).user.update({ where: { id: userId }, data: { publicId: pub } })
  return pub
}

export async function findUserByPublicId(id: string) {
  const pid = normalize(id)
  if (!isValidPublicId(pid)) return null
  return (prisma as any).user.findUnique({ where: { publicId: pid } })
}
