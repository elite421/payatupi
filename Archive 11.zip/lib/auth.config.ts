export const authConfig = {
    session: { strategy: 'jwt' as const, maxAge: 60 * 10, updateAge: 60 },
    pages: {
        signIn: '/login',
    },
    providers: [], // Managed in auth.ts for Node.js environments
    callbacks: {
        async jwt({ token, user }: any) {
            if (user) {
                token.id = (user as any).id
                token.name = user.name
                token.email = user.email
                token.role = (user as any).role
            }
            return token
        },
        async session({ session, token }: any) {
            if (session.user) {
                ; (session.user as any).id = token.id
                session.user.name = token.name
                session.user.email = token.email
                    ; (session.user as any).role = token.role
            }
            return session
        },
    },
    trustHost: true,
    // secret: process.env.NEXTAUTH_SECRET,
    secret: process.env.AUTH_SECRET || process.env.NEXTAUTH_SECRET,
    debug: process.env.NODE_ENV === 'development',
}
