import { isSubscriptionActive } from '@/lib/subscription'
import { isKycApproved } from '@/lib/kyc'

export async function getMerchantEligibility(userId: string): Promise<{
  eligible: boolean,
  subscription: boolean,
  kyc: boolean
}> {
  const [subscription, kyc] = await Promise.all([
    isSubscriptionActive(userId),
    isKycApproved(userId),
  ])

  return {
    eligible: subscription,
    subscription,
    kyc
  }
}
