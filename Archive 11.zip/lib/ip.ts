export function getClientIp(req: Request): string | null {
  try {
    const h = req.headers
    let ip = h.get('cf-connecting-ip') || h.get('x-real-ip') || h.get('x-client-ip') || h.get('x-forwarded-for') || ''
    if (ip.includes(',')) ip = ip.split(',')[0]
    ip = ip.trim()
    if (!ip) return null
    if (ip.includes(':') && ip.includes('.')) ip = ip.split(':')[0]
    return ip
  } catch {
    return null
  }
}
