import { prisma } from '@/lib/prisma'

export async function isSubscriptionActive(userId: string): Promise<boolean> {
  try {
    const sub = await prisma.subscription.findUnique({ where: { userId } })
    if (!sub) return false
    if (sub.plan === 'FREE') return false
    if (sub.status !== 'ACTIVE') return false
    if (sub.currentPeriodEnd && sub.currentPeriodEnd.getTime() <= Date.now()) return false
    return true
  } catch {
    return false
  }
}

export type PlanCode = 'FREE'|'PRO'|'BUSINESS'|'INDIVIDUAL'|'ENTERPRISE'|'INDIVIDUAL_PLUS'|'ENTERPRISE_PLUS'|'TRIAL'

export function planEntitlements(plan: string): { apiAccess: boolean; plugin: boolean; checkoutAds: boolean } {
  const p = String(plan).toUpperCase()
  const enterprise = p === 'ENTERPRISE' || p === 'ENTERPRISE_PLUS' || p === 'BUSINESS'
  const apiAccess = enterprise
  const plugin = enterprise
  const checkoutAds = enterprise
  return { apiAccess, plugin, checkoutAds }
}

export async function hasEntitlement(userId: string, ent: 'apiAccess' | 'plugin' | 'checkoutAds'): Promise<boolean> {
  const sub = await prisma.subscription.findUnique({ where: { userId } })
  if (!sub) return false
  const active = await isSubscriptionActive(userId)
  if (!active) return false
  const entl = planEntitlements((sub as any).plan)
  return !!entl[ent]
}
