/**
 * Shared normalization and parsing utilities for SMS callbacks
 */

const ALLOWED_STATUSES: Array<'Pending' | 'Success' | 'Failed'> = ['Pending', 'Success', 'Failed']

/**
 * Normalize a UTR string by removing spaces/dashes and uppercasing
 */
export function normalizeUtr(s: string): string {
  return String(s || '').replace(/[\s-]+/g, '').toUpperCase()
}

/**
 * Get a value from an object using multiple possible key names (case-insensitive)
 */
export function getAny(o: any, keys: string[]): any {
  if (!o || typeof o !== 'object') return undefined
  const map = new Map<string, any>()
  for (const k of Object.keys(o)) map.set(k.toLowerCase(), (o as any)[k])
  for (const key of keys) {
    const v = map.get(key.toLowerCase())
    if (v !== undefined) return v
  }
  return undefined
}

/**
 * Normalize status string to one of: 'Pending', 'Success', 'Failed', or null
 */
export function normalizeStatus(input: string | undefined | null): 'Pending' | 'Success' | 'Failed' | null {
  const s = String(input || '').trim()
  if (!s) return null
  const l = s.toLowerCase()
  if (
    l === 'success' || l === 'successful' || l === 'ok' || l === 'done' || l === 'paid' ||
    l === 'credit' || l === 'credited' || l === 'receive' || l === 'received' || l === 'approved' ||
    l === '1' || l === 'true' || l === 'y' || l === 'yes'
  ) return 'Success'
  if (
    l === 'failed' || l === 'failure' || l === 'declined' || l === 'rejected' || l === 'error' ||
    l === '0' || l === 'false' || l === 'n' || l === 'no' || l === 'timeout'
  ) return 'Failed'
  if (l === 'pending' || l === 'processing' || l === 'initiated' || l === 'created' || l === 'init' || l === 'wait' || l === 'waiting' || l === 'hold') return 'Pending'
  if (ALLOWED_STATUSES.includes(s as any)) return s as any
  return null
}

/**
 * Extract UTR from text message using common patterns
 */
export function extractUtrFromText(txt: string): string | null {
  const t = String(txt || '').toUpperCase()
  const m1 = t.match(/\b(\d{12,18})\b/)
  if (m1) return normalizeUtr(m1[1])
  const m2 = t.match(/\b([A-Z0-9]{10,20})\b/)
  if (m2 && /[A-Z]/.test(m2[1]) && /\d/.test(m2[1])) return normalizeUtr(m2[1])
  return null
}

/**
 * Extract amount from text message
 */
export function extractAmountFromText(txt: string): number | undefined {
  const t = String(txt || '')
  const m = t.match(/(?:rs|inr|amount|amt)[^\d]{0,5}(\d+(?:\.\d{1,2})?)/i) || t.match(/\b(\d+(?:\.\d{1,2})?)\b\s*(?:rs|inr)\b/i)
  if (m) {
    const n = Number(String(m[1]).replace(/[\,\s]/g, ''))
    if (!Number.isNaN(n)) return Math.round(n)
  }
  return undefined
}

/**
 * Extract status from text message content
 */
export function extractStatusFromText(txt: string): 'Pending' | 'Success' | 'Failed' | null {
  const t = String(txt || '').toLowerCase()
  if (!t) return null
  const hasSuccess = /(success|successful|paid|credit(?:ed)?|receive(?:d)?|approved|completed|done|ok)\b/.test(t)
  const hasFailed = /(failed|failure|declined|rejected|reversal|reversed|chargeback|cancelled|canceled|error|timeout)\b/.test(t)
  const hasPending = /(pending|processing|initiated|created|waiting|wait|on\s+hold|hold|in\s+progress)\b/.test(t)
  if (hasSuccess) return 'Success'
  if (hasFailed) return 'Failed'
  if (hasPending) return 'Pending'
  return null
}
