import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { hasEntitlement } from '@/lib/subscription'

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const allowed = await hasEntitlement(user.id, 'apiAccess')
  if (!allowed) return new Response(JSON.stringify({ error: 'Requires Enterprise plan' }), { status: 403 })
  const { id } = await context.params
  const ip = await prisma.allowedIp.findFirst({ where: { id, userId: user.id } })
  if (!ip) return new Response('Not found', { status: 404 })
  await prisma.allowedIp.delete({ where: { id: ip.id } })
  return new Response(null, { status: 204 })
}
