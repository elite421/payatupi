import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { hasEntitlement } from '@/lib/subscription'

function isValidIp(ip: string): boolean {
  const v4 = /^(25[0-5]|2[0-4]\d|1?\d?\d)(\.(25[0-5]|2[0-4]\d|1?\d?\d)){3}$/
  if (v4.test(ip)) return true
  if (ip.includes(':') && ip.length <= 45) return true
  return false
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const ips = await prisma.allowedIp.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' }, take: 100 })
  return new Response(JSON.stringify(ips), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const allowed = await hasEntitlement(user.id, 'apiAccess')
  if (!allowed) return new Response(JSON.stringify({ error: 'Requires Enterprise plan' }), { status: 403 })
  const body = await req.json().catch(() => ({}))
  const ip = String(body?.ip || '').trim()
  const label = String(body?.label || '').trim() || undefined
  if (!ip || !isValidIp(ip)) return new Response(JSON.stringify({ error: 'invalid_ip' }), { status: 400 })
  try {
    const rec = await prisma.allowedIp.create({ data: { userId: user.id, ip, label } })
    return new Response(JSON.stringify(rec), { status: 201 })
  } catch (e: any) {
    return new Response(JSON.stringify({ error: 'ip_exists' }), { status: 409 })
  }
}
