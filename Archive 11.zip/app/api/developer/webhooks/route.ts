import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { hasEntitlement } from '@/lib/subscription'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const hooks = await prisma.webhook.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' }, take: 50 })
  return new Response(JSON.stringify(hooks), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const allowed = await hasEntitlement(user.id, 'apiAccess')
  if (!allowed) return new Response(JSON.stringify({ error: 'Requires Enterprise plan' }), { status: 403 })
  const body = await req.json().catch(() => ({}))
  const { url, secret } = body || {}
  if (!url) return new Response(JSON.stringify({ error: 'URL required' }), { status: 400 })
  const hook = await prisma.webhook.create({ data: { userId: user.id, url, secret } })
  return new Response(JSON.stringify(hook), { status: 201 })
}
