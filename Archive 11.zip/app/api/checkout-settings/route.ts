import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export const revalidate = 300 // Revalidate every 5 minutes
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })
    const settings = await prisma.checkoutSettings.findUnique({ where: { userId: user.id } })
    return new Response(JSON.stringify(settings), { status: 200 })
  } catch (err) {
    console.error('GET /api/checkout-settings failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })
    const body = await req.json().catch(() => ({}))
    const prev = await prisma.checkoutSettings.findUnique({ where: { userId: user.id } }).catch(() => null)
    const data: any = {}
    const keys = [
      'logoUrl',
      'themeColor',
      'successRedirectUrl',
      'enableTips',
      'enableNotes',
      'currency',
      // New fields
      'enablePurpose',
      'enableName',
      'enablePhone',
      'enableEmail',
      'smsAutomation',
      'checkoutMessage',
      'advertisementImageUrl',
      'advertisementLink',
      // Masked merchant fields
      'maskMerchantName',
      'maskedMerchantName',
    ]
    for (const k of keys) if (body[k] !== undefined) data[k] = body[k]
    const settings = await prisma.checkoutSettings.upsert({
      where: { userId: user.id },
      update: data,
      create: { userId: user.id, ...data },
    })

    const enabledNow = !!data.smsAutomation
    const wasEnabled = !!(prev as any)?.smsAutomation
    if (enabledNow && !wasEnabled) {
      let wallet = await (prisma as any).wallet.findUnique({ where: { userId: user.id } }).catch(() => null)
      if (!wallet) {
        wallet = await (prisma as any).wallet.create({ data: { userId: user.id, balance: 10, trialCredited: true } })
        await (prisma as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: 10, reason: 'Trial credit' } })
      } else if (!wallet.trialCredited) {
        await (prisma as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: 10 }, trialCredited: true } })
        await (prisma as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: 10, reason: 'Trial credit' } })
      }
    }
    return new Response(JSON.stringify(settings), { status: 200 })
  } catch (err) {
    console.error('POST /api/checkout-settings failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
