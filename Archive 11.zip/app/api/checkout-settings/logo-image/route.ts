import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { randomBytes } from 'crypto'
import path from 'path'
import { promises as fs } from 'fs'

function isTooLarge(req: Request, limit = 10 * 1024 * 1024) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  return Number.isFinite(n) && n > limit
}

export async function POST(req: Request) {
  try {
    if (isTooLarge(req)) return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })

    const form = await req.formData().catch(() => null)
    if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
    const file = form.get('file') as File | null
    if (!file) return new Response(JSON.stringify({ error: 'File required' }), { status: 400 })
    if (file.size > 5 * 1024 * 1024) return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })

    const buf = Buffer.from(await file.arrayBuffer())
    const ext = (file.type?.split('/')?.[1] || 'png').toLowerCase()
    const name = `${randomBytes(16).toString('hex')}.${ext}`
    const dir = path.join(process.cwd(), 'public', 'dp')
    const full = path.join(dir, name)
    await fs.mkdir(dir, { recursive: true })
    await fs.writeFile(full, buf)
    const url = `/dp/${name}`

    const settings = await prisma.checkoutSettings.upsert({
      where: { userId: user.id },
      update: { logoUrl: url },
      create: { userId: user.id, logoUrl: url },
    })
    return new Response(JSON.stringify({ url, settings }), { status: 200 })
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
