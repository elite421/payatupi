import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const url = new URL(req.url)
  const take = Math.min(100, Math.max(1, Number(url.searchParams.get('take') || 20)))
  const type = url.searchParams.get('type') || undefined

  const user = await prisma.user.findUnique({ where: { email: session.user.email }, select: { id: true } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const where: any = { userId: user.id }
  if (type) where.type = type as any

  const items = await (prisma as any).activityLog.findMany({ where, orderBy: { createdAt: 'desc' }, take })
  return new Response(JSON.stringify({ items }), { status: 200 })
}
