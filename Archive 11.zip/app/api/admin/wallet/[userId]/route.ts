import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { isValidPublicId, findUserByPublicId } from '@/lib/user-id'

export async function GET(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') {
    return new Response('Unauthorized', { status: 401 })
  }

  try {
    const { userId } = await params
    let user: any = null
    const id = String(userId).trim()
    if (isValidPublicId(id)) {
      user = await findUserByPublicId(id)
    }
    if (!user && id.includes('@')) {
      user = await prisma.user.findUnique({ where: { email: id.toLowerCase() } })
    }
    if (!user) {
      user = await prisma.user.findUnique({ where: { id } })
    }
    if (!user) {
      return new Response(JSON.stringify({ error: 'user_not_found' }), { status: 404 })
    }

    let wallet = await (prisma as any).wallet.findUnique({ where: { userId: user.id } })
    if (!wallet) {
      wallet = await (prisma as any).wallet.create({ data: { userId: user.id, balance: 0 } })
    }

    const entries = await (prisma as any).walletEntry.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    return new Response(JSON.stringify({ wallet, entries, user: { id: user.id, name: user.name, email: user.email, publicId: user.publicId } }), { status: 200 })
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}

