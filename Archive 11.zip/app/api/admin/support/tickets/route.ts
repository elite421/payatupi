import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const url = new URL(req.url)
  const status = url.searchParams.get('status') || undefined

  const where: any = {}
  if (status && (status === 'OPEN' || status === 'CLOSED')) where.status = status

  const tickets = await prisma.supportTicket.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      userId: true,
      subject: true,
      message: true,
      attachmentUrl: true,
      status: true,
      createdAt: true,
      user: { select: { id: true, name: true, email: true } },
    },
  })
  return new Response(JSON.stringify(tickets), { status: 200 })
}
