import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const { id } = await params
  if (!id) return new Response('Missing id', { status: 400 })

  const body = await req.json().catch(() => ({})) as { status?: 'OPEN'|'CLOSED' }
  const status = body?.status
  if (status !== 'OPEN' && status !== 'CLOSED') {
    return new Response(JSON.stringify({ error: 'Invalid status' }), { status: 400 })
  }

  const exists = await prisma.supportTicket.findUnique({ where: { id } })
  if (!exists) return new Response('Not found', { status: 404 })

  const out = await prisma.supportTicket.update({ where: { id }, data: { status } })
  return new Response(JSON.stringify(out), { status: 200 })
}
