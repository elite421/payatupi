import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function PATCH(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const body = await req.json().catch(() => ({})) as any
  const allowedPlans = ['FREE','INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS','TRIAL']
  const allowedStatus = ['ACTIVE','CANCELED','PAST_DUE']
  const data: any = {}
  if (body.plan && allowedPlans.includes(body.plan)) data.plan = body.plan
  if (body.status && allowedStatus.includes(body.status)) data.status = body.status
  if (body.periodEnd) {
    const t = Date.parse(body.periodEnd)
    if (!Number.isNaN(t)) data.currentPeriodEnd = new Date(t)
  }
  // Optional: extendDays to extend from now or existing end
  if (typeof body.extendDays === 'number' && Number.isFinite(body.extendDays)) {
    const now = new Date()
    const sub = await prisma.subscription.findUnique({ where: { userId } })
    const base = sub?.currentPeriodEnd && sub.currentPeriodEnd.getTime() > now.getTime() ? sub.currentPeriodEnd : now
    const extended = new Date(base.getTime() + body.extendDays * 24 * 60 * 60 * 1000)
    data.currentPeriodEnd = extended
    if (!data.status) data.status = 'ACTIVE'
  }
  // If plan provided and period not provided, set sensible defaults
  if (data.plan && data.currentPeriodEnd === undefined) {
    const now = new Date()
    if (data.plan === 'INDIVIDUAL' || data.plan === 'ENTERPRISE') {
      data.currentPeriodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
    } else if (data.plan === 'INDIVIDUAL_PLUS' || data.plan === 'ENTERPRISE_PLUS') {
      data.currentPeriodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
    } else if (data.plan === 'TRIAL') {
      data.currentPeriodEnd = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
    } else if (data.plan === 'FREE') {
      data.currentPeriodEnd = null
    }
  }
  // Ensure paid plans are marked ACTIVE when not explicitly set
  if (data.plan && data.plan !== 'FREE' && data.plan !== 'TRIAL' && !data.status) {
    data.status = 'ACTIVE'
  }
  const sub = await prisma.subscription.upsert({
    where: { userId },
    update: data,
    create: { userId, plan: data.plan || 'FREE', status: data.status || 'ACTIVE', currentPeriodEnd: data.currentPeriodEnd || null },
  })
  return new Response(JSON.stringify(sub), { status: 200 })
}
