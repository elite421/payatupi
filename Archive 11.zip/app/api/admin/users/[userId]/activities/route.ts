import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const url = new URL(req.url)
  const takeRaw = url.searchParams.get('take')
  const take = Math.min(Math.max(parseInt(takeRaw || '50') || 50, 1), 200)
  const logs = await (prisma as any).activityLog.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take,
    select: { id: true, type: true, message: true, metadata: true, createdAt: true },
  })
  return new Response(JSON.stringify(logs), { status: 200 })
}
