import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createActivity } from '@/lib/activity'
import { promises as fs } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

function isTooLarge(req: Request, limit = 10 * 1024 * 1024) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  return Number.isFinite(n) && n > limit
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const kyc = await (prisma as any).kycSubmission.findUnique({ where: { userId: user.id } })
  return new Response(JSON.stringify(kyc || null), { status: 200 })
}

export async function POST(req: Request) {
  if (isTooLarge(req)) return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const form = await req.formData().catch(() => null)
  if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
  const proofType = String(form.get('proofType') || '')
  const doc = form.get('document') as File | null
  const selfie = form.get('selfie') as File | null
  if (doc && doc.size > 5 * 1024 * 1024) return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })
  if (selfie && selfie.size > 5 * 1024 * 1024) return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })

  let documentUrl: string | null = null
  let selfieUrl: string | null = null
  const dir = path.join(process.cwd(), 'public', 'kyc')
  await fs.mkdir(dir, { recursive: true })

  async function saveFile(file: File | null){
    if (!file) return null
    const buf = Buffer.from(await file.arrayBuffer())
    const originalName = (file as any)?.name || ''
    let ext = path.extname(originalName).replace('.', '').toLowerCase()
    if (!ext) {
      ext = (file.type?.split('/')?.[1] || '').toLowerCase()
    }
    if (ext === 'jpeg') ext = 'jpg'
    if (!ext) ext = 'bin'
    const name = `${randomBytes(16).toString('hex')}.${ext}`
    const full = path.join(dir, name)
    await fs.writeFile(full, buf)
    return `/kyc/${name}`
  }

  documentUrl = await saveFile(doc)
  selfieUrl = await saveFile(selfie)

  const kyc = await (prisma as any).kycSubmission.upsert({
    where: { userId: user.id },
    update: { proofType, documentUrl: documentUrl || undefined, selfieUrl: selfieUrl || undefined, status: 'PENDING' },
    create: { userId: user.id, proofType, documentUrl: documentUrl || undefined, selfieUrl: selfieUrl || undefined, status: 'PENDING' },
  })
  await createActivity(user.id, 'KYC_SUBMITTED', 'User submitted KYC', { proofType })
  return new Response(JSON.stringify(kyc), { status: 200 })
}
