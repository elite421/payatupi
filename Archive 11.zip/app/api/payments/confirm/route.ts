import { prisma } from '@/lib/prisma'
import { promises as fs } from 'fs'
import { randomBytes } from 'crypto'
import path from 'path'
import { getMerchantEligibility } from '@/lib/eligibility'
import { createActivity } from '@/lib/activity'
import { normalizeUtr } from '@/lib/normalize'
import { matchCallbackLogToTransaction } from '@/lib/sms-callback-matcher'

function looksLikeCuid(s: string) {
  return typeof s === 'string' && s.length >= 24 && s.startsWith('c')
}

function isTooLarge(req: Request, limit = 10 * 1024 * 1024) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  return Number.isFinite(n) && n > limit
}

async function getLinkByIdOrSlug(idOrSlug: string) {
  if (looksLikeCuid(idOrSlug)) {
    const byId = await prisma.paymentLink.findUnique({
      where: { id: idOrSlug },
      select: { id: true, userId: true, title: true, type: true, active: true, redirectUrl: true },
    }).catch(() => null)
    if (byId && byId.active) return byId
  }
  const bySlug = await prisma.paymentLink.findFirst({
    where: { slug: idOrSlug, active: true },
    select: { id: true, userId: true, title: true, type: true, active: true, redirectUrl: true },
  }).catch(() => null)
  return bySlug
}

export async function POST(req: Request) {
  try {
    if (isTooLarge(req)) {
      return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
    }

    const form = await req.formData().catch(() => null)
    if (!form) {
      return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
    }

    const linkIdOrSlug = String(form.get('link') || '')
    const amountStr = String(form.get('amount') || '')
    const paymentId = String(form.get('paymentId') || '')
    const payMode = String(form.get('payMode') || 'upi')
    const utrRaw = String(form.get('utr') || '')

    const buyerName = String(form.get('buyerName') || '')
    const buyerPhone = String(form.get('buyerPhone') || '')
    const buyerEmail = String(form.get('buyerEmail') || '')
    const purposeIn = String(form.get('purpose') || '')

    const screenshot = form.get('screenshot') as File | null

    if (screenshot && screenshot.size > 5 * 1024 * 1024) {
      return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })
    }

    if (!linkIdOrSlug) {
      return new Response(JSON.stringify({ error: 'Missing link' }), { status: 400 })
    }

    const link = await getLinkByIdOrSlug(linkIdOrSlug)
    if (!link) {
      return new Response(JSON.stringify({ error: 'Invalid link' }), { status: 404 })
    }

    // ------------------------------------
    // 🔥 Eligibility Checker
    // ------------------------------------
    const eligibility = await getMerchantEligibility(link.userId)

    if (!eligibility.subscription) {
      return new Response(JSON.stringify({
        error: 'subscription_inactive',
        message: 'Your subscription plan has expired. Renew to continue accepting payments.'
      }), { status: 403 })
    }

    // ------------------------------------
    // Validate Amount + UTR
    // ------------------------------------
    const amount = Number(amountStr)
    if (!Number.isFinite(amount) || amount <= 0) {
      return new Response(JSON.stringify({ error: 'Invalid amount' }), { status: 400 })
    }

    const utr = normalizeUtr(utrRaw)
    if (!utr || utr.length < 6) {
      return new Response(JSON.stringify({ error: 'Invalid UTR' }), { status: 400 })
    }

    const existing = await prisma.transaction.findFirst({
      where: { userId: link.userId, utr }
    }).catch(() => null)

    if (existing) {
      return new Response(JSON.stringify({ error: 'This UTR has already been submitted' }), { status: 400 })
    }

    // ------------------------------------
    // Save Screenshot if exists
    // ------------------------------------
    let screenshotUrl: string | null = null
    if (screenshot) {
      const buffer = Buffer.from(await screenshot.arrayBuffer())
      const ext = (screenshot.type?.split('/')?.[1] || 'png').toLowerCase()
      const filename = `${randomBytes(16).toString('hex')}.${ext}`
      const dir = path.join(process.cwd(), 'public', 'receipts')
      const full = path.join(dir, filename)

      await fs.mkdir(dir, { recursive: true })
      await fs.writeFile(full, buffer)

      screenshotUrl = `/receipts/${filename}`
    }

    // ------------------------------------
    // Get UPI / Bank account
    // ------------------------------------
    const upiAcc = await prisma.uPIAccount.findFirst({
      where: { userId: link.userId, active: true },
      select: { upiId: true },
      orderBy: { createdAt: 'desc' }
    }).catch(() => null)

    const upiId = (upiAcc as any)?.upiId || null

    const bankAcc = payMode.toLowerCase() === 'bank'
      ? await prisma.bankAccount.findFirst({
          where: { userId: link.userId, active: true },
          select: { accountNumber: true, ifsc: true },
          orderBy: { createdAt: 'desc' }
        }).catch(() => null)
      : null

    // ------------------------------------
    // Redirect URL
    // ------------------------------------
    const cs = await prisma.checkoutSettings.findUnique({
      where: { userId: link.userId },
      select: { successRedirectUrl: true }
    }).catch(() => null)

    const redirectTarget = link.redirectUrl || (cs as any)?.successRedirectUrl || null

    // ------------------------------------
    // Payment Description
    // ------------------------------------
    const rawPurpose = (purposeIn || '').trim()
    const isDefault = String((link as any).type || '').toUpperCase() === 'DEFAULT'
    const prefix = paymentId ? `PID:${paymentId} | ` : ''
    const descCandidateRaw = (isDefault && rawPurpose) ? rawPurpose : (link as any).title
    const desc = (descCandidateRaw || '').replace(/^PID:[^|]+\|\s*/i, '').trim()

    const finalPurpose = `${prefix}${desc.slice(0, 60)}`

    // ------------------------------------
    // Create Transaction
    // ------------------------------------
    const tx = await prisma.transaction.create({
      data: {
        userId: link.userId,
        purpose: finalPurpose,
        amount: Math.round(amount),
        status: 'Pending',
        mode: payMode.toUpperCase(),
        upiId,
        accountNumber: (bankAcc as any)?.accountNumber || undefined,
        ifsc: (bankAcc as any)?.ifsc || undefined,
        utr,
        screenshotUrl: screenshotUrl || undefined,
        buyerName: buyerName || undefined,
        buyerPhone: buyerPhone || undefined,
        buyerEmail: buyerEmail || undefined,
      },
      select: { id: true }
    })

    // ------------------------------------
    // Auto-match UTR using callback logs
    // ------------------------------------
    try {
      const utrNorm = normalizeUtr(utr)
      let log: any = await prisma.smsCallbackLog.findFirst({
        where: { userId: link.userId, utr: utrNorm },
        orderBy: { createdAt: 'desc' }
      }).catch(() => null)

      if (!log) {
        const since = new Date(Date.now() - 72 * 60 * 60 * 1000)

        const candidates = await prisma.smsCallbackLog.findMany({
          where: {
            userId: link.userId,
            amount: Math.round(amount),
            createdAt: { gte: since }
          },
          orderBy: { createdAt: 'desc' },
          take: 3
        }).catch(() => [])

        log = candidates?.[0] || null
      }

      if (log) {
        await matchCallbackLogToTransaction({
          id: log.id,
          userId: log.userId,
          utr: log.utr,
          status: log.status,
          amount: (log as any).amount ?? null,
          createdAt: log.createdAt
        })
      }
    } catch {}

    // ------------------------------------
    // Activity Log
    // ------------------------------------
    await createActivity(
      link.userId,
      'PAYMENT_CREATED',
      'Payment request created',
      { txId: tx.id, amount: Math.round(amount), mode: payMode.toUpperCase() }
    )

    return new Response(
      JSON.stringify({ id: tx.id, screenshotUrl, paymentId, redirectUrl: redirectTarget }),
      { status: 200 }
    )

  } catch (err) {
    console.error('POST /api/payments/confirm failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
