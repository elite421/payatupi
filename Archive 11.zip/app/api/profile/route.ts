import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export const revalidate = 300 // Revalidate every 5 minutes
export const dynamic = 'force-dynamic'
import { ensureUserPublicId } from '@/lib/user-id'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const publicId = await ensureUserPublicId(user.id)
  const data = { id: user.id, publicId, name: user.name, email: user.email, phone: user.phone, createdAt: user.createdAt, emailVerified: user.emailVerified }
  return new Response(JSON.stringify(data), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { name, phone } = body || {}
  if (!name) return new Response(JSON.stringify({ error: 'name required' }), { status: 400 })
  if (!phone) return new Response(JSON.stringify({ error: 'phone required' }), { status: 400 })
  const user = await prisma.user.update({ where: { email: session.user.email }, data: { name, phone } })
  const publicId = await ensureUserPublicId(user.id)
  const data = { id: user.id, publicId, name: user.name, email: user.email, phone: user.phone, createdAt: user.createdAt, emailVerified: user.emailVerified }
  return new Response(JSON.stringify(data), { status: 200 })
}
