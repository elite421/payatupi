import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { promises as fs } from 'fs'
import { randomBytes } from 'crypto'
import path from 'path'
import { normalizeUtr } from '@/lib/normalize'
import { matchCallbackLogToTransaction } from '@/lib/sms-callback-matcher'

function isTooLarge(req: Request, limit = 10 * 1024 * 1024) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  return Number.isFinite(n) && n > limit
}

export async function POST(req: Request) {
  try {
    if (isTooLarge(req)) return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })

    const form = await req.formData().catch(()=>null)
    if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })

    const amountRaw = String(form.get('amount') || '')
    const utrRaw = String(form.get('utr') || '')
    const screenshot = form.get('screenshot') as File | null
    if (screenshot && screenshot.size > 5 * 1024 * 1024) {
      return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })
    }

    let amount = Number(amountRaw)
    if (!Number.isFinite(amount) || amount <= 0) {
      return new Response(JSON.stringify({ error: 'Invalid amount' }), { status: 400 })
    }
    amount = Math.round(amount)

    const utr = normalizeUtr(utrRaw)
    if (!utr || utr.length < 6) return new Response(JSON.stringify({ error: 'Invalid UTR' }), { status: 400 })

    // optional screenshot save
    let screenshotUrl: string | null = null
    if (screenshot) {
      const buf = Buffer.from(await screenshot.arrayBuffer())
      const ext = (screenshot.type?.split('/')?.[1] || 'png').toLowerCase()
      const name = `${randomBytes(16).toString('hex')}.${ext}`
      const dir = path.join(process.cwd(), 'public', 'receipts')
      const full = path.join(dir, name)
      await fs.mkdir(dir, { recursive: true })
      await fs.writeFile(full, buf)
      screenshotUrl = `/receipts/${name}`
    }

    const dup = await prisma.transaction.findFirst({ where: { userId: user.id, utr } }).catch(() => null)
    if (dup) return new Response(JSON.stringify({ error: 'This UTR has already been submitted' }), { status: 400 })

    const tx = await prisma.transaction.create({
      data: {
        userId: user.id,
        purpose: `Wallet Top-up`,
        amount,
        status: 'Pending',
        mode: 'WALLET_TOPUP',
        utr,
        screenshotUrl: screenshotUrl || undefined,
      },
      select: { id: true },
    })

    // Try to auto-match an earlier SMS callback log (message may have arrived before submission)
    try {
      const utrNorm = normalizeUtr(utr)
      let log: any = await prisma.smsCallbackLog.findFirst({
        where: { userId: user.id, utr: utrNorm },
        orderBy: { createdAt: 'desc' },
      }).catch(() => null)

      if (!log) {
        const since = new Date(Date.now() - 72 * 60 * 60 * 1000)
        const candidates = await prisma.smsCallbackLog.findMany({
          where: {
            userId: user.id,
            amount: amount,
            createdAt: { gte: since },
          },
          orderBy: { createdAt: 'desc' },
          take: 3,
        }).catch(() => [])
        log = candidates?.[0] || null
      }

      if (log) {
        await matchCallbackLogToTransaction({
          id: log.id,
          userId: log.userId,
          utr: log.utr,
          status: log.status,
          amount: (log as any).amount ?? null,
          createdAt: log.createdAt,
        })
      }
    } catch {}

    return new Response(JSON.stringify({ id: tx.id }), { status: 200 })
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
