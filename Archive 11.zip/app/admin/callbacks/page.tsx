"use client"

import { useEffect, useState } from 'react'

type LogRow = {
  id: string
  endpoint: string
  method: string
  status: 'OK' | 'ERROR'
  code: number
  reason?: string | null
  metadata?: any
  createdAt: string
  user?: { id: string; name: string; email: string } | null
}

export default function AdminCallbacksPage(){
  const [logs, setLogs] = useState<LogRow[]>([])
  const [loading, setLoading] = useState(false)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState<'all'|'OK'|'ERROR'>('all')
  const [code, setCode] = useState('')
  const [take, setTake] = useState<number>(100)

  async function load(){
    setLoading(true)
    const url = new URL('/api/admin/callback-logs', window.location.origin)
    if (q.trim()) url.searchParams.set('q', q.trim())
    if (status !== 'all') url.searchParams.set('status', status)
    if (code.trim()) url.searchParams.set('code', code.trim())
    url.searchParams.set('take', String(take))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setLogs(await r.json())
  }

  useEffect(() => { 
    const timer = setTimeout(() => load(), 100) // Debounce
    return () => clearTimeout(timer)
  }, [])
  
  useEffect(() => { 
    const timer = setTimeout(() => load(), 300) // Debounce with longer delay for filters
    return () => clearTimeout(timer)
  }, [status, take])

  const okCount = logs.filter(l => l.status === 'OK').length
  const errCount = logs.filter(l => l.status !== 'OK').length

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">SMS Callback Logs</h1>
        <p className="text-slate-600 mt-1">Inspect inbound callback hits from the Android app</p>
      </div>

      <div className="bg-white rounded-xl border p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') load()}} placeholder="Search endpoint/reason/UTR" className="rounded-lg border-slate-300 shadow-sm focus:border-[#366870] focus:ring-[#366870] py-2 px-3" />
          <div className="flex gap-2">
            <select value={status} onChange={e=>setStatus(e.target.value as any)} className="rounded-lg border-slate-300 shadow-sm focus:border-[#366870] focus:ring-[#366870] py-2 px-3">
              <option value="all">All</option>
              <option value="OK">OK</option>
              <option value="ERROR">ERROR</option>
            </select>
            <input value={code} onChange={e=>setCode(e.target.value)} placeholder="HTTP code" className="w-28 rounded-lg border-slate-300 shadow-sm focus:border-[#366870] focus:ring-[#366870] py-2 px-3" />
            <select value={String(take)} onChange={e=>setTake(parseInt(e.target.value)||100)} className="rounded-lg border-slate-300 shadow-sm focus:border-[#366870] focus:ring-[#366870] py-2 px-3">
              <option value="50">50</option>
              <option value="100">100</option>
              <option value="200">200</option>
            </select>
            <button onClick={load} className="px-4 py-2 rounded-lg bg-[#366870] hover:bg-[#2f5b62] text-white">Refresh</button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <div className="p-4 grid grid-cols-2 gap-4 border-b bg-slate-50">
          <div className="text-sm">OK: <span className="font-semibold text-emerald-700">{okCount}</span></div>
          <div className="text-sm">Errors: <span className="font-semibold text-rose-700">{errCount}</span></div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b">
              <tr>
                {['Time','Code','Status','Endpoint','User','Details','Reason'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y">
              {loading ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Loading...</td></tr>
              ) : logs.length === 0 ? (
                <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">No logs</td></tr>
              ) : (
                logs.map(l => (
                  <tr key={l.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 text-sm">{new Date(l.createdAt).toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm">{l.code}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${l.status === 'OK' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>{l.status}</span>
                    </td>
                    <td className="px-4 py-3 text-sm font-mono">{l.method} {l.endpoint}</td>
                    <td className="px-4 py-3 text-sm">{l.user?.name || '—'}<div className="text-xs text-slate-500">{l.user?.email}</div></td>
                    <td className="px-4 py-3 text-xs font-mono whitespace-pre-wrap">{formatMeta(l.metadata)}</td>
                    <td className="px-4 py-3 text-sm">{l.reason || '—'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function formatMeta(meta: any): string {
  if (!meta) return '—'
  try {
    const pick: any = {}
    const keys = ['accountId','utr','status','amount','txId']
    for (const k of keys) if (meta[k] != null) pick[k] = meta[k]
    return JSON.stringify(pick)
  } catch {
    return '—'
  }
}
