"use client"

import { useEffect, useState, FormEvent } from 'react'

type WalletEntry = {
  id: string
  type: 'CREDIT' | 'DEBIT' | 'ADJUST'
  amount: number
  reason: string | null
  createdAt: string
}

type WalletData = {
  wallet: {
    id: string
    balance: number
    userId: string
  }
  entries: WalletEntry[]
  user: {
    id: string
    name: string
    email: string
    publicId: string | null
  }
}

export default function AdminWalletPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedUserId, setSelectedUserId] = useState('')
  const [walletData, setWalletData] = useState<WalletData | null>(null)
  const [loading, setLoading] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [creditAmount, setCreditAmount] = useState('')
  const [debitAmount, setDebitAmount] = useState('')
  const [reason, setReason] = useState('')
  const [processing, setProcessing] = useState(false)

  async function searchUser() {
    if (!searchQuery.trim()) {
      setMsg('Please enter user ID or email')
      return
    }
    setLoading(true)
    setMsg(null)
    try {
      const r = await fetch(`/api/admin/wallet/${encodeURIComponent(searchQuery.trim())}`, { cache: 'no-store' })
      if (r.ok) {
        const data = await r.json()
        setWalletData(data)
        setSelectedUserId(data.user.id)
      } else {
        const err = await r.json()
        setMsg(err.error === 'user_not_found' ? 'User not found' : 'Error loading wallet')
        setWalletData(null)
      }
    } catch (error) {
      setMsg('Error loading wallet')
      setWalletData(null)
    } finally {
      setLoading(false)
    }
  }

  async function handleCredit(e: FormEvent) {
    e.preventDefault()
    if (!selectedUserId || !creditAmount) {
      setMsg('Please enter amount')
      return
    }
    const amount = parseFloat(creditAmount)
    if (isNaN(amount) || amount <= 0) {
      setMsg('Please enter a valid amount')
      return
    }
    setProcessing(true)
    setMsg(null)
    try {
      const r = await fetch('/api/admin/wallet/credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: selectedUserId,
          amount: Math.round(amount),
          reason: reason || 'Admin credit',
        }),
      })
      if (r.ok) {
        setMsg('Amount credited successfully')
        setCreditAmount('')
        setReason('')
        await searchUser() // Reload wallet data
      } else {
        const err = await r.json()
        setMsg(err.error || 'Failed to credit amount')
      }
    } catch (error) {
      setMsg('Error crediting amount')
    } finally {
      setProcessing(false)
    }
  }

  async function handleDebit(e: FormEvent) {
    e.preventDefault()
    if (!selectedUserId || !debitAmount) {
      setMsg('Please enter amount')
      return
    }
    const amount = parseFloat(debitAmount)
    if (isNaN(amount) || amount <= 0) {
      setMsg('Please enter a valid amount')
      return
    }
    if (walletData && walletData.wallet.balance < Math.round(amount)) {
      setMsg('Insufficient wallet balance')
      return
    }
    setProcessing(true)
    setMsg(null)
    try {
      const r = await fetch('/api/admin/wallet/credit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountId: selectedUserId,
          amount: -Math.round(amount), // Negative for debit
          reason: reason || 'Admin debit',
        }),
      })
      if (r.ok) {
        setMsg('Amount debited successfully')
        setDebitAmount('')
        setReason('')
        await searchUser() // Reload wallet data
      } else {
        const err = await r.json()
        setMsg(err.error || 'Failed to debit amount')
      }
    } catch (error) {
      setMsg('Error debiting amount')
    } finally {
      setProcessing(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Wallet Management</h1>
        <p className="mt-1 text-slate-600">View and manage user wallet balances</p>
      </div>

      <div className="glass rounded-xl p-6 space-y-4">
        <div className="font-semibold">Search User</div>
        <div className="flex gap-3">
          <input
            type="text"
            placeholder="Enter User ID, Public ID, or Email"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && searchUser()}
            className="flex-1 rounded-lg border px-4 py-2"
          />
          <button
            onClick={searchUser}
            disabled={loading}
            className="rounded-lg px-6 py-2 text-white disabled:opacity-50"
            style={{ backgroundColor: '#366870' }}
          >
            {loading ? 'Loading...' : 'Search'}
          </button>
        </div>
        {msg && (
          <div className={`text-sm ${msg.includes('successfully') ? 'text-green-600' : 'text-red-600'}`}>
            {msg}
          </div>
        )}
      </div>

      {walletData && (
        <>
          <div className="glass rounded-xl p-6 space-y-4">
            <div className="font-semibold">User Information</div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-sm text-slate-600">Name</div>
                <div className="font-medium">{walletData.user.name}</div>
              </div>
              <div>
                <div className="text-sm text-slate-600">Email</div>
                <div className="font-medium">{walletData.user.email}</div>
              </div>
              <div>
                <div className="text-sm text-slate-600">User ID</div>
                <div className="font-medium text-xs">{walletData.user.id}</div>
              </div>
            </div>
          </div>

          <div className="glass rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Wallet Balance</div>
              <div className="text-3xl font-bold" style={{ color: '#366870' }}>
                ₹{walletData.wallet.balance.toFixed(2)}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass rounded-xl p-6 space-y-4">
              <div className="font-semibold">Credit Money</div>
              <form onSubmit={handleCredit} className="space-y-4">
                <div>
                  <label className="text-sm text-slate-600">Amount (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={creditAmount}
                    onChange={(e) => setCreditAmount(e.target.value)}
                    className="mt-1 w-full rounded-lg border px-4 py-2"
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Reason (optional)</label>
                  <input
                    type="text"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="mt-1 w-full rounded-lg border px-4 py-2"
                    placeholder="Admin credit"
                  />
                </div>
                <button
                  type="submit"
                  disabled={processing}
                  className="w-full rounded-lg px-4 py-2 text-white disabled:opacity-50"
                  style={{ backgroundColor: '#366870' }}
                >
                  {processing ? 'Processing...' : 'Credit Amount'}
                </button>
              </form>
            </div>

            <div className="glass rounded-xl p-6 space-y-4">
              <div className="font-semibold">Debit Money</div>
              <form onSubmit={handleDebit} className="space-y-4">
                <div>
                  <label className="text-sm text-slate-600">Amount (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={debitAmount}
                    onChange={(e) => setDebitAmount(e.target.value)}
                    className="mt-1 w-full rounded-lg border px-4 py-2"
                    placeholder="0.00"
                    required
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-600">Reason (optional)</label>
                  <input
                    type="text"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    className="mt-1 w-full rounded-lg border px-4 py-2"
                    placeholder="Admin debit"
                  />
                </div>
                <button
                  type="submit"
                  disabled={processing}
                  className="w-full rounded-lg px-4 py-2 text-white disabled:opacity-50"
                  style={{ backgroundColor: '#dc2626' }}
                >
                  {processing ? 'Processing...' : 'Debit Amount'}
                </button>
              </form>
            </div>
          </div>

          <div className="glass rounded-xl p-6 space-y-4">
            <div className="font-semibold">Recent Transactions</div>
            {walletData.entries.length === 0 ? (
              <div className="text-sm text-slate-600">No transactions found</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3">Type</th>
                      <th className="text-left py-2 px-3">Amount</th>
                      <th className="text-left py-2 px-3">Reason</th>
                      <th className="text-left py-2 px-3">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {walletData.entries.map((entry) => (
                      <tr key={entry.id} className="border-b">
                        <td className="py-2 px-3">
                          <span
                            className={`px-2 py-1 rounded text-xs font-medium ${
                              entry.type === 'CREDIT'
                                ? 'bg-green-100 text-green-800'
                                : entry.type === 'DEBIT'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {entry.type}
                          </span>
                        </td>
                        <td className="py-2 px-3 font-medium">
                          {entry.type === 'CREDIT' ? '+' : '-'}₹{entry.amount.toFixed(2)}
                        </td>
                        <td className="py-2 px-3 text-slate-600">{entry.reason || '-'}</td>
                        <td className="py-2 px-3 text-slate-600">
                          {new Date(entry.createdAt).toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  )
}

