import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import AdminNav from '@/components/admin/AdminNav'

export const dynamic = "force-dynamic"
export const revalidate = 0

export default async function AdminLayout({ children }: { children: React.ReactNode }){
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email) return redirect('/login')
  if (role !== 'ADMIN') return redirect('/account')
  return (
    <div className="container mx-auto max-w-7xl px-4 py-6">
      <div className="grid gap-6">
        <AdminNav />
        <div className="glass rounded-xl p-6 min-h-[70vh]">
          {children}
        </div>
      </div>
    </div>
  )
}
