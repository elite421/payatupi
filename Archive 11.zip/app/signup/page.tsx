"use client"

import Link from "next/link"
import { FormEvent, useState } from "react"
import { signIn } from "next-auth/react"

export default function Signup(){
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    const form = new FormData(e.currentTarget)
    const name = String(form.get('name') || '')
    const email = String(form.get('email') || '')
    const phone = String(form.get('phone') || '')
    const password = String(form.get('password') || '')

    if (!name || !email || !phone || !password) {
      setError('All fields are required')
      setLoading(false)
      return
    }

    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone, password })
    })

    if (!res.ok) {
      const data = await res.json().catch(() => ({ error: 'Failed to sign up' }))
      setError(data.error || 'Failed to sign up')
      setLoading(false)
      return
    }

    // Auto sign-in then redirect
    const sign = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)
    if (sign?.error) {
      window.location.href = '/login'
    } else {
      window.location.href = '/account'
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4 mt-0">
      <div className="max-w-md w-full bg-white/70 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/40">
        <h1 className="text-4xl font-bold text-center text-gray-900">Create your Payatupi account</h1>
        <p className="mt-2 text-lg text-center text-gray-600">Get started with seamless payments.</p>

        <form method="post" onSubmit={onSubmit} className="mt-8">
          <label className="block mb-2 font-medium text-gray-700" htmlFor="name">Full Name</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#366870] focus:outline-none transition" name="name" type="text" id="name" placeholder="Enter your full name" required />

          <label className="block mb-2 font-medium text-gray-700 mt-4" htmlFor="email">Email</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#366870] focus:outline-none transition" name="email" type="email" id="email" placeholder="Enter your email" required />

          <label className="block mb-2 font-medium text-gray-700 mt-4" htmlFor="phone">Phone</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#366870] focus:outline-none transition" name="phone" type="tel" id="phone" placeholder="Enter your phone number" required />

          <label className="block mb-2 font-medium text-gray-700 mt-4" htmlFor="password">Password</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#366870] focus:outline-none transition" name="password" type="password" id="password" placeholder="Enter your password" required />

          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={loading} className="mt-6 w-full bg-[#366870] text-white p-3 rounded-lg hover:bg-[#2f5b62] transition font-medium shadow-md">
            {loading ? 'Creating account...' : 'Create Account'}
          </button>

          <p className="mt-4 text-center text-gray-700">
            Already have an account?{" "}
            <Link href="/login" className="text-[#366870] font-semibold hover:underline">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  )
}