"use client"

import { useState, ChangeEvent } from 'react'
import { useRouter } from 'next/navigation'

export default function WalletAddMoneyPage(){
  const router = useRouter()
  const [amount, setAmount] = useState('')
  const [utr, setUtr] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)

  const upiId = process.env.NEXT_PUBLIC_PLATFORM_UPI_ID || ''
  const platformName = process.env.NEXT_PUBLIC_PLATFORM_NAME || 'Payatupi'

  const validAmount = Number.isFinite(Number(amount)) && Number(amount) > 0
  const payAmount = validAmount ? Math.round(Number(amount)) : 0
  const upi = validAmount && upiId ? `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(platformName)}&am=${encodeURIComponent(String(payAmount))}&tn=${encodeURIComponent('WALLET-TOPUP')}&cu=INR` : ''
  const upiQr = upi ? `https://quickchart.io/qr?size=200&text=${encodeURIComponent(upi)}` : ''

  function onFileChange(e: ChangeEvent<HTMLInputElement>){
    const f = e.target.files?.[0] || null
    setFile(f)
  }

  async function submit(){
    setMsg(null)
    const a = Math.round(Number(amount))
    if (!Number.isFinite(a) || a <= 0) { setMsg('Enter a valid amount'); return }
    const u = utr.trim()
    if (!u || u.length < 6) { setMsg('Enter a valid UTR'); return }
    const fd = new FormData()
    fd.append('amount', String(a))
    fd.append('utr', u)
    if (file) fd.append('screenshot', file)
    setSubmitting(true)
    try {
      const r = await fetch('/api/wallet/topup', { method: 'POST', body: fd })
      if (r.ok) {
        setMsg('Submitted. It will auto-credit after SMS callback updates the payment to Success.')
        setAmount('')
        setUtr('')
        setFile(null)
        setTimeout(() => router.push('/account/wallet'), 1200)
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setMsg(d.error || 'Failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="max-w-xl mx-auto py-8">
      <h1 className="text-2xl font-semibold">Add Money</h1>
      <div className="mt-6 rounded-xl border bg-white p-6 shadow-sm">
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="mb-1 block text-sm text-slate-700">Amount (₹)</label>
            <input value={amount} onChange={e=>setAmount(e.target.value)} type="number" min={1} className="w-full rounded-md border px-3 py-2" placeholder="Enter amount" />
          </div>
          <div className="text-xs text-slate-600">Scan and pay via UPI</div>
          <div className="flex items-center gap-4">
            <div className="rounded-md border p-3">
              {upiQr ? <img src={upiQr} alt="UPI QR" className="h-40 w-40" /> : <div className="text-xs text-slate-600">Enter a valid amount</div>}
            </div>
            <div className="text-xs text-slate-600">
              <div>UPI ID: <span className="font-medium">{upiId}</span></div>
              <div>{upi ? <a href={upi} className="underline text-blue-600">Open in UPI app</a> : 'Enter amount to enable UPI link'}</div>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-sm text-slate-700">UTR</label>
            <input value={utr} onChange={e=>setUtr(e.target.value)} className="w-full rounded-md border px-3 py-2" placeholder="Enter UTR" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-slate-700">Screenshot (optional)</label>
            <input type="file" accept="image/*" onChange={onFileChange} className="block w-full text-sm rounded-md border px-3 py-2 bg-white" />
          </div>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <button onClick={()=>router.back()} className="rounded-md bg-slate-100 px-4 py-2">Back</button>
          <button disabled={submitting} onClick={submit} className="rounded-md bg-slate-900 text-white px-4 py-2 disabled:opacity-50">{submitting ? 'Submitting...' : 'Submit'}</button>
        </div>
        {msg && <div className="mt-2 text-sm text-slate-600">{msg}</div>}
      </div>
    </div>
  )
}
