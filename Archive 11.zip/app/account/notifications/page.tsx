"use client"

export default function NotificationsPage(){
  const items = [
    {
      icon: 'fab fa-whatsapp',
      title: 'Join WhatsApp Channel',
      desc: 'https://whatsapp.com/channel/0029VbAVha4BVJl9zOrmc20i',
      time: '3 months ago',
      bg: 'bg-emerald-500'
    },
    {
      icon: 'fas fa-tag',
      title: 'Big sale 25% off on One year Subscription 19th and 20th nov',
      time: '2 years ago',
      bg: 'bg-rose-500'
    },
    {
      icon: 'fas fa-sync-alt',
      title: 'System Update Completed',
      time: '1 year ago',
      bg: 'bg-teal-500'
    }
  ]
  return (
    <div className="min-h-screen bg-gray-50/50 p-6">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
        <p className="text-gray-600 mt-1">Your recent updates and announcements</p>

        <div className="mt-6 bg-white rounded-2xl border border-gray-200 shadow-sm divide-y">
          {items.map((n, i) => (
            <div key={i} className="p-4 flex items-start gap-3">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white ${n.bg}`}>
                <i className={n.icon}></i>
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-gray-900">{n.title}</div>
                {n.desc ? (
                  <div className="text-sm text-emerald-600 break-all">{n.desc}</div>
                ) : null}
                <div className="text-xs text-gray-500 mt-1">{n.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
