"use client"

import { useEffect, useMemo, useState, FormEvent } from "react"

type UPI = { id: string; upiId: string; label?: string | null; upiType?: 'MERCHANT'|'NON_MERCHANT'; active: boolean; createdAt?: string }

export default function AddUpiPage(){
  const [items, setItems] = useState<UPI[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [query, setQuery] = useState("")

  async function load() {
    setLoading(true)
    const r = await fetch('/api/upi-accounts')
    setLoading(false)
    if (r.ok) setItems(await r.json())
  }

  useEffect(() => { load() }, [])

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    const fd = new FormData(e.currentTarget)
    const payload: any = {
      upiId: String(fd.get('upiId') || ''),
      label: String(fd.get('label') || ''),
    }
    const upiType = String(fd.get('upiType') || '')
    if (upiType) payload.upiType = upiType
    const res = await fetch('/api/upi-accounts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (res.ok) {
      await load()
      ;(e.target as HTMLFormElement).reset()
    }
  }

  async function remove(id: string) {
    await fetch(`/api/upi-accounts/${id}`, { method: 'DELETE' })
    await load()
  }

  const filtered = useMemo(() => {
    if (!query.trim()) return items
    const q = query.toLowerCase()
    return items.filter(i => i.upiId.toLowerCase().includes(q) || (i.label || '').toLowerCase().includes(q))
  }, [items, query])

  return (
    <div>
      <h1 className="text-2xl font-semibold">Add UPI</h1>
      <p className="mt-2 text-slate-600">Add a new UPI VPA with type for smart routing.</p>

      <form onSubmit={onSubmit} className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 glass rounded-xl p-6">
        <div>
          <label className="text-sm text-slate-700">UPI VPA</label>
          <input name="upiId" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="username@bank" required />
        </div>
        <div>
          <label className="text-sm text-slate-700">UPI Type</label>
          <select name="upiType" className="mt-1 w-full rounded-lg border px-3 py-2">
            <option value="">Select</option>
            <option value="MERCHANT">Merchant</option>
            <option value="NON_MERCHANT">Non Merchant</option>
          </select>
        </div>
        <div>
          <label className="text-sm text-slate-700">Label</label>
          <input name="label" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Primary UPI" />
        </div>
        <div className="md:col-span-3">
          <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Adding...' : 'Proceed'}</button>
        </div>
      </form>

      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Saved UPI</h2>
          <div className="w-full max-w-xs">
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." className="w-full rounded-lg border px-3 py-2" />
          </div>
        </div>
        {loading ? (
          <div className="mt-3 text-sm text-slate-600">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="mt-3 text-sm text-slate-600">No UPI found.</div>
        ) : (
          <div className="mt-4 overflow-x-auto glass rounded-xl p-6">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-600">
                  <th className="py-2 px-3">Timestamp</th>
                  <th className="py-2 px-3">Smart Route ID</th>
                  <th className="py-2 px-3">UPI VPA</th>
                  <th className="py-2 px-3">UPI Type</th>
                  <th className="py-2 px-3">Status</th>
                  <th className="py-2 px-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(i => (
                  <tr key={i.id} className="border-t">
                    <td className="py-2 px-3">{i.createdAt ? new Date(i.createdAt).toLocaleString() : '-'}</td>
                    <td className="py-2 px-3">{i.id.slice(0,8)}</td>
                    <td className="py-2 px-3">{i.upiId}</td>
                    <td className="py-2 px-3">{i.upiType === 'MERCHANT' ? 'Merchant' : 'Non Merchant'}</td>
                    <td className="py-2 px-3">{i.active ? 'Active' : 'Inactive'}</td>
                    <td className="py-2 px-3 text-right"><button onClick={() => remove(i.id)} className="rounded-md bg-red-600 text-white px-3 py-1 text-sm">Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
