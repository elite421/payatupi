"use client"

import { useEffect, useState, FormEvent } from "react"

export default function AppSettingsPage(){
  const [profile, setProfile] = useState<any>(null)
  const [settings, setSettings] = useState<any>(null)
  const [msgAutomation, setMsgAutomation] = useState<string | null>(null)
  const [wallet, setWallet] = useState<any>(null)
  const origin = typeof window !== 'undefined' ? window.location.origin : ''
  const rawApk = process.env.NEXT_PUBLIC_APK_URL as string | undefined
  const apkUrl = rawApk
    ? (rawApk.startsWith('/public/') ? rawApk.replace(/^\/public\//, '/') : rawApk)
    : '/Auto_sms_Update.apk'

  useEffect(() => {
    let active = true
    Promise.all([
      fetch('/api/profile', { cache: 'default', next: { revalidate: 300 } }),
      fetch('/api/checkout-settings', { cache: 'default', next: { revalidate: 300 } }),
      fetch('/api/wallet', { cache: 'default', next: { revalidate: 60 } })
    ]).then(async ([profileRes, settingsRes, walletRes]) => {
      if (!active) return
      if (profileRes.ok) {
        const p = await profileRes.json()
        if (active) setProfile(p)
      } else if (active) setProfile({})
      
      if (settingsRes.ok) {
        const s = await settingsRes.json()
        if (active) setSettings(s)
      } else if (active) setSettings({})
      
      if (walletRes.ok) {
        const w = await walletRes.json()
        if (active) setWallet(w)
      } else if (active) setWallet(null)
    }).catch(() => {
      if (active) {
        setProfile({})
        setSettings({})
        setWallet(null)
      }
    })
    return () => { active = false }
  }, [])

  async function updateSettings(partial: any, setSectionMsg: (s: string|null)=>void) {
    setSectionMsg(null)
    const r = await fetch('/api/checkout-settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(partial) })
    if (r.ok) { setSettings(await r.json()); setSectionMsg('Updated') } else { setSectionMsg('Failed') }
  }

  async function onUpdateProcessing(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const mode = String(fd.get('processing_mode') || '')
    const smsAutomation = mode === 'auto'
    await updateSettings({ smsAutomation }, setMsgAutomation)
  }

  async function copy(text: string){
    try { await navigator.clipboard.writeText(text); setMsgAutomation('Copied'); setTimeout(()=>setMsgAutomation(null), 1200) } catch {}
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Android App (APK) Settings</h1>
      <p className="mt-1 text-slate-600">Configure and connect the Android SMS app for automatic payment status updates.</p>

      <div className="mt-4">
        <a href={apkUrl} download className="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-white" style={{ backgroundColor: '#366870' }}>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M12 16a1 1 0 0 0 .707-.293l4-4a1 1 0 1 0-1.414-1.414L13 12.586V3a1 1 0 1 0-2 0v9.586L8.707 10.293a1 1 0 1 0-1.414 1.414l4 4A1 1 0 0 0 12 16Z"/><path d="M4 15a1 1 0 0 0-1 1v3a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-3a1 1 0 1 0-2 0v3a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1Z"/></svg>
          Download APK
        </a>
      </div>

      <div className="mt-6 glass rounded-xl p-6 space-y-4">
        <div className="font-semibold">Payment Processing</div>
        <form key={settings?.smsAutomation ? 'auto' : 'manual'} onSubmit={onUpdateProcessing} className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-6">
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="radio" name="processing_mode" value="manual" defaultChecked={!settings?.smsAutomation} className="h-4 w-4" />
              Manual (merchant updates status)
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="radio" name="processing_mode" value="auto" defaultChecked={!!settings?.smsAutomation} className="h-4 w-4" />
              Automated via Android SMS App
            </label>
          </div>
          <div>
            <button className="rounded-lg px-4 py-2 text-white" style={{ backgroundColor: '#366870' }}>Update</button>
            {msgAutomation && <span className="ml-3 text-sm text-slate-600">{msgAutomation}</span>}
          </div>
        </form>
      </div>

      <div className="mt-8 glass rounded-xl p-6 space-y-4">
        <div className="font-semibold">Account & API</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-slate-700">Account ID</label>
            <div className="mt-1 flex items-center gap-3">
              <input readOnly value={profile?.publicId || profile?.id || ''} className="w-full rounded-lg border px-3 py-2 bg-slate-50" />
              {(profile?.publicId || profile?.id) && (
                <button type="button" onClick={()=>copy(profile?.publicId || profile?.id)} className="rounded-lg px-3 py-2 text-white" style={{ backgroundColor: '#366870' }}>Copy</button>
              )}
            </div>
          </div>
          <div>
            <label className="text-sm text-slate-700">Wallet Balance</label>
            <div className="mt-1">
              <div className="w-full rounded-lg border px-3 py-2 bg-slate-50 font-semibold text-lg" style={{ color: '#366870' }}>
                ₹{wallet?.wallet ? wallet.wallet.balance.toFixed(2) : '0.00'}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 glass rounded-xl p-6 space-y-5">
        <div className="font-semibold">SMS Callback Endpoints</div>
        
        <div>
      
          <div className="mt-1 flex items-center gap-3">
            <input readOnly value={`${origin}/api/sms/callback/${profile?.publicId || profile?.id || ''}`} className="w-full rounded-lg border px-3 py-2 bg-slate-50" />
            <button type="button" disabled={!(profile?.publicId || profile?.id)} onClick={()=>copy(`${origin}/api/sms/callback/${profile?.publicId || profile?.id || ''}`)} className="rounded-lg px-3 py-2 text-white disabled:opacity-50" style={{ backgroundColor: '#366870' }}>Copy</button>
          </div>
  
        </div>
      </div>

      {/* <div className="mt-8 glass rounded-xl p-6 space-y-4">
        <div className="font-semibold">How to use the APK</div>
        <ol className="list-decimal pl-5 space-y-2 text-sm text-slate-700">
          <li>Install the Android SMS app on a device that receives your bank SMS for credits.</li>
          <li>Enable <b>Automated via Android SMS App</b> above.</li>
          <li>In the app, configure:
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>Account ID: copy from this page.</li>
              <li>Secret Key: create/reset on Developer page.</li>
              <li>Callback URL: use the POST URL shown above.</li>
            </ul>
          </li>
          <li>When a credit SMS arrives, the app should POST JSON like:</li>
        </ol>
        <pre className="mt-2 rounded-lg border bg-slate-50 p-3 overflow-auto text-xs">
{`{
  "account_id": "${profile?.publicId || profile?.id || 'YOUR_ACCOUNT_ID'}",
  "secret_key": "<YOUR_API_KEY>",
  "utr": "123456789012",
  "status": "Success",
  "amount": 499
}`}
        </pre>
        <div className="text-xs text-slate-600">Requirements: UTR + amount + status must be present. Matches your Pending transaction and marks it with status source "SMS".</div>
        <div className="mt-4 text-sm text-slate-700">Test with cURL:</div>
        <pre className="mt-2 rounded-lg border bg-slate-50 p-3 overflow-auto text-xs">
{`curl -X POST ${origin}/api/sms/callback \
  -H 'Content-Type: application/json' \
  -d '{
    "account_id": "${profile?.publicId || profile?.id || 'YOUR_ACCOUNT_ID'}",
    "secret_key": "<YOUR_API_KEY>",
    "utr": "123456789012",
    "status": "Success",
    "amount": 499
  }'`}
        </pre>
        <div className="text-xs text-slate-600">Tip: Use POST (recommended). GET is available but may expose parameters in the URL.</div>
      </div> */}

      <div className="mt-8 glass rounded-xl p-6 space-y-6">
        <div className="font-semibold">Step-by-step</div>
        <div className="grid grid-cols-1 gap-6">
          <div>
            <div className="text-sm font-medium text-slate-800">1) Download the APK & Install the App</div>
            <img src="/install1.jpg" alt="Install the APK" className="mt-2 w-full rounded border" loading="lazy" />
          </div>
          <div>
            <div className="text-sm font-medium text-slate-800">3) Enter Account ID and Callback URL</div>
            <img src="/account.jpg" alt="Set Account ID & Callback URL " className="mt-2 w-full rounded border" loading="lazy" />
          </div>
          <div>
            <div className="text-sm font-medium text-slate-800">3) Grant SMS permission and enable auto-processing</div>
            <img src="/permission.jpg" alt="Grant SMS permission and enable processing" className="mt-2 w-full rounded border" loading="lazy" />
          </div>
        </div>
      </div>
    </div>
  )
}

