"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import Head from "next/head"
import Navbar from "@/components/Navbaar"

export default function ProfilePage() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const { data: session } = useSession()

  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const r = await fetch('/api/profile', { cache: 'no-store' })
        if (r.ok) {
          const d = await r.json()
          if (active) setData(d)
        }
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [])

  function formatDateTime(v?: string | Date | null) {
    if (!v) return '—'
    const d = new Date(v)
    const opts: any = { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
    return d.toLocaleString(undefined, opts)
  }

  const displayName = (data?.name || session?.user?.name || 'User').trim()

  return (
    <>
      <Head>
        <title>Profile - Payatupi</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
      </Head>
      <Navbar/>

      <div className={`min-h-screen bg-gradient-to-br from-[#f5f7fa] to-[#e4edf5] font-sans transition-opacity duration-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
        <main className="max-w-7xl mx-auto px-6 py-8">
          <section className="mb-8">
            <div className="welcome-section mb-6">
              <div className="text-xl font-extrabold animate-[fadeGlow_3s_ease_infinite]" style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Welcome, {displayName}
              </div>
              <h4 className="text-gray-600 mt-1 font-medium">Your Profile Details</h4>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4" style={{ borderTopColor: "#50bd49" }}>
              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#50bd49]"></div>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Account ID</label>
                      <div className="font-mono text-lg break-all bg-gray-50 p-3 rounded-lg border border-gray-200">
                        {data?.id || '—'}
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Created At</label>
                      <div className="text-lg font-medium bg-gray-50 p-3 rounded-lg border border-gray-200">
                        {formatDateTime(data?.createdAt)}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Full Name</label>
                      <div className="text-lg font-medium bg-gray-50 p-3 rounded-lg border border-gray-200">
                        {data?.name || '—'}
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Phone Number</label>
                      <div className="text-lg font-medium bg-gray-50 p-3 rounded-lg border border-gray-200">
                        {data?.phone || '—'}
                      </div>
                    </div>

                    <div className="space-y-1 md:col-span-2">
                      <label className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Email Address</label>
                      <div className="text-lg font-medium bg-gray-50 p-3 rounded-lg border border-gray-200">
                        {data?.email || '—'}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 pt-6 border-t border-gray-200">
                    <a 
                      href="/dashboard/change-password" 
                      className="group relative inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-white overflow-hidden transition-transform hover:-translate-y-0.5"
                      style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)" }}
                    >
                      <i className="fas fa-key"></i>
                      <span className="relative z-10">Change Password</span>
                      <span className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </a>
                    
                    <a 
                      href="/dashboard/activity" 
                      className="group inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-gray-700 border-2 border-gray-300 hover:border-[#50bd49] hover:text-[#50bd49] transition-all duration-200"
                    >
                      <i className="fas fa-history"></i>
                      View Login Activity
                    </a>
                    
                    <a 
                      href="/dashboard/two-factor" 
                      className="group inline-flex items-center gap-2 px-6 py-3 rounded-full font-medium text-gray-700 border-2 border-gray-300 hover:border-[#50bd49] hover:text-[#50bd49] transition-all duration-200"
                    >
                      <i className="fas fa-shield-alt"></i>
                      Two-Factor Authentication
                    </a>
                  </div>
                </>
              )}
            </div>
          </section>
        </main>
      </div>

      <style jsx global>{`
        @keyframes fadeGlow {
          0% { filter: brightness(1); }
          50% { filter: brightness(1.15); }
          100% { filter: brightness(1); }
        }
      `}</style>
    </>
  )
}