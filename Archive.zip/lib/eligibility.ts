import { isSubscriptionActive } from '@/lib/subscription'
import { isKycApproved } from '@/lib/kyc'

export async function isMerchantEligible(userId: string): Promise<boolean> {
  const [sub, kyc] = await Promise.all([
    isSubscriptionActive(userId),
    isKycApproved(userId),
  ])
  return sub && kyc
}
