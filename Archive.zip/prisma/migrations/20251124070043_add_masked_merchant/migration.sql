-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "Plan" ADD VALUE 'INDIVIDUAL';
ALTER TYPE "Plan" ADD VALUE 'ENTERPRISE';
ALTER TYPE "Plan" ADD VALUE 'INDIVIDUAL_PLUS';
ALTER TYPE "Plan" ADD VALUE 'ENTERPRISE_PLUS';

-- AlterTable
ALTER TABLE "CheckoutSettings" ADD COLUMN     "maskMerchantName" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "maskedMerchantName" TEXT;
