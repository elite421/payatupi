export default function forget(){
    return (
   <div className="flex items-center justify-center min-h-screen px-4 mt-30">
   <div className="max-w-md w-full bg-white/70 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/40">
     
     {/* Title */}
     <h2 className="text-3xl font-bold mb-6 text-gray-900 text-center">Forgot Password</h2>
     
     {/* Email Input */}
     <label className="block mb-2 font-medium text-gray-700" htmlFor="email">
       Email
     </label>
     <input
       className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
       type="email"
       id="email"
       placeholder="Enter your email"
       required
     />
 
     {/* Submit Button */}
     <button className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition font-medium shadow-md">
       Reset Password
     </button>
   </div>
 </div>

    )
}