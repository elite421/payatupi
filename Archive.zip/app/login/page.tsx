"use client"

import Link from "next/link"
import { FormEvent, useState } from "react"
import { signIn } from "next-auth/react"

export default function Login(){
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    const form = new FormData(e.currentTarget)
    const email = String(form.get('email') || '')
    const password = String(form.get('password') || '')
    const res = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)
    if (res?.error) {
      setError('Invalid email or password')
    } else {
      window.location.href = '/account'
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="max-w-md w-full bg-white/70 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/40">
        <h1 className="text-4xl font-bold text-center text-gray-900">Login to Payatupi</h1>
        <p className="mt-2 text-lg text-center text-gray-600">Access your account and manage your payments.</p>

        <form onSubmit={onSubmit} className="mt-8">
          <label className="block mb-2 font-medium text-gray-700" htmlFor="email">Email</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none transition" name="email" type="email" id="email" placeholder="Enter your email" required />

          <label className="block mb-2 font-medium text-gray-700 mt-4" htmlFor="password">Password</label>
          <input className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400 focus:outline-none transition" name="password" type="password" id="password" placeholder="Enter your password" required />

          {error && <p className="mt-3 text-sm text-red-600">{error}</p>}

          <button type="submit" disabled={loading} className="mt-6 w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 transition font-medium shadow-md">
            {loading ? 'Signing in...' : 'Login'}
          </button>
        </form>

        <Link href="/forget" className="block mt-4 text-center text-blue-600 hover:underline font-medium">Forgot Password?</Link>
        <p className="mt-4 text-center text-gray-700">
          Don't have an account?{" "}
          <Link href="/signup" className="text-blue-600 font-semibold hover:underline">Sign up</Link>
        </p>
      </div>
    </div>
  )
}