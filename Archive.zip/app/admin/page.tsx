import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import AdminPanel from '@/components/admin/AdminPanel'

export default async function AdminPage(){
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email) return redirect('/login')
  if (role !== 'ADMIN') return redirect('/account')
  return (
    <div className="container mx-auto max-w-7xl px-4 py-6">
      <div className="glass rounded-xl p-6 min-h-[70vh]">
        <AdminPanel />
      </div>
    </div>
  )
}
