import { prisma } from '@/lib/prisma'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import PayForm from '@/components/pay/PayForm'

function looksLikeCuid(s: string) {
  return typeof s === 'string' && s.length >= 24 && s.startsWith('c')
}

async function getLinkByIdOrSlug(idOrSlug: string) {
  // Try by ID only if it looks like a cuid
  if (looksLikeCuid(idOrSlug)) {
    const byId = await prisma.paymentLink
      .findUnique({
        where: { id: idOrSlug },
        select: {
          id: true,
          userId: true,
          amount: true,
          title: true,
          type: true,
          active: true,
          user: { select: { name: true } },
        },
      })
      .catch(() => null)
    if (byId && byId.active) return byId
  }
  // Fallback to slug
  const bySlug = await prisma.paymentLink
    .findFirst({
      where: { slug: idOrSlug, active: true },
      select: {
        id: true,
        userId: true,
        amount: true,
        title: true,
        type: true,
        active: true,
        user: { select: { name: true } },
      },
    })
    .catch(() => null)
  return bySlug
}

export async function generateMetadata(
  { params }: { params: Promise<{ id: string }> }
): Promise<Metadata> {
  const { id } = await params
  const link = await getLinkByIdOrSlug(id)
  let titleName = 'Paying'
  if (link) {
    const cs = await (prisma as any).checkoutSettings.findUnique({ where: { userId: link.userId } }).catch(()=>null)
    const raw = link.user?.name || 'Merchant'
    const masked = (((cs as any)?.maskMerchantName) ? (((cs as any)?.maskedMerchantName || '').trim() || 'Merchant') : raw)
    titleName = `Paying - ${masked}`
  }
  return {
    title: titleName,
    description: 'Accept free and unlimited online payments with instant bank settlement with Zerotize.',
    keywords: [
      'UPI payment gateway',
      'UPI payment link',
      'UPI payment gateway plugin',
      'free payment gateway',
      'NEFT',
      'IMPS',
      'payment gateway',
      'best payment gateway',
    ],
  }
}

export default async function PayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const link = await getLinkByIdOrSlug(id)
  if (!link) return notFound()

  // Merchant eligibility gating (Subscription + KYC)

  const purposeValue = link.title || ''
  const cs = await (prisma as any).checkoutSettings.findUnique({ where: { userId: link.userId } }).catch(()=>null)
  const rawName = link.user?.name || 'Merchant'
  const displayName = (((cs as any)?.maskMerchantName) ? (((cs as any)?.maskedMerchantName || '').trim() || 'Merchant') : rawName)
  const dp = link.user && (cs as any)?.logoUrl || '/file.svg'

  return (
    <div className="w-full flex justify-center py-10">
      <div className="w-full max-w-lg rounded-xl bg-white text-black shadow-md">
        {/* Header */}
        <div className="flex items-center gap-3 border-b p-4">
          <div className="shrink-0">
            {/* DP */}
            <img src={dp} alt="Logo" className="h-12 w-12 rounded-full object-cover border" />
          </div>
          <div className="flex-1">
            <div className="text-xs text-slate-500">Paying to</div>
            <div className="flex items-center gap-2">
              <div className="text-base font-semibold">{displayName}</div>
              <span title="KYC Verified">
                <img src="/globe.svg" alt="KYC Verified" className="h-4 w-4" />
              </span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <PayForm
            linkIdOrSlug={id}
            fixedAmount={link.amount != null && link.amount > 0}
            defaultAmount={link.amount && link.amount > 0 ? link.amount : null}
            purpose={purposeValue}
            allowEditPurpose={(link as any).type === 'DEFAULT'}
          />
        </div>
      </div>
    </div>
  )
}
