import { prisma } from '@/lib/prisma'
import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import UpiModal from '@/components/pay/UpiModal'
import HideDuringUtr from '@/components/pay/HideDuringUtr'
import { planEntitlements } from '@/lib/subscription'

function genPaymentId(len = 12) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let out = ''
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)]
  return out
}

function looksLikeCuid(s: string) {
  return typeof s === 'string' && s.length >= 24 && s.startsWith('c')
}

async function getLinkByIdOrSlug(idOrSlug: string) {
  if (looksLikeCuid(idOrSlug)) {
    const byId = await prisma.paymentLink
      .findUnique({
        where: { id: idOrSlug },
        select: {
          id: true,
          userId: true,
          amount: true,
          title: true,
          redirectUrl: true,
          active: true,
          user: { select: { name: true } },
        },
      })
      .catch(() => null)
    if (byId && byId.active) return byId
  }
  const bySlug = await prisma.paymentLink
    .findFirst({
      where: { slug: idOrSlug, active: true },
      select: {
        id: true,
        userId: true,
        amount: true,
        title: true,
        redirectUrl: true,
        active: true,
        user: { select: { name: true } },
      },
    })
    .catch(() => null)
  return bySlug
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: 'Checkout - Zerotize',
    description: 'Accept free and unlimited online payments with instant bank settlement with Zerotize.',
    keywords: [
      'UPI payment gateway',
      'UPI payment link',
      'UPI payment gateway plugin',
      'free payment gateway',
      'NEFT',
      'IMPS',
      'payment gateway',
      'best payment gateway',
    ],
  }
}

export default async function CheckoutPage({ params, searchParams }: { params: Promise<{ id: string }>, searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const { id } = await params
  const sp = await searchParams as Record<string, string | string[] | undefined>
  const link = await getLinkByIdOrSlug(id)
  if (!link) return notFound()

  // Merchant eligibility gating temporarily disabled for testing

  const settings = await (prisma as any).checkoutSettings.findUnique({ where: { userId: link.userId }, select: { logoUrl: true, advertisementImageUrl: true, advertisementLink: true, successRedirectUrl: true } }).catch(()=>null)
  const dp = (settings as any)?.logoUrl || '/file.svg'
  const rawName = link.user?.name || 'Merchant'
  const displayName = (((settings as any)?.maskMerchantName) ? (((settings as any)?.maskedMerchantName || '').trim() || 'Merchant') : rawName)

  const upiAccount = await prisma.uPIAccount
    .findFirst({ where: { userId: link.userId, active: true } as any, select: { upiId: true }, orderBy: { createdAt: 'desc' } as any })
    .catch(() => null)
  const upiId = (upiAccount as any)?.upiId || ''

  const bank = await prisma.bankAccount
    .findFirst({ where: { userId: link.userId, active: true } as any, select: { accountHolder: true, accountNumber: true, ifsc: true, bankName: true }, orderBy: { createdAt: 'desc' } as any })
    .catch(() => null) as any

  // Ads entitlement: only Enterprise tiers (and legacy BUSINESS)
  const sub = await prisma.subscription.findUnique({ where: { userId: link.userId }, select: { plan: true, status: true, currentPeriodEnd: true } }).catch(()=>null)
  const adsEntitled = (() => {
    if (!sub) return false
    const end = sub.currentPeriodEnd ? sub.currentPeriodEnd.getTime() : 0
    const activeSub = sub.status === 'ACTIVE' && (end === 0 || end > Date.now()) && sub.plan !== 'FREE'
    const ent = planEntitlements((sub as any).plan)
    return activeSub && ent.checkoutAds
  })()

  // derive amount
  let chosenAmount: number | null = (link.amount != null && link.amount > 0) ? link.amount : null
  if (chosenAmount == null) {
    const spVal = typeof sp?.amount === 'string' ? sp.amount : Array.isArray(sp?.amount) ? sp?.amount[0] : undefined
    const parsed = spVal != null ? Number(spVal) : NaN
    if (Number.isFinite(parsed) && parsed > 0) chosenAmount = Math.round(parsed)
  }
  if (!chosenAmount || chosenAmount <= 0) {
    // Missing amount for variable link: send the user back to the amount entry page instead of 404
    redirect(`/pay/${encodeURIComponent(id)}`)
  }

  const buyerName = typeof sp?.name === 'string' ? sp.name : Array.isArray(sp?.name) ? sp?.name[0] : ''
  const purpose = (() => {
    const p = typeof sp?.purpose === 'string' ? sp.purpose : Array.isArray(sp?.purpose) ? sp.purpose[0] : ''
    const base = (p || '').trim()
    return base || (link as any).title || ''
  })()

  const paymentId = genPaymentId()
  const upiQr = upiId ? `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(displayName)}&am=${encodeURIComponent(String(chosenAmount))}&tn=${encodeURIComponent(paymentId)}&cu=INR` : ''
  const qrImg = upiQr ? `https://quickchart.io/qr?size=160&text=${encodeURIComponent(upiQr)}` : ''

  return (
    <div className="w-full flex justify-center py-10">
      <div className="w-full max-w-lg rounded-xl bg-white text-black shadow-md">
        {/* Header */}
        <div className="flex items-center gap-3 border-b p-4">
          <div className="shrink-0">
            <img src={dp} alt="Logo" className="h-12 w-12 rounded-full object-cover border" />
          </div>
          <div className="flex-1">
            <div className="text-xs text-slate-500">Paying to</div>
            <div className="flex items-center gap-2">
              <div className="text-base font-semibold">{displayName}</div>
              <span title="KYC Verified">
                <img src="/globe.svg" alt="KYC Verified" className="h-4 w-4" />
              </span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="mb-4 text-sm">
            <div className="flex items-center justify-between"><span>Payment ID</span><span className="font-mono">{paymentId}</span></div>
            <div className="flex items-center justify-between mt-1"><span>Amount</span><span className="font-semibold">₹ {chosenAmount}</span></div>
            {purpose ? (
              <div className="flex items-center justify-between mt-1"><span>Purpose</span><span className="truncate max-w-[60%] text-right" title={purpose}>{purpose}</span></div>
            ) : null}
          </div>

          <div className="mt-4">
            <div className="flex gap-2">
              <a href="#upi" className="px-3 py-2 rounded-md text-white bg-slate-900">UPI</a>
              {bank ? (
                <a href="#bank" className="px-3 py-2 rounded-md bg-slate-100 text-slate-800">Bank</a>
              ) : (
                <button className="px-3 py-2 rounded-md bg-slate-100 text-slate-800" disabled>Bank</button>
              )}
            </div>
          </div>

          {/* Advertisement on checkout page */}
          {adsEntitled && (settings as any)?.advertisementImageUrl && (
            <div className="mt-4 rounded-md border p-3 bg-slate-50">
              <div className="text-sm font-medium mb-2">Sponsored</div>
              { (settings as any)?.advertisementLink ? (
                <a href={(settings as any).advertisementLink} target="_blank" rel="noreferrer">
                  <img src={(settings as any).advertisementImageUrl} alt="Advertisement" className="max-h-40 rounded border" />
                </a>
              ) : (
                <img src={(settings as any).advertisementImageUrl} alt="Advertisement" className="max-h-40 rounded border" />
              )}
            </div>
          )}

          <HideDuringUtr>
            {/* UPI block */}
            <div id="upi" className="mt-4">
              <div className="flex items-center justify-between text-sm">
                <div className="font-medium">Pay With UPI</div>
                <a className="text-slate-700 hover:underline" href="#upi-modal-upi">Next</a>
              </div>

              <div className="mt-3 flex items-center gap-4">
                <div className="rounded-md border p-3">
                  {qrImg ? (
                    <img src={qrImg} alt="UPI QR Code" className="h-32 w-32" />
                  ) : (
                    <div className="text-xs text-slate-600">UPI not enabled</div>
                  )}
                </div>
                <div className="text-xs text-slate-600">
                  <div>Scan the QR using any UPI app on your phone</div>
                </div>
              </div>
            </div>

            {/* Bank block */}
            <div id="bank" className="mt-6 text-sm">
              <div className="flex items-center justify-between">
                <div className="font-medium">Bank Transfer</div>
                {bank && <a className="text-slate-700 hover:underline" href="#upi-modal-bank">Next</a>}
              </div>
              {!bank ? (
                <div className="mt-2 rounded-md border p-3 bg-slate-50 text-slate-600">Bank payments not enabled</div>
              ) : (
                <div className="mt-3 rounded-md border p-3">
                  <div className="grid grid-cols-1 gap-2 text-slate-800">
                    <div className="flex items-center justify-between"><span>Account Holder</span><span className="font-medium">{bank.accountHolder}</span></div>
                    <div className="flex items-center justify-between"><span>Bank</span><span className="font-medium">{bank.bankName}</span></div>
                    <div className="flex items-center justify-between"><span>Account No.</span><span className="font-mono">{bank.accountNumber}</span></div>
                    <div className="flex items-center justify-between"><span>IFSC</span><span className="font-mono">{bank.ifsc}</span></div>
                  </div>
                </div>
              )}
            </div>
          </HideDuringUtr>

          {/* UPI Modal with Confirm handler */}
          <UpiModal
            paymentId={paymentId}
            displayName={displayName}
            upiId={upiId}
            amount={chosenAmount}
            linkIdOrSlug={id}
            buyerName={buyerName}
            purpose={purpose}
            adImageUrl={adsEntitled ? (settings?.advertisementImageUrl || null) : null}
            adLink={adsEntitled ? (settings?.advertisementLink || null) : null}
            redirectUrl={link.redirectUrl || settings?.successRedirectUrl || null}
          />
        </div>
      </div>
    </div>
  )
}
