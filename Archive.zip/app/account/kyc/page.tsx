"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function KycPage(){
  const router = useRouter()
  useEffect(() => {
    router.replace('/account/profile')
  }, [router])
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Redirecting…</h1>
        <p className="mt-2 text-slate-600">KYC is now managed from your Profile. Taking you there…</p>
      </div>
    </div>
  )
}
