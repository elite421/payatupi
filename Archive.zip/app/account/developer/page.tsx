"use client"

import { useEffect, useState, FormEvent } from "react"

type Key = { id: string; prefix: string; revoked: boolean; createdAt: string; lastUsedAt?: string | null }
type Sub = { plan: string; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null }
type Profile = { id: string; name: string; email: string; phone?: string | null }
type Webhook = { id: string; url: string; secret?: string | null; createdAt: string }

export default function DeveloperPage(){
  const [keys, setKeys] = useState<Key[]>([])
  const [profile, setProfile] = useState<Profile | null>(null)
  const [sub, setSub] = useState<Sub | null>(null)
  const [creating, setCreating] = useState(false)
  const [newKey, setNewKey] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [resetOpen, setResetOpen] = useState(false)
  const [hooks, setHooks] = useState<Webhook[]>([])
  const [hookMsg, setHookMsg] = useState<string | null>(null)

  function isActiveSubscription(s: Sub | null){
    if (!s) return false
    if (s.status !== 'ACTIVE') return false
    if (String(s.plan).toUpperCase() === 'FREE') return false
    const end = s.currentPeriodEnd ? new Date(s.currentPeriodEnd) : null
    if (end && end.getTime() <= Date.now()) return false
    return true
  }

  async function load() {
    const [pr, sr, kr, wr] = await Promise.all([
      fetch('/api/profile'),
      fetch('/api/subscription'),
      fetch('/api/developer/api-keys'),
      fetch('/api/developer/webhooks'),
    ])
    if (pr.ok) setProfile(await pr.json())
    if (sr.ok) setSub(await sr.json())
    if (kr.ok) setKeys(await kr.json())
    if (wr.ok) setHooks(await wr.json())
  }

  useEffect(() => { load() }, [])

  async function createKey() {
    setCreating(true)
    setMsg(null)
    const r = await fetch('/api/developer/api-keys', { method: 'POST' })
    setCreating(false)
    if (r.ok) {
      const data = await r.json()
      setNewKey(data.key)
      await load()
    }
  }

  async function resetSecret() {
    setResetOpen(false)
    setMsg(null)
    const r = await fetch('/api/developer/api-keys/reset', { method: 'POST' })
    if (r.ok) {
      const data = await r.json()
      setNewKey(data.key)
      await load()
    } else {
      setMsg('Failed to reset')
    }
  }

  function downloadKeys(){
    const lines = keys.map(k => `${k.prefix}••••••••\t${new Date(k.createdAt).toISOString()}${k.revoked? '\trevoked':''}`)
    const blob = new Blob([lines.join('\n') || 'No keys'], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'api-keys.txt'
    a.click()
    URL.revokeObjectURL(url)
  }

  function downloadPlugin(){
    setMsg('WooCommerce plugin download not available yet')
  }

  const acctId = profile?.id ? profile.id.slice(0, 8) : '—'
  const active = isActiveSubscription(sub)
  const plan = String(sub?.plan || '').toUpperCase()
  const enterprise = active && (plan === 'ENTERPRISE' || plan === 'ENTERPRISE_PLUS' || plan === 'BUSINESS')
  const apiAccess = enterprise ? 'Active' : 'Inactive'

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-semibold">Developer</h1>
      <p className="text-slate-600">Manage API credentials and webhooks for integrating payments with your website.</p>

      <div className="glass rounded-xl p-4">
        <div className="text-lg font-semibold">API Credentials & Plugins</div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-y-3 text-sm">
          <div className="text-slate-600">Account ID</div>
          <div className="font-medium">{acctId}</div>

          <div className="text-slate-600">API Access</div>
          <div className="font-medium">{apiAccess}</div>

          <div className="text-slate-600">Secret Key</div>
          <div>
            <button disabled={!enterprise} onClick={()=>setResetOpen(true)} className="link underline text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed">Change</button>
          </div>

          <div className="text-slate-600">API Keys</div>
          <div>
            <button disabled={!enterprise} onClick={downloadKeys} className="link underline text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed">Download</button>
          </div>

          <div className="text-slate-600">WooCommerce Plugin</div>
          <div>
            <button disabled={!enterprise} onClick={downloadPlugin} className="link underline text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed">Download</button>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-3">
          <button onClick={createKey} disabled={creating || !enterprise} className="rounded-md bg-slate-900 text-white px-3 py-2 text-sm disabled:opacity-50 disabled:cursor-not-allowed">{creating ? 'Creating...' : 'Create API Key'}</button>
          {msg && <div className="text-sm text-slate-600">{msg}</div>}
        </div>
        {newKey && (
          <div className="mt-3 rounded-md border p-3 text-sm">
            <div className="font-medium">New key (copy now):</div>
            <div className="mt-1 font-mono break-all">{newKey}</div>
          </div>
        )}
      </div>

      <div className="glass rounded-xl p-4">
        <div className="text-lg font-semibold">Create Payment Request</div>
        <div className="mt-3 overflow-auto">
          <pre className="text-xs bg-slate-50 rounded-md p-3"><code>{`# API URL
$url = "https://zerotize.in/api_payment_init";
# Define the data
$account_id = ""; // Required - Account ID
$secret_key = ""; // Required - Secret key
$payment_id = ""; // Required - Unique payment ID
$payment_purpose = ""; // Optional - Maximum 30 characters
$payment_amount = ""; // Required - 1-100000
$payment_name = ""; // Optional - 3-30 characters
$payment_phone = ""; // Optional - 7-15 digit numeric
$payment_email = ""; // Optional - Valid email address
$redirect_url = ""; // Required - http://, https://, http://www, https://www
# Put the data into an array
$data = [
  "account_id" => $account_id,
  "secret_key" => $secret_key,
  "payment_id" => $payment_id,
  "payment_purpose" => $payment_purpose,
  "payment_amount" => $payment_amount,
  "payment_name" => $payment_name,
  "payment_phone" => $payment_phone,
  "payment_email" => $payment_email,
  "redirect_url" => $redirect_url
];
# Initialiaze the curl
$ch = curl_init($url);
# Setup request to send json via POST
$payload = json_encode(["init_payment" => $data]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json']);
# Return response instead of printing
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request
$result = curl_exec($ch);
curl_close($ch);
# Convert the json response into array
$api_response = json_decode($result, true);
`}</code></pre>
        </div>
      </div>

      <div className="glass rounded-xl p-4">
        <div className="text-lg font-semibold">Get Payment Details</div>
        <p className="mt-2 text-sm text-slate-600">When creating a payment request through the API, customers will be redirected to a URL you define (e.g., https://yoursite.com/callback.file?{'{payment_id}'}). In the callback file on your server, include the following code to retrieve payment details. This code can also be used to fetch and verify a payment at a later time.</p>
        <div className="mt-3 overflow-auto">
          <pre className="text-xs bg-slate-50 rounded-md p-3"><code>{`# API URL
$url = "https://zerotize.in/api_payment_status";
# Define the data
$account_id = ""; // Required - Account ID
$secret_key = ""; // Required - Secret key
$payment_id = ""; // Required - Payment ID
# Put the data into an array
$data = [
  "account_id" => $account_id,
  "secret_key" => $secret_key,
  "payment_id" => $payment_id
];
# Initialiaze the curl
$ch = curl_init($url);
# Setup request to send json via POST
$payload = json_encode(["fetch_payment" => $data]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json']);
# Return response instead of printing
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
# Send request
$result = curl_exec($ch);
curl_close($ch);
# Convert the json response into array
$api_response = json_decode($result, true);
`}</code></pre>
        </div>
      </div>

      {/* Webhooks */}
      <div className="glass rounded-xl p-4">
        <div className="text-lg font-semibold">Webhooks</div>
        <p className="mt-1 text-sm text-slate-600">Receive real-time notifications to your server when payment status changes.</p>
        <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
          <form
            onSubmit={async (e: FormEvent<HTMLFormElement>) => {
              e.preventDefault()
              setHookMsg(null)
              const fd = new FormData(e.currentTarget)
              const payload = { url: String(fd.get('url') || ''), secret: String(fd.get('secret') || '') }
              const r = await fetch('/api/developer/webhooks', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
              if (r.ok) {
                setHookMsg('Webhook added')
                e.currentTarget.reset()
                await load()
              } else {
                const d = await r.json().catch(()=>({error:'Failed'}))
                setHookMsg(d.error || 'Failed')
              }
            }}
            className="md:col-span-1 space-y-2"
          >
            <div>
              <label className="block text-slate-700">URL</label>
              <input name="url" placeholder="https://example.com/webhook" className="w-full rounded border px-3 py-2" disabled={!enterprise} required />
            </div>
            <div>
              <label className="block text-slate-700">Secret (optional)</label>
              <input name="secret" placeholder="Shared secret" className="w-full rounded border px-3 py-2" disabled={!enterprise} />
            </div>
            <div>
              <button className="rounded-md bg-slate-900 text-white px-3 py-2 disabled:opacity-50" disabled={!enterprise}>Add Webhook</button>
              {hookMsg && <span className="ml-3 text-slate-600">{hookMsg}</span>}
            </div>
          </form>
          <div className="md:col-span-2">
            <div className="text-sm font-medium mb-2">Existing</div>
            <div className="rounded border overflow-hidden">
              <table className="w-full text-xs">
                <thead><tr className="text-left text-slate-600"><th className="py-2 px-3">URL</th><th className="py-2 px-3">Created</th></tr></thead>
                <tbody>
                  {hooks.length === 0 ? (
                    <tr><td className="py-2 px-3" colSpan={2}>No webhooks</td></tr>
                  ) : hooks.map(h => (
                    <tr key={h.id} className="border-t"><td className="py-2 px-3 break-all">{h.url}</td><td className="py-2 px-3">{new Date(h.createdAt).toLocaleString()}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {resetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="glass w-full max-w-md rounded-xl p-6">
            <div className="text-lg font-semibold">Reset Secret Key</div>
            <div className="mt-2 text-sm text-slate-600">You are about to reset your API secret key. Your existing integrations will stop working until you update to the new key. Proceed?</div>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={()=>setResetOpen(false)} className="rounded-md bg-slate-100 px-4 py-2">No</button>
              <button onClick={resetSecret} className="rounded-md bg-slate-900 text-white px-4 py-2">Yes</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
