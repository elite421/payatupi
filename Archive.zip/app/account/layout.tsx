import Sidebar from '@/components/Sidebar'
import AccountGate from '@/components/AccountGate'

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="container mx-auto max-w-7xl px-4 py-6 flex gap-6">
      <Sidebar />
      <div className="flex-1">
        <AccountGate>
          <div className="glass rounded-xl p-6 min-h-[70vh]">
            {children}
          </div>
        </AccountGate>
      </div>
    </div>
  )
}
