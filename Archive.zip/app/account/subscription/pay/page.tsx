"use client"

import { useMemo, useState, ChangeEvent, useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'

export default function SubscriptionPayPage(){
  const sp = useSearchParams()
  const router = useRouter()
  const [utr, setUtr] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [errUtr, setErrUtr] = useState('')

  const plan = (sp.get('plan') || '').toUpperCase()
  const amtStr = sp.get('amt') || ''
  const amount = Number(amtStr)
  const allowedPlans = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS','PRO','BUSINESS']
  const validPlan = allowedPlans.includes(plan)
  const validAmount = Number.isFinite(amount) && amount > 0
  const baseAmount = amount
  const gstAmount = validAmount ? Math.round(baseAmount * 0.18) : 0
  const payAmount = validAmount ? baseAmount + gstAmount : 0

  const upiId = process.env.NEXT_PUBLIC_PLATFORM_UPI_ID || ''
  const platformName = process.env.NEXT_PUBLIC_PLATFORM_NAME || 'Payatme'

  const upiQr = useMemo(() => {
    if (!validAmount || !upiId) return ''
    const upi = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(platformName)}&am=${encodeURIComponent(String(payAmount))}&tn=${encodeURIComponent(`SUB-${plan}`)}&cu=INR`
    return `https://quickchart.io/qr?size=200&text=${encodeURIComponent(upi)}`
  }, [upiId, platformName, payAmount, plan, validAmount])

  function onFileChange(e: ChangeEvent<HTMLInputElement>){
    const f = e.target.files?.[0] || null
    setFile(f)
  }

  async function submit(){
    setErrUtr('')
    setMsg(null)
    const trimmed = utr.trim()
    if (!validPlan || !validAmount) { setMsg('Invalid plan or amount'); return }
    if (!trimmed || trimmed.length < 6) { setErrUtr('Enter a valid UTR'); return }
    const fd = new FormData()
    fd.append('plan', plan)
    fd.append('amount', String(payAmount))
    fd.append('utr', trimmed)
    if (file) fd.append('screenshot', file)
    setSubmitting(true)
    try {
      const r = await fetch('/api/subscription/payment', { method: 'POST', body: fd })
      if (r.ok) {
        setMsg('Submitted for verification. Admin will activate once verified.')
        setUtr('')
        setFile(null)
        setTimeout(() => router.push('/account/subscription'), 1200)
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setMsg(d.error || 'Failed')
      }
    } finally {
      setSubmitting(false)
    }
  }

  useEffect(() => {
    if (!validPlan || !validAmount) return
  }, [validPlan, validAmount])

  return (
    <div className="max-w-xl mx-auto py-8">
      <h1 className="text-2xl font-semibold">Pay Subscription</h1>
      {!validPlan || !validAmount ? (
        <div className="mt-4 rounded-md border p-4 text-sm text-red-700 bg-red-50">Invalid plan or amount</div>
      ) : (
        <div className="mt-6 rounded-xl border bg-white p-6 shadow-sm">
          <div className="text-sm text-slate-600">Plan</div>
          <div className="font-medium">{plan}</div>
          <div className="mt-2 text-sm text-slate-600">Amount (incl. 18% GST)</div>
          <div className="mt-1 text-xs text-slate-600">Base: ₹ {baseAmount} • GST (18%): ₹ {gstAmount}</div>
          <div className="font-semibold">Total Payable: ₹ {payAmount}</div>

          <div className="mt-4 flex items-center gap-4">
            <div className="rounded-md border p-3">
              {upiQr ? <img src={upiQr} alt="UPI QR" className="h-40 w-40" /> : <div className="text-xs text-slate-600">Invalid amount</div>}
            </div>
            <div className="text-xs text-slate-600">
              <div>UPI ID: <span className="font-medium">{upiId}</span></div>
              <div>Scan the QR with any UPI app to pay</div>
            </div>
          </div>

          <div className="mt-4">
            <label className="mb-1 block text-sm text-slate-700">UTR</label>
            <input value={utr} onChange={e=>setUtr(e.target.value)} className="w-full rounded-md border px-3 py-2" placeholder="Enter UTR" />
            {errUtr && <div className="text-xs text-red-600 mt-1">{errUtr}</div>}
          </div>
          <div className="mt-3">
            <label className="mb-1 block text-sm text-slate-700">Screenshot (optional)</label>
            <input type="file" accept="image/*" onChange={onFileChange} className="block w-full text-sm rounded-md border px-3 py-2 bg-white" />
          </div>

          <div className="mt-4 flex items-center gap-2">
            <button onClick={()=>router.back()} className="rounded-md bg-slate-100 px-4 py-2">Back</button>
            <button disabled={submitting} onClick={submit} className="rounded-md bg-slate-900 text-white px-4 py-2">{submitting ? 'Submitting...' : 'Submit'}</button>
          </div>
          {msg && <div className="mt-2 text-sm text-slate-600">{msg}</div>}
        </div>
      )}
    </div>
  )
}
