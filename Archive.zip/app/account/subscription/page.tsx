"use client"

import { useEffect, useState } from "react"
import { useRouter } from 'next/navigation'

type PlanCode = 'FREE'|'PRO'|'BUSINESS'|'INDIVIDUAL'|'ENTERPRISE'|'INDIVIDUAL_PLUS'|'ENTERPRISE_PLUS'
type Sub = { plan: PlanCode; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null }

export default function SubscriptionPage(){
  const [sub, setSub] = useState<Sub | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const fetchSubscription = async () => {
      try {
        setLoading(true)
        const r = await fetch('/api/subscription')
        if (r.ok) {
          const data = await r.json()
          setSub(data)
        } else {
          setMsg('Failed to load subscription data')
        }
      } catch (error) {
        console.error('Error fetching subscription:', error)
        setMsg('Network error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchSubscription()
  }, [])

  // Define plan hierarchy for comparison
  const planHierarchy: Record<string, PlanCode[]> = {
    'PRO': ['INDIVIDUAL', 'ENTERPRISE'],
    'BUSINESS': ['INDIVIDUAL_PLUS', 'ENTERPRISE_PLUS']
  }

  const cards = [
    {
      key: 'individual',
      title: 'Individual',
      price: 300,
      oldPrice: 999,
      duration: '30 Days',
      plan: 'INDIVIDUAL' as PlanCode,
      features: [
        { label: '70% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: false },
        { label: 'WooCommerce Plugin', ok: false },
        { label: 'API access', ok: false },
      ],
    },
    {
      key: 'enterprise',
      title: 'Enterprise',
      price: 375,
      oldPrice: 1499,
      duration: '30 Days',
      plan: 'ENTERPRISE' as PlanCode,
      features: [
        { label: '75% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: true },
        { label: 'WooCommerce Plugin', ok: true },
        { label: 'API access', ok: true },
      ],
    },
    {
      key: 'individual_plus',
      title: 'Individual Plus',
      price: 2000,
      oldPrice: 9999,
      duration: '365 Days',
      plan: 'INDIVIDUAL_PLUS' as PlanCode,
      features: [
        { label: '80% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: false },
        { label: 'WooCommerce Plugin', ok: false },
        { label: 'API access', ok: false },
      ],
    },
    {
      key: 'enterprise_plus',
      title: 'Enterprise Plus',
      price: 2250,
      oldPrice: 14999,
      duration: '365 Days',
      plan: 'ENTERPRISE_PLUS' as PlanCode,
      features: [
        { label: '85% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: true },
        { label: 'WooCommerce Plugin', ok: true },
        { label: 'API access', ok: true },
      ],
    },
  ]

  function isPlanActive(cardPlan: PlanCode, currentSub: Sub | null): boolean {
    if (!currentSub) return false
    
    // Direct match
    if (currentSub.plan === cardPlan) return true
    
    // Check plan hierarchy
    const equivalentPlans = planHierarchy[currentSub.plan]
    return equivalentPlans ? equivalentPlans.includes(cardPlan) : false
  }

  async function selectPlan(plan: PlanCode, amount: number) {
    if (plan === 'FREE') return
    
    setSaving(true)
    setMsg(null)
    
    try {
      const q = new URLSearchParams({ 
        plan: String(plan), 
        amt: String(amount) 
      })
      router.push(`/account/subscription/pay?${q.toString()}`)
    } catch (error) {
      console.error('Error selecting plan:', error)
      setMsg('Failed to proceed with plan selection')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading subscription information...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Choose Your Plan</h1>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          Select the perfect plan to unlock powerful features and enjoy better transaction rates.
        </p>
      </div>

      {/* Promotional Banner */}
      <div className="mb-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-6 text-center text-white shadow-lg">
        <div className="flex items-center justify-center space-x-2">
          <span className="text-2xl">🎁</span>
          <p className="text-lg font-semibold">
            Get an Amazon voucher worth ₹225 when you subscribe to Enterprise Plus!
          </p>
        </div>
      </div>

      {/* Subscription Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {cards.map(card => {
          const active = isPlanActive(card.plan, sub)
          const discount = Math.round(((card.oldPrice - card.price) / card.oldPrice) * 100)
          
          return (
            <div 
              key={card.key}
              className={`relative rounded-2xl border-2 p-6 shadow-lg transition-all duration-300 hover:shadow-xl ${
                active 
                  ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              {/* Discount Badge */}
              <div className="absolute -top-3 -right-3 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                Save {discount}%
              </div>

              {/* Plan Header */}
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{card.title}</h3>
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <span className="text-3xl font-bold text-gray-900">₹{card.price}</span>
                  <span className="text-lg text-gray-500 line-through">₹{card.oldPrice}</span>
                </div>
                <div className="text-sm text-gray-600 bg-gray-100 rounded-full px-3 py-1 inline-block">
                  {card.duration}
                </div>
              </div>

              {/* Features List */}
              <div className="space-y-3 mb-6">
                {card.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      feature.ok 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      {feature.ok ? '✓' : '✕'}
                    </div>
                    <span className={`text-sm ${
                      feature.ok ? 'text-gray-700' : 'text-gray-400'
                    }`}>
                      {feature.label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <button
                disabled={saving || active}
                onClick={() => selectPlan(card.plan, card.price)}
                className={`w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 ${
                  active
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 transform hover:scale-105'
                } disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none`}
              >
                {saving ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Processing...</span>
                  </div>
                ) : active ? (
                  <div className="flex items-center justify-center space-x-2">
                    <span>✓</span>
                    <span>Current Plan</span>
                  </div>
                ) : (
                  'Select Plan'
                )}
              </button>
            </div>
          )
        })}
      </div>

      {/* Current Subscription Status */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Current Subscription</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-600">Plan:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.plan ? sub.plan.replace('_', ' ') : 'FREE'}
            </span>
          </div>
          <div>
            <span className="text-gray-600">Status:</span>
            <span className={`ml-2 font-medium ${
              sub?.status === 'ACTIVE' ? 'text-green-600' :
              sub?.status === 'CANCELED' ? 'text-red-600' :
              'text-yellow-600'
            }`}>
              {sub?.status || 'INACTIVE'}
            </span>
          </div>
          <div>
            <span className="text-gray-600">Renewal Date:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.currentPeriodEnd 
                ? new Date(sub.currentPeriodEnd).toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })
                : '—'
              }
            </span>
          </div>
          <div>
            <span className="text-gray-600">Billing Cycle:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.plan?.includes('PLUS') ? 'Annual' : 'Monthly'}
            </span>
          </div>
        </div>
      </div>

      {/* Messages */}
      {msg && (
        <div className={`mt-4 p-4 rounded-lg ${
          msg.includes('error') || msg.includes('Failed') 
            ? 'bg-red-50 text-red-700 border border-red-200'
            : 'bg-blue-50 text-blue-700 border border-blue-200'
        }`}>
          {msg}
        </div>
      )}

      {/* Additional Info */}
      <div className="mt-8 text-center text-sm text-gray-500">
        <p>All plans include 24/7 customer support and secure payment processing.</p>
        <p className="mt-1">Need help choosing? <a href="/contact" className="text-blue-600 hover:text-blue-700 underline">Contact our sales team</a></p>
      </div>
    </div>
  )
}