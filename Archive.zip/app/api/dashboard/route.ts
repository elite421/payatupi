import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

function formatTimestamp(date: Date) {
  const pad = (n: number) => n.toString().padStart(2, '0')
  const d = new Date(date)
  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)
  const year = d.getFullYear()
  let hours = d.getHours()
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12
  if (hours === 0) hours = 12
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())
  return `${day}-${month}-${year} ${pad(hours)}:${minutes}:${seconds} ${ampm}`
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })

  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
 
  const prismaAny = prisma as any
  const [todayAgg, pendingAgg, successAgg, failedAgg, txs] = await Promise.all([
    prismaAny.transaction.aggregate({
      where: { userId: user.id, createdAt: { gte: startOfToday } },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Pending' },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Success' },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Failed' },
      _sum: { amount: true },
    }),
    prismaAny.transaction.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
  ])

  const recent = (txs as any[]).map((t: any) => {
    const base = Math.floor(new Date(t.createdAt).getTime() / 1000).toString(36).toUpperCase()
    const suf = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g, 'X')
    const mix = (base + suf).slice(0, 10)
    const displayId = mix.padEnd(10, '0')
    return {
      id: t.id,
      displayId,
      timestamp: formatTimestamp(t.createdAt),
      purpose: t.purpose,
      amount: t.amount,
      utr: t.utr ?? null,
      screenshot: t.screenshotUrl ?? null,
      status: (t.status as 'Pending' | 'Success' | 'Failed'),
      name: t.buyerName ?? null,
      phone: t.buyerPhone ?? null,
      email: t.buyerEmail ?? null,
      payMode: t.mode ? (['UPI', 'BANK'].includes(t.mode.toUpperCase()) ? (t.mode.toUpperCase() as 'UPI' | 'BANK') : 'NA') : 'NA',
      payUpiId: t.upiId ?? null,
      payAccountNumber: t.accountNumber ?? null,
      payIfsc: t.ifsc ?? null,
    }
  })

  const json = {
    todayTotal: todayAgg._sum.amount ?? 0,
    pendingTotal: pendingAgg._sum.amount ?? 0,
    successTotal: successAgg._sum.amount ?? 0,
    failedTotal: failedAgg._sum.amount ?? 0,
    recent,
  }

  return new Response(JSON.stringify(json), { status: 200 })
}
