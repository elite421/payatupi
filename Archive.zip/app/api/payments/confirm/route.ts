import { prisma } from '@/lib/prisma'
import { promises as fs } from 'fs'
import { randomBytes } from 'crypto'
import path from 'path'
import { isMerchantEligible } from '@/lib/eligibility'
import { createActivity } from '@/lib/activity'

function looksLikeCuid(s: string) {
  return typeof s === 'string' && s.length >= 24 && s.startsWith('c')
}

async function getLinkByIdOrSlug(idOrSlug: string) {
  if (looksLikeCuid(idOrSlug)) {
    const byId = await prisma.paymentLink.findUnique({
      where: { id: idOrSlug },
      select: { id: true, userId: true, title: true, type: true, active: true, redirectUrl: true },
    }).catch(() => null)
    if (byId && byId.active) return byId
  }
  const bySlug = await prisma.paymentLink.findFirst({
    where: { slug: idOrSlug, active: true },
    select: { id: true, userId: true, title: true, type: true, active: true, redirectUrl: true },
  }).catch(() => null)
  return bySlug
}

export async function POST(req: Request) {
  try {
    const form = await req.formData().catch(() => null)
    if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })

    const linkIdOrSlug = String(form.get('link') || '')
    const amountStr = String(form.get('amount') || '')
    const paymentId = String(form.get('paymentId') || '')
    const payMode = String(form.get('payMode') || 'upi')
    const utr = String(form.get('utr') || '')
    // optional
    const buyerName = String(form.get('buyerName') || '')
    const purposeIn = String(form.get('purpose') || '')
    const screenshot = form.get('screenshot') as File | null

    if (!linkIdOrSlug) return new Response(JSON.stringify({ error: 'Missing link' }), { status: 400 })
    const link = await getLinkByIdOrSlug(linkIdOrSlug)
    if (!link) return new Response(JSON.stringify({ error: 'Invalid link' }), { status: 404 })

    // Gating: merchant must be eligible (Subscription + KYC)
    const active = await isMerchantEligible(link.userId)
    if (!active) return new Response(JSON.stringify({ error: 'Merchant subscription inactive' }), { status: 403 })

    const amount = Number(amountStr)
    if (!Number.isFinite(amount) || amount <= 0) return new Response(JSON.stringify({ error: 'Invalid amount' }), { status: 400 })
    if (!utr || utr.length < 6) return new Response(JSON.stringify({ error: 'Invalid UTR' }), { status: 400 })

    // Store screenshot if provided
    let screenshotUrl: string | null = null
    if (screenshot) {
      const buf = Buffer.from(await screenshot.arrayBuffer())
      const ext = (screenshot.type?.split('/')?.[1] || 'png').toLowerCase()
      const name = `${randomBytes(16).toString('hex')}.${ext}`
      const dir = path.join(process.cwd(), 'public', 'receipts')
      const full = path.join(dir, name)
      await fs.mkdir(dir, { recursive: true })
      await fs.writeFile(full, buf)
      screenshotUrl = `/receipts/${name}`
    }

    // Fetch merchant UPI/BANK to save context (optional)
    const upiAcc = await prisma.uPIAccount.findFirst({ where: { userId: link.userId, active: true } as any, select: { upiId: true }, orderBy: { createdAt: 'desc' } as any }).catch(() => null)
    const upiId = (upiAcc as any)?.upiId || null
    const bankAcc = payMode.toLowerCase() === 'bank'
      ? await prisma.bankAccount.findFirst({ where: { userId: link.userId, active: true } as any, select: { accountNumber: true, ifsc: true }, orderBy: { createdAt: 'desc' } as any }).catch(() => null)
      : null

    // Determine redirect target
    const cs = await prisma.checkoutSettings.findUnique({ where: { userId: link.userId }, select: { successRedirectUrl: true } }).catch(() => null)
    const redirectTarget = link.redirectUrl || (cs as any)?.successRedirectUrl || null

    // Derive final purpose (allow override only for DEFAULT links)
    const rawPurpose = (purposeIn || '').trim()
    const isDefault = String((link as any).type || '').toUpperCase() === 'DEFAULT'
    const finalPurpose = (isDefault && rawPurpose) ? rawPurpose.slice(0, 60) : (link as any).title

    // Create a pending transaction for merchant
    const tx = await prisma.transaction.create({
      data: {
        userId: link.userId,
        purpose: finalPurpose,
        amount: Math.round(amount),
        status: 'Pending',
        mode: payMode.toUpperCase(),
        upiId: upiId,
        accountNumber: (bankAcc as any)?.accountNumber || undefined,
        ifsc: (bankAcc as any)?.ifsc || undefined,
        utr: utr,
        screenshotUrl: screenshotUrl || undefined,
        buyerName: buyerName || undefined,
      },
      select: { id: true },
    })

    // Activity
    await createActivity(link.userId, 'PAYMENT_CREATED', 'Payment request created', { txId: tx.id, amount: Math.round(amount), mode: payMode.toUpperCase() })

    return new Response(JSON.stringify({ id: tx.id, screenshotUrl, paymentId, redirectUrl: redirectTarget }), { status: 200 })
  } catch (err) {
    console.error('POST /api/payments/confirm failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
