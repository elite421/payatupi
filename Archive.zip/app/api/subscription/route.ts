import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createActivity } from '@/lib/activity'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const sub = await prisma.subscription.findUnique({ where: { userId: user.id } })
  return new Response(JSON.stringify(sub), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { plan } = body || {}
  if (!plan) return new Response(JSON.stringify({ error: 'plan required' }), { status: 400 })
  const P = String(plan).toUpperCase()
  const allowed = ['FREE','INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS','PRO','BUSINESS']
  if (!allowed.includes(P)) return new Response(JSON.stringify({ error: 'invalid plan' }), { status: 400 })
  const now = new Date()
  let periodEnd: Date | null = null
  if (P === 'INDIVIDUAL' || P === 'ENTERPRISE' || P === 'PRO') {
    periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
  } else if (P === 'INDIVIDUAL_PLUS' || P === 'ENTERPRISE_PLUS' || P === 'BUSINESS') {
    periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
  } else {
    periodEnd = null
  }
  const sub = await prisma.subscription.upsert({
    where: { userId: user.id },
    update: { plan: P as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
    create: { userId: user.id, plan: P as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
  })
  await createActivity(user.id, 'SUBSCRIPTION_CHANGED', 'Subscription updated', { plan: P, periodEnd })
  return new Response(JSON.stringify(sub), { status: 200 })
}
