import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { promises as fs } from 'fs'
import { randomBytes } from 'crypto'
import path from 'path'
import { createActivity } from '@/lib/activity'

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const form = await req.formData().catch(()=>null)
  if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
  const plan = String(form.get('plan') || '')
  const utr = String(form.get('utr') || '')
  const amountStr = String(form.get('amount') || '')
  const screenshot = form.get('screenshot') as File | null
  const allowedPlans = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS','PRO','BUSINESS']
  if (!allowedPlans.includes(plan.toUpperCase())) return new Response(JSON.stringify({ error: 'Invalid plan' }), { status: 400 })
  if (!utr || utr.length < 6) return new Response(JSON.stringify({ error: 'Invalid UTR' }), { status: 400 })

  let screenshotUrl: string | null = null
  if (screenshot) {
    const buf = Buffer.from(await screenshot.arrayBuffer())
    const ext = (screenshot.type?.split('/')?.[1] || 'png').toLowerCase()
    const name = `${randomBytes(16).toString('hex')}.${ext}`
    const dir = path.join(process.cwd(), 'public', 'receipts')
    const full = path.join(dir, name)
    await fs.mkdir(dir, { recursive: true })
    await fs.writeFile(full, buf)
    screenshotUrl = `/receipts/${name}`
  }

  let amount = Number(amountStr)
  if (!Number.isFinite(amount) || amount <= 0) {
    const p = plan.toUpperCase()
    if (p === 'INDIVIDUAL' || p === 'PRO') amount = 300
    else if (p === 'ENTERPRISE') amount = 375
    else if (p === 'INDIVIDUAL_PLUS') amount = 2000
    else amount = 2250
  } else {
    amount = Math.round(amount)
  }
  const tx = await prisma.transaction.create({
    data: {
      userId: user.id,
      purpose: `Subscription ${plan.toUpperCase()}`,
      amount,
      status: 'Pending',
      mode: 'SUBSCRIPTION',
      utr,
      screenshotUrl: screenshotUrl || undefined,
    },
    select: { id: true },
  })

  await createActivity(user.id, 'PAYMENT_CREATED', 'Subscription payment submitted', { txId: tx.id, plan, amount })

  return new Response(JSON.stringify({ id: tx.id }), { status: 200 })
}
