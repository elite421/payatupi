import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function PATCH(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const body = await req.json().catch(() => ({})) as any
  const allowedPlans = ['FREE','PRO','BUSINESS','INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS']
  const allowedStatus = ['ACTIVE','CANCELED','PAST_DUE']
  const data: any = {}
  if (body.plan && allowedPlans.includes(body.plan)) data.plan = body.plan
  if (body.status && allowedStatus.includes(body.status)) data.status = body.status
  if (body.periodEnd) {
    const t = Date.parse(body.periodEnd)
    if (!Number.isNaN(t)) data.currentPeriodEnd = new Date(t)
  }
  // Optional: extendDays to extend from now or existing end
  if (typeof body.extendDays === 'number' && Number.isFinite(body.extendDays)) {
    const now = new Date()
    const sub = await prisma.subscription.findUnique({ where: { userId } })
    const base = sub?.currentPeriodEnd && sub.currentPeriodEnd.getTime() > now.getTime() ? sub.currentPeriodEnd : now
    const extended = new Date(base.getTime() + body.extendDays * 24 * 60 * 60 * 1000)
    data.currentPeriodEnd = extended
    if (!data.status) data.status = 'ACTIVE'
  }
  const sub = await prisma.subscription.upsert({
    where: { userId },
    update: data,
    create: { userId, plan: data.plan || 'FREE', status: data.status || 'ACTIVE', currentPeriodEnd: data.currentPeriodEnd || null },
  })
  return new Response(JSON.stringify(sub), { status: 200 })
}
