import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { randomBytes } from 'crypto'
import path from 'path'
import { promises as fs } from 'fs'

export async function POST(req: Request) {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })

    const form = await req.formData().catch(() => null)
    if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
    const file = form.get('file') as File | null
    if (!file) return new Response(JSON.stringify({ error: 'File required' }), { status: 400 })

    const buf = Buffer.from(await file.arrayBuffer())
    const ext = (file.type?.split('/')?.[1] || 'png').toLowerCase()
    const name = `${randomBytes(16).toString('hex')}.${ext}`
    const dir = path.join(process.cwd(), 'public', 'ads')
    const full = path.join(dir, name)
    await fs.mkdir(dir, { recursive: true })
    await fs.writeFile(full, buf)
    const url = `/ads/${name}`

    const settings = await prisma.checkoutSettings.upsert({
      where: { userId: user.id },
      update: { advertisementImageUrl: url },
      create: { userId: user.id, advertisementImageUrl: url },
    })
    return new Response(JSON.stringify({ url, settings }), { status: 200 })
  } catch (err) {
    console.error('POST /api/checkout-settings/ad-image failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
