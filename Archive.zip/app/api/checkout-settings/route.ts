import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })
    const settings = await prisma.checkoutSettings.findUnique({ where: { userId: user.id } })
    return new Response(JSON.stringify(settings), { status: 200 })
  } catch (err) {
    console.error('GET /api/checkout-settings failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}

export async function POST(req: Request) {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })
    const body = await req.json().catch(() => ({}))
    const data: any = {}
    const keys = [
      'logoUrl',
      'themeColor',
      'successRedirectUrl',
      'enableTips',
      'enableNotes',
      'currency',
      // New fields
      'enablePurpose',
      'enableName',
      'enablePhone',
      'enableEmail',
      'checkoutMessage',
      'advertisementImageUrl',
      'advertisementLink',
    ]
    for (const k of keys) if (body[k] !== undefined) data[k] = body[k]
    const settings = await prisma.checkoutSettings.upsert({
      where: { userId: user.id },
      update: data,
      create: { userId: user.id, ...data },
    })
    return new Response(JSON.stringify(settings), { status: 200 })
  } catch (err) {
    console.error('POST /api/checkout-settings failed', err)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
