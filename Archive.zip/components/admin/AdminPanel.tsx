"use client"

import { useEffect, useState } from 'react'

type UserRow = {
  id: string
  name: string
  email: string
  role: 'USER'|'ADMIN'
  subscription: { plan: string; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null } | null
}

export default function AdminPanel(){
  const [loading, setLoading] = useState(true)
  const [users, setUsers] = useState<UserRow[]>([])
  const [msg, setMsg] = useState<string|null>(null)
  const [detailOpen, setDetailOpen] = useState(false)
  const [detail, setDetail] = useState<any>(null)
  const [logs, setLogs] = useState<any[]>([])
  const [txs, setTxs] = useState<any[]>([])
  const [tab, setTab] = useState<'dashboard'|'users'|'transactions'|'support'>('dashboard')
  const [stats, setStats] = useState<any>(null)
  const [q, setQ] = useState('')
  const [txList, setTxList] = useState<any[]>([])
  const [txLoading, setTxLoading] = useState(false)
  const [txFilter, setTxFilter] = useState<string>('all')
  const [txUserId, setTxUserId] = useState('')
  const [txTake, setTxTake] = useState<number>(50)
  const [tickets, setTickets] = useState<any[]>([])
  const [ticketLoading, setTicketLoading] = useState(false)
  const [ticketFilter, setTicketFilter] = useState<'all'|'OPEN'|'CLOSED'>('all')

  // Load functions remain the same...
  async function load(){
    setLoading(true)
    const r = await fetch('/api/admin/users', { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setUsers(await r.json())
  }

  async function loadTickets(){
    setTicketLoading(true)
    const url = new URL('/api/admin/support/tickets', window.location.origin)
    if (ticketFilter !== 'all') url.searchParams.set('status', ticketFilter)
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setTicketLoading(false)
    if (r.ok) setTickets(await r.json())
  }

  async function updateTicket(id: string, status: 'OPEN'|'CLOSED'){
    const r = await fetch(`/api/admin/support/tickets/${encodeURIComponent(id)}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (r.ok) { setMsg('Ticket updated'); await loadTickets() } else { setMsg('Failed to update ticket') }
  }

  async function loadStats(){
    try {
      const r = await fetch('/api/admin/dashboard/stats', { cache: 'no-store' })
      if (r.ok) setStats(await r.json())
    } catch {}
  }

  async function loadUsers(search?: string){
    setLoading(true)
    const url = new URL('/api/admin/users', window.location.origin)
    const qv = (search ?? q).trim()
    if (qv) url.searchParams.set('q', qv)
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setUsers(await r.json())
  }

  async function loadTransactions(){
    setTxLoading(true)
    const url = new URL('/api/admin/transactions', window.location.origin)
    if (txFilter !== 'all') url.searchParams.set('status', txFilter)
    if (txUserId.trim()) url.searchParams.set('userId', txUserId.trim())
    if (txTake) url.searchParams.set('take', String(txTake))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setTxLoading(false)
    if (r.ok) setTxList(await r.json())
  }

  useEffect(() => { loadStats(); loadUsers() }, [])
  useEffect(() => { if (tab === 'transactions') loadTransactions() }, [tab, txFilter, txUserId, txTake])
  useEffect(() => { if (tab === 'support') loadTickets() }, [tab, ticketFilter])
  useEffect(() => { load() }, [])

  async function save(u: UserRow, idx: number){
    const plan = (document.getElementById(`plan-${u.id}`) as HTMLSelectElement)?.value as any
    const status = (document.getElementById(`status-${u.id}`) as HTMLSelectElement)?.value as any
    const periodEnd = (document.getElementById(`end-${u.id}`) as HTMLInputElement)?.value
    const body: any = { plan, status }
    if (periodEnd) body.periodEnd = periodEnd
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (r.ok) { await loadUsers(); setMsg('Updated') } else { setMsg('Failed') }
  }

  async function extend(u: UserRow, days: number){
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ extendDays: days }) })
    if (r.ok) { await loadUsers(); setMsg(`Extended by ${days} days`) } else { setMsg('Failed') }
  }

  async function activate(u: UserRow){
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'ACTIVE' }) })
    if (r.ok) { await loadUsers(); setMsg('Account activated') } else { setMsg('Failed to activate') }
  }

  async function openManage(u: UserRow){
    setDetailOpen(true)
    setDetail(null)
    setLogs([])
    setTxs([])
    try {
      const [pr, lr, tr] = await Promise.all([
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/profile`, { cache: 'no-store' }),
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/activities?take=50`, { cache: 'no-store' }),
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/transactions?take=50`, { cache: 'no-store' }),
      ])
      if (pr.ok) setDetail(await pr.json())
      if (lr.ok) setLogs(await lr.json())
      if (tr.ok) setTxs(await tr.json())
    } catch {}
  }

  async function updateKyc(userId: string){
    const status = (document.getElementById('kyc-status') as HTMLSelectElement)?.value
    const note = (document.getElementById('kyc-note') as HTMLInputElement)?.value
    const r = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/kyc`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status, adminNote: note }) })
    if (r.ok) {
      setMsg('KYC updated')
      const pr = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { cache: 'no-store' })
      if (pr.ok) setDetail(await pr.json())
    } else {
      setMsg('Failed to update KYC')
    }
  }

  async function saveProfile(userId: string){
    const name = (document.getElementById('profile-name') as HTMLInputElement)?.value
    const phone = (document.getElementById('profile-phone') as HTMLInputElement)?.value
    const role = (document.getElementById('profile-role') as HTMLSelectElement)?.value
    const r = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, phone, role }) })
    if (r.ok) {
      setMsg('Profile updated')
      const pr = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { cache: 'no-store' })
      if (pr.ok) setDetail(await pr.json())
      await loadUsers()
    } else {
      setMsg('Failed to update profile')
    }
  }

  async function updateTxStatus(id: string, status: 'Pending'|'Success'|'Failed'){
    const r = await fetch(`/api/admin/transactions/${encodeURIComponent(id)}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (r.ok) {
      setMsg('Transaction updated')
      await loadTransactions()
    } else {
      setMsg('Failed to update transaction')
    }
  }

  function exportTxCsv(){
    const rows = [
      ['Date','User Name','User Email','Purpose','Amount','Status','Mode','UTR','Screenshot','PaymentID10'].join(',')
    ]
    for (const t of txList) {
      const base = Math.floor(new Date(t.createdAt).getTime()/1000).toString(36).toUpperCase()
      const suf = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g,'X')
      const pid = (base + suf).slice(0,10).padEnd(10,'0')
      const row = [
        new Date(t.createdAt).toLocaleString(),
        (t.user?.name || '').replaceAll(',',' '),
        (t.user?.email || ''),
        String(t.purpose || '').replaceAll(',',' '),
        String(t.amount || ''),
        String(t.status || ''),
        String(t.mode || ''),
        String(t.utr || ''),
        String(t.screenshotUrl || ''),
        pid,
      ]
      rows.push(row.join(','))
    }
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'transactions.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="min-h-screen bg-gray-50/30">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="mt-1 text-sm text-gray-600">Manage users, subscriptions, transactions and support</p>
          </div>
          {msg && (
            <div className="px-4 py-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-sm">
              {msg}
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="mt-6 flex space-x-1">
          {(['dashboard', 'users', 'transactions', 'support'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                tab === t
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
              }`}
            >
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="p-6">
        {/* Dashboard Overview */}
        {tab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Total Users', value: stats?.totalUsers ?? '—', color: 'blue' },
              { label: 'Active Subscribers', value: stats?.activeSubscribers ?? '—', color: 'green' },
              { label: 'KYC Pending', value: stats?.kycPending ?? '—', color: 'orange' },
              { label: 'Payments Pending', value: stats?.txPending ?? '—', color: 'red' }
            ].map((stat, index) => (
              <div key={index} className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-full bg-${stat.color}-100 flex items-center justify-center`}>
                    <div className={`w-6 h-6 bg-${stat.color}-500 rounded-full opacity-80`}></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Users Tab */}
        {tab === 'users' && (
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
            <div className="p-6 border-b border-gray-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <input
                      value={q}
                      onChange={e => setQ(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') loadUsers() }}
                      placeholder="Search by name, email, or phone..."
                      className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => loadUsers()}
                  className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                >
                  Search
                </button>
              </div>
            </div>

            <div className="overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    {['User', 'Plan', 'Status', 'Period End', 'Actions'].map((header) => (
                      <th key={header} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        </div>
                        <p className="mt-2 text-sm text-gray-500">Loading users...</p>
                      </td>
                    </tr>
                  ) : users.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                        No users found
                      </td>
                    </tr>
                  ) : (
                    users.map((u) => (
                      <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div>
                            <div className="font-medium text-gray-900">{u.name}</div>
                            <div className="text-sm text-gray-500">{u.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            id={`plan-${u.id}`}
                            defaultValue={u.subscription?.plan || 'FREE'}
                            className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                          >
                            <option>FREE</option>
                            <option>INDIVIDUAL</option>
                            <option>ENTERPRISE</option>
                            <option>INDIVIDUAL_PLUS</option>
                            <option>ENTERPRISE_PLUS</option>
                            <option>PRO</option>
                            <option>BUSINESS</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            id={`status-${u.id}`}
                            defaultValue={u.subscription?.status || 'ACTIVE'}
                            className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                          >
                            <option>ACTIVE</option>
                            <option>CANCELED</option>
                            <option>PAST_DUE</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <input
                            id={`end-${u.id}`}
                            type="datetime-local"
                            defaultValue={u.subscription?.currentPeriodEnd ? new Date(u.subscription.currentPeriodEnd).toISOString().slice(0, 16) : ''}
                            className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <select
                            defaultValue=""
                            onChange={(e) => {
                              const v = e.target.value
                              if (!v) return
                              if (v === 'save') save(u, 0)
                              else if (v === 'activate') activate(u)
                              else if (v === 'extend30') extend(u, 30)
                              else if (v === 'extend365') extend(u, 365)
                              else if (v === 'manage') openManage(u)
                              e.currentTarget.selectedIndex = 0
                            }}
                            className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                          >
                            <option value="">Quick actions...</option>
                            <option value="save">Save subscription</option>
                            <option value="activate">Activate now</option>
                            <option value="extend30">Extend +30 days</option>
                            <option value="extend365">Extend +365 days</option>
                            <option value="manage">Manage user</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Transactions Tab */}
        {tab === 'transactions' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <div className="flex flex-col lg:flex-row gap-4">
                <select
                  value={txFilter}
                  onChange={e => setTxFilter(e.target.value)}
                  className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="all">All Status</option>
                  <option>Pending</option>
                  <option>Success</option>
                  <option>Failed</option>
                </select>
                <input
                  value={txUserId}
                  onChange={e => setTxUserId(e.target.value)}
                  placeholder="Filter by User ID"
                  className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                />
                <select
                  value={String(txTake)}
                  onChange={e => setTxTake(parseInt(e.target.value) || 50)}
                  className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="50">50 rows</option>
                  <option value="100">100 rows</option>
                  <option value="200">200 rows</option>
                </select>
                <div className="flex gap-2">
                  <button
                    onClick={loadTransactions}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition-colors"
                  >
                    Refresh
                  </button>
                  <button
                    onClick={exportTxCsv}
                    className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 transition-colors"
                  >
                    Export CSV
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      {['Date', 'Payment ID', 'User', 'Purpose', 'Amount', 'Status', 'Mode', 'UTR', 'Screenshot', 'Action'].map((header) => (
                        <th key={header} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {txLoading ? (
                      <tr>
                        <td colSpan={10} className="px-6 py-12 text-center">
                          <div className="flex justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                          </div>
                          <p className="mt-2 text-sm text-gray-500">Loading transactions...</p>
                        </td>
                      </tr>
                    ) : txList.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="px-6 py-12 text-center text-gray-500">
                          No transactions found
                        </td>
                      </tr>
                    ) : (
                      txList.map((t: any) => (
                        <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {new Date(t.createdAt).toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-sm font-mono text-gray-600">
                            {(() => {
                              const b = Math.floor(new Date(t.createdAt).getTime() / 1000).toString(36).toUpperCase()
                              const s = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g, 'X')
                              return (b + s).slice(0, 10).padEnd(10, '0')
                            })()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">{t.user?.name || '—'}</div>
                            <div className="text-sm text-gray-500">{t.user?.email}</div>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-900">{t.purpose}</td>
                          <td className="px-6 py-4 text-sm font-medium text-gray-900">₹{t.amount}</td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              t.status === 'Success' ? 'bg-green-100 text-green-800' :
                              t.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {t.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">{t.mode || '—'}</td>
                          <td className="px-6 py-4 text-sm font-mono text-gray-600">{t.utr || '—'}</td>
                          <td className="px-6 py-4">
                            {t.screenshotUrl ? (
                              <a
                                href={t.screenshotUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-blue-600 hover:text-blue-500 text-sm font-medium"
                              >
                                View
                              </a>
                            ) : (
                              <span className="text-gray-400 text-sm">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <select
                              defaultValue={t.status}
                              onChange={(e) => updateTxStatus(t.id, e.target.value as any)}
                              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                            >
                              <option>Pending</option>
                              <option>Success</option>
                              <option>Failed</option>
                            </select>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Support Tab */}
        {tab === 'support' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 p-6 shadow-sm">
              <div className="flex items-center gap-4">
                <select
                  value={ticketFilter}
                  onChange={e => setTicketFilter(e.target.value as any)}
                  className="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                >
                  <option value="all">All Tickets</option>
                  <option value="OPEN">Open</option>
                  <option value="CLOSED">Closed</option>
                </select>
                <button
                  onClick={loadTickets}
                  className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition-colors"
                >
                  Refresh
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      {['Date', 'User', 'Subject', 'Message', 'Attachment', 'Status', 'Action'].map((header) => (
                        <th key={header} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {ticketLoading ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center">
                          <div className="flex justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                          </div>
                          <p className="mt-2 text-sm text-gray-500">Loading tickets...</p>
                        </td>
                      </tr>
                    ) : tickets.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                          No tickets found
                        </td>
                      </tr>
                    ) : (
                      tickets.map((t: any) => (
                        <tr key={t.id} className="hover:bg-gray-50 transition-colors">
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {new Date(t.createdAt).toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">{t.user?.name || '—'}</div>
                            <div className="text-sm text-gray-500">{t.user?.email}</div>
                          </td>
                          <td className="px-6 py-4 text-sm font-medium text-gray-900">{t.subject}</td>
                          <td className="px-6 py-4 text-sm text-gray-600 max-w-xs">
                            <div className="line-clamp-2">{t.message}</div>
                          </td>
                          <td className="px-6 py-4">
                            {t.attachmentUrl ? (
                              <a
                                href={t.attachmentUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-blue-600 hover:text-blue-500 text-sm font-medium"
                              >
                                View
                              </a>
                            ) : (
                              <span className="text-gray-400 text-sm">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              t.status === 'OPEN' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {t.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <select
                              defaultValue={t.status}
                              onChange={(e) => updateTicket(t.id, e.target.value as 'OPEN' | 'CLOSED')}
                              className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                            >
                              <option value="OPEN">OPEN</option>
                              <option value="CLOSED">CLOSED</option>
                            </select>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* User Detail Modal */}
      {detailOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-6xl my-8">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">Manage User</h2>
                <p className="text-sm text-gray-600 mt-1">Detailed user information and management</p>
              </div>
              <button
                onClick={() => setDetailOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {!detail ? (
              <div className="p-12 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-4 text-gray-500">Loading user details...</p>
              </div>
            ) : (
              <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 max-h-[70vh] overflow-y-auto">
                {/* Left Column - Profile Info */}
                <div className="space-y-6">
                  {/* Profile Card */}
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-3">Profile Information</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                        <input
                          id="profile-name"
                          defaultValue={detail.name}
                          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input
                          disabled
                          value={detail.email}
                          className="w-full rounded-lg border-gray-300 bg-gray-100 text-gray-600 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <input
                          id="profile-phone"
                          defaultValue={detail.phone || ''}
                          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Role</label>
                        <select
                          id="profile-role"
                          defaultValue={detail.role}
                          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                        >
                          <option>USER</option>
                          <option>ADMIN</option>
                        </select>
                      </div>
                      <button
                        onClick={() => saveProfile(detail.id)}
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition-colors"
                      >
                        Save Profile
                      </button>
                    </div>
                    <div className="mt-4 pt-4 border-t border-gray-200 text-xs text-gray-500">
                      Joined: {new Date(detail.createdAt).toLocaleString()}
                    </div>
                  </div>

                  {/* Subscription Card */}
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-3">Subscription</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Plan:</span>
                        <span className="font-medium">{detail.subscription?.plan || 'FREE'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Status:</span>
                        <span className={`font-medium ${
                          detail.subscription?.status === 'ACTIVE' ? 'text-green-600' : 
                          detail.subscription?.status === 'CANCELED' ? 'text-red-600' : 'text-yellow-600'
                        }`}>
                          {detail.subscription?.status || 'ACTIVE'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Period End:</span>
                        <span className="font-medium">
                          {detail.subscription?.currentPeriodEnd ? 
                            new Date(detail.subscription.currentPeriodEnd).toLocaleDateString() : '—'
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Middle Column - KYC */}
                <div className="space-y-6">
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-3">KYC Verification</h3>
                    <div className="space-y-3">
                      <div>
                        <span className="text-sm text-gray-600">Current Status:</span>
                        <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                          detail.kyc?.status === 'APPROVED' ? 'bg-green-100 text-green-800' :
                          detail.kyc?.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                          detail.kyc?.status === 'REJECTED' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {detail.kyc?.status || 'NOT_SUBMITTED'}
                        </span>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Update Status</label>
                        <select
                          id="kyc-status"
                          defaultValue={detail.kyc?.status || 'NOT_SUBMITTED'}
                          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                        >
                          <option>NOT_SUBMITTED</option>
                          <option>PENDING</option>
                          <option>APPROVED</option>
                          <option>REJECTED</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Admin Note</label>
                        <input
                          id="kyc-note"
                          placeholder="Add a note..."
                          defaultValue={detail.kyc?.adminNote || ''}
                          className="w-full rounded-lg border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm"
                        />
                      </div>
                      <button
                        onClick={() => updateKyc(detail.id)}
                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition-colors"
                      >
                        Update KYC
                      </button>
                      {(detail.kyc?.documentUrl || detail.kyc?.selfieUrl) && (
                        <div className="pt-3 border-t border-gray-200">
                          <h4 className="text-sm font-medium text-gray-700 mb-2">Documents</h4>
                          <div className="space-y-2">
                            {detail.kyc?.documentUrl && (
                              <a
                                href={detail.kyc.documentUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center text-blue-600 hover:text-blue-500 text-sm"
                              >
                                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                </svg>
                                View Document
                              </a>
                            )}
                            {detail.kyc?.selfieUrl && (
                              <a
                                href={detail.kyc.selfieUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center text-blue-600 hover:text-blue-500 text-sm"
                              >
                                <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                </svg>
                                View Selfie
                              </a>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Column - Activity & Transactions */}
                <div className="lg:col-span-1 space-y-6">
                  {/* Activity Logs */}
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-3">Recent Activity</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto">
                      {logs.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">No activity logs</p>
                      ) : (
                        logs.map((log) => (
                          <div key={log.id} className="text-sm border-l-2 border-blue-500 pl-3 py-1">
                            <div className="font-medium text-gray-900">{log.type}</div>
                            <div className="text-gray-600 text-xs">{log.message || '—'}</div>
                            <div className="text-gray-400 text-xs mt-1">
                              {new Date(log.createdAt).toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Transactions */}
                  <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-3">Recent Transactions</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto">
                      {txs.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">No transactions</p>
                      ) : (
                        txs.map((t) => (
                          <div key={t.id} className="text-sm border-l-2 border-green-500 pl-3 py-1">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="font-medium text-gray-900">{t.purpose}</div>
                                <div className="text-gray-600 text-xs">₹{t.amount}</div>
                              </div>
                              <select
                                defaultValue={t.status}
                                onChange={(e) => updateTxStatus(t.id, e.target.value as any)}
                                className="text-xs rounded border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              >
                                <option>Pending</option>
                                <option>Success</option>
                                <option>Failed</option>
                              </select>
                            </div>
                            <div className="text-gray-400 text-xs mt-1">
                              {new Date(t.createdAt).toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}