"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useMemo } from 'react'
import { useSession } from 'next-auth/react'
import { signOut } from 'next-auth/react'

export default function Sidebar() {
  const pathname = usePathname()
  const { data: session } = useSession()
  const role = (session?.user as any)?.role
  const nav = useMemo(() => {
    const items: any[] = [
      { label: 'Dashboard', href: '/account' },
      { label: 'Payment Link', children: [
        { label: 'Default Link', href: '/account/payment-link/default' },
        { label: 'Custom Link', href: '/account/payment-link/custom' },
      ]},
      { label: 'Smart Route', children: [
        { label: 'Add UPI', href: '/account/smart-route/add-upi' },
        { label: 'Add Bank', href: '/account/smart-route/add-bank' },
      ]},
      { label: 'Checkout Settings', href: '/account/checkout-settings' },
      { label: 'Developer', href: '/account/developer' },
    ]
    if (role === 'ADMIN') items.push({ label: 'Admin', href: '/admin' })
    items.push(
      { label: 'Subscription', href: '/account/subscription' },
      { label: 'Profile', href: '/account/profile' },
      { label: 'Support', href: '/account/support' },
      { label: 'Logout', action: 'logout' },
    )
    return items
  }, [role])

  function isActive(href: string) {
    if (href === '/account') return pathname === '/account'
    return pathname?.startsWith(href)
  }

  return (
    <aside className="w-64 shrink-0">
      <div className="glass rounded-xl p-4 sticky top-4">
        {/* <div className="mb-4">
          <Link href="/" className="font-semibold text-slate-800">Payatupi</Link>
        </div> */}
        <nav className="space-y-2 text-sm">
          {nav.map((item) => (
            <div key={item.label}>
              {item.action === 'logout' ? (
                <button
                  onClick={() => signOut({ callbackUrl: '/login' })}
                  className={`block w-full text-left rounded-lg px-3 py-2 transition hover:bg-white/60 text-slate-700`}
                >
                  {item.label}
                </button>
              ) : item.href ? (
                <Link
                  href={item.href}
                  className={`block rounded-lg px-3 py-2 transition ${isActive(item.href) ? 'bg-slate-900 text-white' : 'hover:bg-white/60 text-slate-700'}`}
                >
                  {item.label}
                </Link>
              ) : (
                <div className="px-3 py-2 text-slate-500 uppercase tracking-wide text-xs">{item.label}</div>
              )}
              {item.children && (
                <div className="mt-1 ml-2 space-y-1">
                  {item.children.map((child: any) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      className={`block rounded-md px-3 py-2 transition ${isActive(child.href) ? 'bg-slate-900 text-white' : 'hover:bg-white/60 text-slate-700'}`}
                    >
                      {child.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </aside>
  )
}
