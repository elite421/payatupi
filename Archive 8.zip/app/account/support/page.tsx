"use client"

import { useEffect, useState, FormEvent } from "react"

type Ticket = { id: string; subject: string; message: string; status: 'OPEN'|'CLOSED'; createdAt: string }

export default function SupportPage(){
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  async function load() {
    setLoading(true)
    const r = await fetch('/api/support/tickets')
    setLoading(false)
    if (r.ok) setTickets(await r.json())
  }

  useEffect(() => { load() }, [])

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    const fd = new FormData(e.currentTarget)
    const payload = { subject: String(fd.get('subject') || ''), message: String(fd.get('message') || '') }
    const r = await fetch('/api/support/tickets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (r.ok) { (e.target as HTMLFormElement).reset(); await load() }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">Support</h1>
      <p className="mt-2 text-slate-600">Get help, contact support, and explore docs.</p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4 glass rounded-xl p-6">
        <div>
          <label className="text-sm text-slate-700">Subject</label>
          <input name="subject" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="text-sm text-slate-700">Message</label>
          <textarea name="message" className="mt-1 w-full rounded-lg border px-3 py-2" rows={4} required />
        </div>
        <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Submitting...' : 'Submit Ticket'}</button>
      </form>

      <div className="mt-8">
        <h2 className="font-semibold">Your Tickets</h2>
        {loading ? (
          <div className="mt-3 text-sm text-slate-600">Loading...</div>
        ) : tickets.length === 0 ? (
          <div className="mt-3 text-sm text-slate-600">No tickets yet.</div>
        ) : (
          <ul className="mt-3 divide-y rounded-lg border glass rounded-xl p-6">
            {tickets.map(t => (
              <li key={t.id} className="px-4 py-3">
                <div className="flex items-center justify-between">
                  <div className="font-medium">{t.subject}</div>
                  <div className="text-xs rounded bg-slate-100 px-2 py-1">{t.status}</div>
                </div>
                <div className="text-sm text-slate-600 mt-1 whitespace-pre-wrap">{t.message}</div>
                <div className="text-xs text-slate-500 mt-1">{new Date(t.createdAt).toLocaleString()}</div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
