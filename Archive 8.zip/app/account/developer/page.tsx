"use client"

import { useEffect, useState, FormEvent } from "react"
import { 
  ClipboardDocumentIcon, 
  KeyIcon, 
  LinkIcon, 
  DocumentArrowDownIcon,
  CloudArrowUpIcon,
  CodeBracketIcon,
  PlusIcon,
  TrashIcon,
  ArrowPathIcon,
  ExclamationTriangleIcon,
  CheckCircleIcon,
  InformationCircleIcon
} from "@heroicons/react/24/outline"

type Key = { id: string; prefix: string; revoked: boolean; createdAt: string; lastUsedAt?: string | null }
type Sub = { plan: string; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null }
type Profile = { id: string; publicId?: string | null; name: string; email: string; phone?: string | null }
type Webhook = { id: string; url: string; secret?: string | null; createdAt: string }
type AllowedIp = { id: string; ip: string; label?: string | null; createdAt: string }

export default function DeveloperPage(){
  const [keys, setKeys] = useState<Key[]>([])
  const [profile, setProfile] = useState<Profile | null>(null)
  const [sub, setSub] = useState<Sub | null>(null)
  const [creating, setCreating] = useState(false)
  const [newKey, setNewKey] = useState<string | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [resetOpen, setResetOpen] = useState(false)
  const [hooks, setHooks] = useState<Webhook[]>([])
  const [hookMsg, setHookMsg] = useState<string | null>(null)
  const [base, setBase] = useState<string>('')
  const [activeTab, setActiveTab] = useState<'credentials' | 'api' | 'webhooks'>('credentials')
  const [allowedIps, setAllowedIps] = useState<AllowedIp[]>([])
  const [ipMsg, setIpMsg] = useState<string | null>(null)
  const [keysFilter, setKeysFilter] = useState<'all'|'active'|'revoked'>('active')

  function isActiveSubscription(s: Sub | null){
    if (!s) return false
    if (s.status !== 'ACTIVE') return false
    if (String(s.plan).toUpperCase() === 'FREE') return false
    const end = s.currentPeriodEnd ? new Date(s.currentPeriodEnd) : null
    if (end && end.getTime() <= Date.now()) return false
    return true
  }

  async function load() {
    const [pr, sr, kr, wr, ir] = await Promise.all([
      fetch('/api/profile'),
      fetch('/api/subscription'),
      fetch('/api/developer/api-keys'),
      fetch('/api/developer/webhooks'),
      fetch('/api/developer/allowed-ips'),
    ])
    if (pr.ok) setProfile(await pr.json())
    if (sr.ok) setSub(await sr.json())
    if (kr.ok) setKeys(await kr.json())
    if (wr.ok) setHooks(await wr.json())
    if (ir.ok) setAllowedIps(await ir.json())
  }

  useEffect(() => { load() }, [])
  useEffect(() => { 
    try { 
      if (typeof window !== 'undefined') setBase(window.location.origin) 
    } catch {} 
  }, [])

  async function createKey() {
    setCreating(true)
    setMsg(null)
    const r = await fetch('/api/developer/api-keys', { method: 'POST' })
    setCreating(false)
    if (r.ok) {
      const data = await r.json()
      setNewKey(data.key)
      await load()
      setMsg('API key created successfully')
    } else {
      const d = await r.json().catch(() => ({} as any))
      setMsg(d?.error === 'ip_required' ? 'Add at least one allowed IP to create an API key' : 'Failed to create API key')
    }
  }

  async function resetSecret() {
    setResetOpen(false)
    setMsg(null)
    const r = await fetch('/api/developer/api-keys/reset', { method: 'POST' })
    if (r.ok) {
      const data = await r.json()
      setNewKey(data.key)
      await load()
      setMsg('Secret key reset successfully')
    } else {
      const d = await r.json().catch(() => ({} as any))
      setMsg(d?.error === 'ip_required' ? 'Add at least one allowed IP to reset the secret key' : 'Failed to reset secret key')
    }
  }

  async function revokeKey(keyId: string) {
    const r = await fetch(`/api/developer/api-keys/${keyId}`, { method: 'DELETE' })
    if (r.ok) {
      await load()
      setMsg('API key revoked')
    }
  }

  async function deleteWebhook(hookId: string) {
    const r = await fetch(`/api/developer/webhooks/${hookId}`, { method: 'DELETE' })
    if (r.ok) {
      await load()
      setHookMsg('Webhook deleted')
    }
  }

  async function addAllowedIp(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setIpMsg(null)
    const fd = new FormData(e.currentTarget)
    const ip = String(fd.get('ip') || '').trim()
    const label = String(fd.get('label') || '').trim()
    if (!ip) { setIpMsg('Enter a valid IP'); return }
    const r = await fetch('/api/developer/allowed-ips', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ip, label })
    })
    if (r.ok) {
      setIpMsg('IP added')
      e.currentTarget.reset()
      await load()
    } else {
      const d = await r.json().catch(()=>({ error: 'Failed to add IP' }))
      setIpMsg(d.error || 'Failed to add IP')
    }
  }

  async function removeAllowedIp(id: string) {
    setIpMsg(null)
    const r = await fetch(`/api/developer/allowed-ips/${id}`, { method: 'DELETE' })
    if (r.status === 204) {
      setIpMsg('IP removed')
      await load()
    }
  }

  function downloadKeys(){
    const lines = keys.map(k => `${k.prefix}••••••••\tCreated: ${new Date(k.createdAt).toISOString()}${k.revoked? '\tStatus: Revoked':''}${k.lastUsedAt ? `\tLast Used: ${new Date(k.lastUsedAt).toISOString()}` : ''}`)
    const blob = new Blob([lines.join('\n') || 'No API keys'], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'api-keys-backup.txt'
    a.click()
    URL.revokeObjectURL(url)
  }

  function downloadPlugin(){
    setMsg('WooCommerce plugin download not available yet')
  }

  const acctId = profile?.publicId || profile?.id || '—'
  const active = isActiveSubscription(sub)
  const plan = String(sub?.plan || '').toUpperCase()
  const enterprise = active && (plan === 'ENTERPRISE' || plan === 'ENTERPRISE_PLUS' || plan === 'BUSINESS')
  const apiAccess = enterprise ? 'Active' : 'Inactive'
  const filteredKeys = keysFilter === 'all' ? keys : keys.filter(k => keysFilter === 'active' ? !k.revoked : k.revoked)

  // Copy to clipboard utility
  const copyToClipboard = async (text: string, successMessage: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setMsg(successMessage)
      setTimeout(() => setMsg(null), 2000)
    } catch {}
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Developer Dashboard</h1>
        <p className="mt-2 text-gray-600">Manage your API credentials, webhooks, and integration settings</p>
      </div>

      {/* Status Banner */}
      {msg && (
        <div className="mb-6 p-4 rounded-lg bg-green-50 border border-green-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircleIcon className="w-5 h-5 text-green-600" />
            <span className="text-green-700">{msg}</span>
          </div>
          <button onClick={() => setMsg(null)} className="text-green-600 hover:text-green-800">
            ×
          </button>
        </div>
      )}

      {/* Subscription Warning */}
      {!enterprise && (
        <div className="mb-6 p-4 rounded-lg bg-amber-50 border border-amber-200">
          <div className="flex items-start gap-3">
            <ExclamationTriangleIcon className="w-5 h-5 text-amber-600 mt-0.5" />
            <div>
              <p className="font-medium text-amber-800">API Access Limited</p>
              <p className="text-amber-700 text-sm mt-1">
                Upgrade to an Enterprise, Enterprise Plus, or Business plan to access API features.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="mb-8 border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('credentials')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${activeTab === 'credentials' 
              ? 'border-blue-500 text-blue-600' 
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            <div className="flex items-center gap-2">
              <KeyIcon className="w-4 h-4" />
              Credentials
            </div>
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${activeTab === 'api' 
              ? 'border-blue-500 text-blue-600' 
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            <div className="flex items-center gap-2">
              <CodeBracketIcon className="w-4 h-4" />
              API Reference
            </div>
          </button>
          <button
            onClick={() => setActiveTab('webhooks')}
            className={`py-2 px-1 border-b-2 font-medium text-sm ${activeTab === 'webhooks' 
              ? 'border-blue-500 text-blue-600' 
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            <div className="flex items-center gap-2">
              <CloudArrowUpIcon className="w-4 h-4" />
              Webhooks
            </div>
          </button>
        </nav>
      </div>

      {/* Main Content */}
      <div className="space-y-8">
        {/* Credentials Tab */}
        {activeTab === 'credentials' && (
          <div className="space-y-8">
            {/* Account Information Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Account Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Account ID</label>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 bg-gray-50 px-3 py-2 rounded-md text-sm font-mono break-all">
                        {acctId}
                      </code>
                      <button
                        onClick={() => copyToClipboard(acctId, 'Account ID copied')}
                        className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md"
                        title="Copy Account ID"
                      >
                        <ClipboardDocumentIcon className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">API Access</label>
                    <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${apiAccess === 'Active' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'}`}>
                      {apiAccess}
                    </div>
                    {!enterprise && (
                      <p className="mt-1 text-xs text-gray-500">
                        Upgrade your plan to enable API access
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">SMS Callback URL</label>
                    <div className="flex items-center gap-2">
                      <code className="flex-1 bg-gray-50 px-3 py-2 rounded-md text-sm font-mono break-all">
                        {`${base}/api/sms/callback/${acctId}`}
                      </code>
                      <button
                        onClick={() => copyToClipboard(`${base}/api/sms/callback/${acctId}`, 'Callback URL copied')}
                        className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md"
                        title="Copy Callback URL"
                      >
                        <ClipboardDocumentIcon className="w-5 h-5" />
                      </button>
                    </div>
                    <p className="mt-2 text-xs text-gray-500">
                      Android app sends UTR updates to this endpoint. Enable automation in Checkout Settings.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* API Keys Management */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-gray-900">API Keys Management</h2>
                <div className="flex items-center gap-3">
                  <button
                    onClick={downloadKeys}
                    disabled={!enterprise || keys.length === 0}
                    className="inline-flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <DocumentArrowDownIcon className="w-4 h-4" />
                    Export Keys
                  </button>
                  <button
                    onClick={createKey}
                    disabled={creating || !enterprise || allowedIps.length === 0}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <PlusIcon className="w-4 h-4" />
                    {creating ? 'Creating...' : 'New API Key'}
                  </button>
                </div>
              </div>

              {enterprise && allowedIps.length === 0 && (
                <div className="mb-4 p-3 rounded-md bg-amber-50 border border-amber-200 text-amber-800 text-sm">
                  Add at least one Allowed IP to enable creating or resetting API keys.
                </div>
              )}

              {/* New Key Display */}
              {newKey && (
                <div className="mb-6 p-4 rounded-lg bg-blue-50 border border-blue-200">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-blue-800 flex items-center gap-2">
                        <InformationCircleIcon className="w-5 h-5" />
                        New API Key Generated
                      </p>
                      <p className="text-blue-700 text-sm mt-1 mb-2">
                        Copy this key now. It won't be shown again.
                      </p>
                      <code className="block bg-white px-3 py-2 rounded border border-blue-300 text-sm font-mono break-all">
                        {newKey}
                      </code>
                    </div>
                    <button
                      onClick={() => copyToClipboard(newKey, 'API key copied')}
                      className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-md"
                    >
                      <ClipboardDocumentIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Keys List */}
              <div className="flex items-center justify-between mb-3">
                <div className="inline-flex rounded-md shadow-sm border border-gray-200 overflow-hidden" role="group">
                  <button onClick={() => setKeysFilter('active')} className={`px-3 py-1.5 text-sm ${keysFilter==='active' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>Active</button>
                  <button onClick={() => setKeysFilter('revoked')} className={`px-3 py-1.5 text-sm border-l border-gray-200 ${keysFilter==='revoked' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>Revoked</button>
                  <button onClick={() => setKeysFilter('all')} className={`px-3 py-1.5 text-sm border-l border-gray-200 ${keysFilter==='all' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}>All</button>
                </div>
              </div>
              <div className="overflow-hidden rounded-lg border border-gray-200">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Key Prefix
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Created
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Used
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredKeys.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                          <KeyIcon className="w-12 h-12 mx-auto text-gray-300" />
                          <p className="mt-2">{keysFilter === 'active' ? 'No active API keys' : keysFilter === 'revoked' ? 'No revoked keys' : 'No API keys created yet'}</p>
                          {!enterprise && (
                            <p className="text-sm text-gray-400 mt-1">
                              Upgrade your plan to create API keys
                            </p>
                          )}
                        </td>
                      </tr>
                    ) : (
                      filteredKeys.map((key) => (
                        <tr key={key.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <code className="text-sm font-mono">{key.prefix}••••••••</code>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(key.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {key.lastUsedAt ? new Date(key.lastUsedAt).toLocaleDateString() : 'Never'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${key.revoked 
                              ? 'bg-red-100 text-red-800' 
                              : 'bg-green-100 text-green-800'}`}>
                              {key.revoked ? 'Revoked' : 'Active'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            {!key.revoked && (
                              <button
                                onClick={() => revokeKey(key.id)}
                                className="text-red-600 hover:text-red-900"
                              >
                                Revoke
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Security Settings */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Security Settings</h2>
              <div className="space-y-6">
                <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200">
                  <div>
                    <h3 className="font-medium text-gray-900">Secret Key</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Rotate your master secret key. This will affect all existing integrations.
                    </p>
                  </div>
                  <button
                    onClick={() => setResetOpen(true)}
                    disabled={!enterprise || allowedIps.length === 0}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md border border-gray-300 text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ArrowPathIcon className="w-4 h-4" />
                    Reset Secret Key
                  </button>
                </div>

                <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200">
                  <div>
                    <h3 className="font-medium text-gray-900">WooCommerce Plugin</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      Download our official WooCommerce payment gateway plugin.
                    </p>
                  </div>
                  <button
                    onClick={downloadPlugin}
                    disabled={!enterprise}
                    className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md bg-gray-900 text-white hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <DocumentArrowDownIcon className="w-4 h-4" />
                    Download Plugin
                  </button>
                </div>

                <div className="p-4 rounded-lg border border-gray-200">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">IP Allowlist</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        API requests are allowed only from the IPs you add here. You must add at least one IP before creating or using API keys.
                      </p>
                    </div>
                  </div>

                  <form onSubmit={addAllowedIp} className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                    <input
                      name="ip"
                      type="text"
                      placeholder="e.g. 203.0.113.42"
                      className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"
                      disabled={!enterprise}
                      required
                    />
                    <input
                      name="label"
                      type="text"
                      placeholder="Optional label (office, server)"
                      className="px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"
                      disabled={!enterprise}
                    />
                    <button
                      type="submit"
                      disabled={!enterprise}
                      className="inline-flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <PlusIcon className="w-4 h-4" />
                      Add IP
                    </button>
                  </form>

                  {ipMsg && (
                    <div className={`mt-3 p-3 rounded-md text-sm ${ipMsg.includes('added') || ipMsg.includes('removed') ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                      {ipMsg}
                    </div>
                  )}

                  <div className="mt-4 overflow-hidden rounded-lg border border-gray-200">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IP</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Label</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Added</th>
                          <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {allowedIps.length === 0 ? (
                          <tr>
                            <td className="px-4 py-6 text-center text-gray-500" colSpan={4}>No IPs added</td>
                          </tr>
                        ) : (
                          allowedIps.map((rec) => (
                            <tr key={rec.id}>
                              <td className="px-4 py-2 font-mono text-sm text-gray-900">{rec.ip}</td>
                              <td className="px-4 py-2 text-sm text-gray-600">{rec.label || '—'}</td>
                              <td className="px-4 py-2 text-sm text-gray-600">{new Date(rec.createdAt).toLocaleDateString()}</td>
                              <td className="px-4 py-2 text-sm">
                                <button
                                  onClick={() => removeAllowedIp(rec.id)}
                                  disabled={!enterprise}
                                  className="inline-flex items-center gap-1 text-red-600 hover:text-red-800 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  <TrashIcon className="w-4 h-4" />
                                  Remove
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* API Reference Tab */}
        {activeTab === 'api' && (
          <div className="space-y-8">
            {/* Create Payment Request */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <CodeBracketIcon className="w-5 h-5" />
                Create Payment Request
              </h2>
              <p className="text-gray-600 mb-6">
                Initialize a new payment request via API. Customers will be redirected to your specified URL.
              </p>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Endpoint</h3>
                  <code className="block bg-gray-900 text-gray-100 px-4 py-3 rounded-md text-sm font-mono">
                    POST {base}/api/api_payment_init
                  </code>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Request Parameters</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm border border-gray-200 rounded-lg">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-2 text-left font-medium text-gray-700 border-b">Parameter</th>
                          <th className="px-4 py-2 text-left font-medium text-gray-700 border-b">Type</th>
                          <th className="px-4 py-2 text-left font-medium text-gray-700 border-b">Required</th>
                          <th className="px-4 py-2 text-left font-medium text-gray-700 border-b">Description</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {[
                          { param: 'account_id', type: 'string', required: 'Yes', desc: 'Your account ID' },
                          { param: 'secret_key', type: 'string', required: 'Yes', desc: 'Your secret key' },
                          { param: 'payment_id', type: 'string', required: 'Yes', desc: 'Unique payment identifier' },
                          { param: 'payment_purpose', type: 'string', required: 'No', desc: 'Payment description (max 30 chars)' },
                          { param: 'payment_amount', type: 'number', required: 'Yes', desc: 'Amount (1-100000)' },
                          { param: 'payment_name', type: 'string', required: 'No', desc: 'Customer name (3-30 chars)' },
                          { param: 'payment_phone', type: 'string', required: 'No', desc: 'Customer phone (7-15 digits)' },
                          { param: 'payment_email', type: 'string', required: 'No', desc: 'Valid email address' },
                          { param: 'redirect_url', type: 'string', required: 'Yes', desc: 'Callback URL after payment' },
                        ].map((row) => (
                          <tr key={row.param}>
                            <td className="px-4 py-2 font-mono text-gray-900">{row.param}</td>
                            <td className="px-4 py-2 text-gray-600">{row.type}</td>
                            <td className="px-4 py-2">
                              <span className={`px-2 py-1 rounded text-xs ${row.required === 'Yes' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'}`}>
                                {row.required}
                              </span>
                            </td>
                            <td className="px-4 py-2 text-gray-600">{row.desc}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">PHP Example</h3>
                  <pre className="bg-gray-50 rounded-lg p-4 overflow-x-auto text-sm">
                    <code>{`<?php
$url = "${base}/api/api_payment_init";
$data = [
    "account_id" => "your_account_id",
    "secret_key" => "your_secret_key",
    "payment_id" => "unique_payment_123",
    "payment_purpose" => "Order #123",
    "payment_amount" => 5000,
    "payment_name" => "John Doe",
    "payment_phone" => "9876543210",
    "payment_email" => "john@example.com",
    "redirect_url" => "https://yourstore.com/thank-you"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["init_payment" => $data]));
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

$response = json_decode($result, true);
print_r($response);
?>`}</code>
                  </pre>
                </div>
              </div>
            </div>

            {/* Get Payment Status */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Get Payment Status</h2>
              <p className="text-gray-600 mb-6">
                Retrieve payment details for verification. Use this in your callback endpoint.
              </p>

              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">Endpoint</h3>
                  <code className="block bg-gray-900 text-gray-100 px-4 py-3 rounded-md text-sm font-mono">
                    POST {base}/api/api_payment_status
                  </code>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-800 mb-2 flex items-center gap-2">
                    <InformationCircleIcon className="w-5 h-5" />
                    Implementation Tip
                  </h4>
                  <p className="text-blue-700 text-sm">
                    When customers are redirected to your callback URL (e.g., https://yourstore.com/callback?payment_id=123),
                    include this API call to verify and retrieve payment details.
                  </p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-700 mb-2">PHP Example</h3>
                  <pre className="bg-gray-50 rounded-lg p-4 overflow-x-auto text-sm">
                    <code>{`<?php
$url = "${base}/api/api_payment_status";
$data = [
    "account_id" => "your_account_id",
    "secret_key" => "your_secret_key",
    "payment_id" => $_GET['payment_id'] // Get from callback URL
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["fetch_payment" => $data]));
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch);
curl_close($ch);

$payment = json_decode($result, true);
if ($payment['status'] === 'SUCCESS') {
    // Payment successful, update your database
    echo "Payment completed successfully";
} else {
    // Payment failed or pending
    echo "Payment status: " . $payment['status'];
}
?>`}</code>
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Webhooks Tab */}
        {activeTab === 'webhooks' && (
          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Webhook Configuration</h2>
                  <p className="text-gray-600 mt-1">
                    Receive real-time notifications for payment events on your server.
                  </p>
                </div>
                <div className="text-sm text-gray-500">
                  {hooks.length} webhook{hooks.length !== 1 ? 's' : ''} configured
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Add Webhook Form */}
                <div className="lg:col-span-1">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="font-medium text-gray-900 mb-4 flex items-center gap-2">
                      <PlusIcon className="w-5 h-5" />
                      Add New Webhook
                    </h3>
                    <form
                      onSubmit={async (e: FormEvent<HTMLFormElement>) => {
                        e.preventDefault()
                        setHookMsg(null)
                        const fd = new FormData(e.currentTarget)
                        const payload = { 
                          url: String(fd.get('url') || ''), 
                          secret: String(fd.get('secret') || '') 
                        }
                        const r = await fetch('/api/developer/webhooks', { 
                          method: 'POST', 
                          headers: { 'Content-Type': 'application/json' }, 
                          body: JSON.stringify(payload) 
                        })
                        if (r.ok) {
                          setHookMsg('Webhook added successfully')
                          e.currentTarget.reset()
                          await load()
                        } else {
                          const d = await r.json().catch(() => ({ error: 'Failed to add webhook' }))
                          setHookMsg(d.error || 'Failed to add webhook')
                        }
                      }}
                      className="space-y-4"
                    >
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Webhook URL *
                        </label>
                        <input
                          name="url"
                          type="url"
                          placeholder="https://your-server.com/webhooks/payments"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"
                          disabled={!enterprise}
                          required
                        />
                        <p className="mt-1 text-xs text-gray-500">
                          Must be a valid HTTPS endpoint
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Secret Key (Optional)
                        </label>
                        <input
                          name="secret"
                          type="text"
                          placeholder="your_webhook_secret"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"
                          disabled={!enterprise}
                        />
                        <p className="mt-1 text-xs text-gray-500">
                          Used to verify webhook authenticity
                        </p>
                      </div>

                      {hookMsg && (
                        <div className={`p-3 rounded-md text-sm ${hookMsg.includes('success') 
                          ? 'bg-green-50 text-green-700' 
                          : 'bg-red-50 text-red-700'}`}>
                          {hookMsg}
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={!enterprise}
                        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Add Webhook
                      </button>
                    </form>
                  </div>
                </div>

                {/* Webhooks List */}
                <div className="lg:col-span-2">
                  <h3 className="font-medium text-gray-900 mb-4">Configured Webhooks</h3>
                  {hooks.length === 0 ? (
                    <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
                      <CloudArrowUpIcon className="w-12 h-12 mx-auto text-gray-400" />
                      <p className="mt-4 text-gray-500">No webhooks configured</p>
                      <p className="text-sm text-gray-400 mt-1">
                        Add a webhook to receive payment notifications
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {hooks.map((hook) => (
                        <div key={hook.id} className="border border-gray-200 rounded-lg p-4 hover:border-gray-300">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <LinkIcon className="w-4 h-4 text-gray-400" />
                                <code className="text-sm font-mono bg-gray-50 px-2 py-1 rounded">
                                  {hook.url}
                                </code>
                              </div>
                              <div className="flex items-center gap-4 text-xs text-gray-500">
                                <span>Created: {new Date(hook.createdAt).toLocaleDateString()}</span>
                                {hook.secret && (
                                  <span className="inline-flex items-center gap-1">
                                    <KeyIcon className="w-3 h-3" />
                                    Has secret
                                  </span>
                                )}
                              </div>
                            </div>
                            <button
                              onClick={() => deleteWebhook(hook.id)}
                              className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-md"
                              title="Delete webhook"
                            >
                              <TrashIcon className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Webhook Events Documentation */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="font-medium text-gray-900 mb-4">Webhook Events</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm border border-gray-200 rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left font-medium text-gray-700 border-b">Event</th>
                      <th className="px-4 py-3 text-left font-medium text-gray-700 border-b">Description</th>
                      <th className="px-4 py-3 text-left font-medium text-gray-700 border-b">Payload</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {[
                      {
                        event: 'payment.completed',
                        desc: 'Payment successfully completed',
                        payload: 'payment_id, amount, customer_info, timestamp'
                      },
                      {
                        event: 'payment.failed',
                        desc: 'Payment failed or was declined',
                        payload: 'payment_id, error_code, error_message, timestamp'
                      },
                      {
                        event: 'payment.refunded',
                        desc: 'Payment was refunded',
                        payload: 'payment_id, refund_amount, refund_reason, timestamp'
                      },
                      {
                        event: 'payment.expired',
                        desc: 'Payment request expired',
                        payload: 'payment_id, created_at, expired_at'
                      }
                    ].map((row) => (
                      <tr key={row.event}>
                        <td className="px-4 py-3">
                          <span className="font-mono text-blue-600">{row.event}</span>
                        </td>
                        <td className="px-4 py-3 text-gray-600">{row.desc}</td>
                        <td className="px-4 py-3">
                          <code className="text-xs bg-gray-100 px-2 py-1 rounded">{row.payload}</code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Reset Secret Key Modal */}
      {resetOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-red-100 rounded-lg">
                  <ExclamationTriangleIcon className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Reset Secret Key</h3>
                  <p className="text-sm text-gray-500">This action cannot be undone</p>
                </div>
              </div>

              <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800">
                  <strong>Warning:</strong> Resetting your secret key will immediately invalidate all existing integrations using the current key. You will need to update all your applications with the new key.
                </p>
              </div>

              <div className="flex justify-end gap-3">
                <button
                  onClick={() => setResetOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
                >
                  Cancel
                </button>
                <button
                  onClick={resetSecret}
                  className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-md"
                >
                  Reset Secret Key
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}