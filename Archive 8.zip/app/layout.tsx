import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import "./brand.css"
import ConditionalLayout from "@/components/conditional_nav";
import Background from "@/components/Background";
import Providers from "@/components/Providers";
import ErrorBoundary from "@/components/ErrorBoundary";


const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://app.payatupi.com'),
  title: {
    default: "Payatupi",
    template: "%s | Payatupi",
  },
  description: "Accept free and unlimited online payments with instant bank settlement with Payatupi.",
  keywords: [
    "UPI payment gateway",
    "UPI payment link",
    "free payment gateway",
    "NEFT",
    "IMPS",
    "payment gateway",
    "best payment gateway",
    "India payments",
  ],
  authors: [{ name: "Payatupi" }],
  creator: "Payatupi",
  publisher: "Payatupi",
  alternates: { canonical: "/" },
  openGraph: {
    title: "Payatupi — UPI Payment Gateway",
    description: "Accept free and unlimited online payments with instant bank settlement with Payatupi.",
    url: "https://aap.payatupi.com",
    siteName: "Payatupi",
    images: [
      { url: "/app.png", width: 1200, height: 630, alt: "Payatupi" },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Payatupi — UPI Payment Gateway",
    description: "Accept free and unlimited online payments with instant bank settlement with Payatupi.",
    images: ["/app.png"],
    creator: "@payatupi",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      noimageindex: false,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: "/icon.png",        // for normal browsers
    shortcut: "/icon.png",    // for old browsers
    apple: "/icon.png",       // for iOS devices
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: 'cover',
  themeColor: '#0a0a0a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen`}
      >
       <Background />
       <Providers>
         <ErrorBoundary>
           {children}
         </ErrorBoundary>
       </Providers>
        
        
        
      </body>
    </html>
  );
}
