import { prisma } from '@/lib/prisma'
import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import AutoRefreshBill from '@/components/AutoRefreshBill'
import BillRedirectTimer from '@/components/BillRedirectTimer'

export const revalidate = 0

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: 'Receipt - Payatupi',
    description: 'Accept free and unlimited online payments with instant bank settlement with Payatupi.',
    keywords: [
      'UPI payment gateway',
      'UPI payment link',
      'UPI payment gateway plugin',
      'free payment gateway',
      'NEFT',
      'IMPS',
      'payment gateway',
      'best payment gateway',
    ],
  }
}

function formatDate(d: Date) {
  const pad = (n: number) => n.toString().padStart(2, '0')
  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)
  const year = d.getFullYear()
  let hours = d.getHours()
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12
  if (hours === 0) hours = 12
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())
  return { date: `${day}-${month}-${year}`, time: `${pad(hours)}:${minutes}:${seconds} ${ampm}` }
}

export default async function ReceiptPage({ params }: { params: Promise<{ paymentId: string }> }) {
  const { paymentId } = await params
  const tx = await prisma.transaction.findFirst({
    where: { purpose: { startsWith: `PID:${paymentId}` } },
    orderBy: { createdAt: 'desc' },
    select: { id: true, amount: true, status: true, mode: true, utr: true, purpose: true, createdAt: true, upiId: true },
  })
  if (!tx) return notFound()

  const when = formatDate(tx.createdAt)
  const amount = `₹ ${tx.amount}`
  const purpose = (tx.purpose || '').replace(/^PID:[^|]+\s*\|\s*/i, '').trim() || 'Payment'
  const mode = (tx.mode || '').toUpperCase() || 'UPI'
  const utr = tx.utr || '-'
  const upiId = tx.upiId || '-'
  const status = tx.status as 'Pending' | 'Success' | 'Failed'
  const createdAtIso = tx.createdAt.toISOString()

  const banner = status === 'Success'
    ? { text: 'Congratulations! Your transaction was successful.', cls: 'bg-green-50 text-green-700 border-green-200' }
    : status === 'Failed'
    ? { text: 'Your transaction has failed.', cls: 'bg-red-50 text-red-700 border-red-200' }
    : { text: 'Your transaction is pending.', cls: 'bg-yellow-50 text-yellow-700 border-yellow-200' }

  return (
    <div className="w-full min-h-screen bg-slate-50 flex items-start justify-center py-8 px-3">
      <div className="w-full max-w-2xl">
        <div className="mx-auto rounded-2xl bg-white shadow ring-1 ring-slate-200 overflow-hidden">
          <div className="p-6 border-b border-[#366870] bg-[#366870] text-white flex items-center gap-3">
            <div className="h-10 w-10 rounded-full flex items-center justify-center bg-white text-[#366870]">
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6M6 8h12M7 4h10a3 3 0 013 3v10a3 3 0 01-3 3H7a3 3 0 01-3-3V7a3 3 0 013-3z"/></svg>
            </div>
            <div className="flex-1">
              <div className="text-xl font-semibold">{purpose}</div>
              <div className="text-sm text-white/80">Payment ID : <span className="font-mono">{paymentId}</span></div>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <BillRedirectTimer paymentId={paymentId} seconds={30} />
              <AutoRefreshBill createdAt={createdAtIso} status={status} />
            </div>
          </div>

          <div className={`m-4 rounded-lg border p-3 text-sm ${banner.cls}`}>{banner.text}</div>

          <div className="p-6">
            <div className="text-base font-semibold mb-3">Payment Details</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
              <div className="text-slate-500">Date</div>
              <div className="text-slate-900">{when.date}</div>
              <div className="text-slate-500">Time</div>
              <div className="text-slate-900">{when.time}</div>
              <div className="text-slate-500">Purpose</div>
              <div className="text-slate-900">{purpose}</div>
              <div className="text-slate-500">Payment ID</div>
              <div className="text-slate-900 font-mono">{paymentId}</div>
              <div className="text-slate-500">Payment Mode</div>
              <div className="text-slate-900">{mode}</div>
              <div className="text-slate-500">UPI ID</div>
              <div className="text-slate-900 font-mono break-all">{upiId}</div>
              <div className="text-slate-500">Amount</div>
              <div className="text-slate-900 font-semibold">{amount}</div>
              <div className="text-slate-500">UTR</div>
              <div className="text-slate-900 font-mono break-all">{utr}</div>
              <div className="text-slate-500">Status</div>
              <div className="text-slate-900">{status}</div>
            </div>
          </div>
        </div>

        <p className="text-center text-sm text-slate-600 mt-6">
          Want to accept FREE and unlimited online payments with instant bank settlement?
          <br />
          <a className="text-[#366870] font-medium hover:underline" href="/login" target="_blank">Get started here</a>
        </p>
      </div>
    </div>
  )
}
