"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import Head from "next/head"
import Navbar from "@/components/Navbaar"

type Profile = { id: string; email: string; name: string; phone?: string | null; emailVerified?: boolean | null }

export default function TwoFactorPage(){
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const { data: session } = useSession()

  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const r = await fetch('/api/profile', { cache: 'no-store' })
        if (r.ok) {
          const d = await r.json()
          if (active) setProfile(d)
        }
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [])

  const displayName = (profile?.name || session?.user?.name || 'User').trim()

  return (
    <>
      <Head>
        <title>Two-Factor Authentication - Payatupi</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
      </Head>
      <Navbar/>

      <div className={`min-h-screen bg-gradient-to-br from-[#f5f7fa] to-[#e4edf5] font-sans transition-opacity duration-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
        <main className="max-w-7xl mx-auto px-6 py-8">
          <section className="mb-8">
            <div className="welcome-section mb-6">
              <div className="text-xl font-extrabold animate-[fadeGlow_3s_ease_infinite]" style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Welcome, {displayName}
              </div>
              <h4 className="text-gray-600 mt-1 font-medium">Two-Factor Authentication</h4>
            </div>

            <div className="max-w-2xl">
              <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4" style={{ borderTopColor: "#50bd49" }}>
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-gray-800">Two‑Factor Authentication</h1>
                  <p className="mt-2 text-gray-600">Strengthen account security. 2FA setup is coming soon.</p>
                </div>

                {loading ? (
                  <div className="flex justify-center items-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#50bd49]"></div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Status</div>
                          <div className="text-lg font-bold text-gray-800 mt-1">Disabled</div>
                        </div>
                        <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                          <i className="fas fa-shield-alt text-red-500 text-xl"></i>
                        </div>
                      </div>
                      <div className="mt-4 text-sm text-gray-600">
                        2FA is currently disabled. Enable it for enhanced security.
                      </div>
                    </div>

                    <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Email</div>
                          <div className="text-lg font-medium text-gray-800 mt-1">{profile?.email || '—'}</div>
                        </div>
                        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                          <i className="fas fa-envelope text-blue-500 text-xl"></i>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-semibold text-gray-500 uppercase tracking-wide">Email Verified</div>
                          <div className={`text-lg font-bold mt-1 ${profile?.emailVerified ? 'text-green-600' : 'text-red-600'}`}>
                            {profile?.emailVerified ? 'Verified' : 'Not Verified'}
                          </div>
                        </div>
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center ${profile?.emailVerified ? 'bg-green-100' : 'bg-red-100'}`}>
                          <i className={`fas ${profile?.emailVerified ? 'fa-check-circle text-green-500' : 'fa-times-circle text-red-500'} text-xl`}></i>
                        </div>
                      </div>
                      {!profile?.emailVerified && (
                        <div className="mt-4 text-sm text-gray-600">
                          Please verify your email address to enhance account security.
                        </div>
                      )}
                    </div>

                    <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl border border-blue-200 p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                          <i className="fas fa-info-circle text-white"></i>
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-800">Coming Soon</h3>
                          <p className="text-sm text-gray-600 mt-1">
                            Two-factor authentication features are currently under development. 
                            You'll be able to enable SMS, authenticator app, or email-based 2FA soon.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        </main>
      </div>

      <style jsx global>{`
        @keyframes fadeGlow {
          0% { filter: brightness(1); }
          50% { filter: brightness(1.15); }
          100% { filter: brightness(1); }
        }
      `}</style>
    </>
  )
}