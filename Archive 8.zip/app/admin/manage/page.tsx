import AdminPanel from '@/components/admin/AdminPanel'

export default function Page(){
  return (
    <AdminPanel defaultTab="manage" hideTabs />
  )
}
