import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'

export default async function AdminPage(){
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email) return redirect('/login')
  if (role !== 'ADMIN') return redirect('/account')
  return redirect('/admin/dashboard')
}
