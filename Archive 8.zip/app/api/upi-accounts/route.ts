import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const items = await prisma.uPIAccount.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
  return new Response(JSON.stringify(items), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { upiId, label, upiType } = body || {}
  if (!upiId) return new Response(JSON.stringify({ error: 'UPI ID required' }), { status: 400 })
  const normalizedType = typeof upiType === 'string' ? upiType.toUpperCase() : undefined
  const value: any = normalizedType === 'MERCHANT' ? 'MERCHANT' : normalizedType === 'NON_MERCHANT' ? 'NON_MERCHANT' : undefined
  const item = await prisma.uPIAccount.create({ data: { userId: user.id, upiId, label, ...(value ? { upiType: value } : {}) } })
  return new Response(JSON.stringify(item), { status: 201 })
}
