import { prisma } from '@/lib/prisma'

export async function GET() {
  try {
    const startTime = Date.now()

    const dbCheck = await prisma.user.count().catch((err) => {
      console.error('Database check failed:', err)
      return null
    })

    const dbTime = Date.now() - startTime

    if (dbCheck === null) {
      return new Response(
        JSON.stringify({
          status: 'unhealthy',
          database: 'disconnected',
          timestamp: new Date().toISOString()
        }),
        { status: 503 }
      )
    }

    return new Response(
      JSON.stringify({
        status: 'healthy',
        database: 'connected',
        dbQueryTime: `${dbTime}ms`,
        totalUsers: dbCheck,
        timestamp: new Date().toISOString()
      }),
      { status: 200 }
    )
  } catch (err) {
    console.error('Health check error:', err)
    return new Response(
      JSON.stringify({
        status: 'error',
        error: String(err),
        timestamp: new Date().toISOString()
      }),
      { status: 500 }
    )
  }
}
