import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const link = await prisma.paymentLink.findFirst({ where: { userId: user.id, type: 'DEFAULT' } })
  return new Response(JSON.stringify(link), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { title, description, amount, active } = body || {}
  if (!title) return new Response(JSON.stringify({ error: 'Title required' }), { status: 400 })
  const existing = await prisma.paymentLink.findFirst({ where: { userId: user.id, type: 'DEFAULT' } })
  const data: any = { userId: user.id, type: 'DEFAULT', title }
  if (description !== undefined) data.description = description
  if (amount !== undefined) data.amount = Number.isFinite(+amount) ? +amount : null
  if (active !== undefined) data.active = !!active
  const link = existing
    ? await prisma.paymentLink.update({ where: { id: existing.id }, data })
    : await prisma.paymentLink.create({ data })
  return new Response(JSON.stringify(link), { status: 200 })
}
