import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const links = await prisma.paymentLink.findMany({ where: { userId: user.id, type: 'CUSTOM' }, orderBy: { createdAt: 'desc' } })
  return new Response(JSON.stringify(links), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { slug, title, description, amount, active, redirectUrl } = body || {}
  if (!title) return new Response(JSON.stringify({ error: 'Title required' }), { status: 400 })

  const baseData: any = {
    userId: user.id,
    type: 'CUSTOM',
    title,
    description: description || null,
    amount: amount != null && Number.isFinite(+amount) ? Math.round(+amount) : null,
    active: active ?? true,
    redirectUrl: redirectUrl || null,
  }

  const provided = String(slug ?? '').trim()
  if (provided) {
    try {
      const link = await prisma.paymentLink.create({ data: { ...baseData, slug: provided } })
      return new Response(JSON.stringify(link), { status: 201 })
    } catch (e: any) {
      if (e?.code === 'P2002') {
        return new Response(JSON.stringify({ error: 'Slug already exists' }), { status: 409 })
      }
      return new Response(JSON.stringify({ error: e?.message || 'Failed to create link' }), { status: 500 })
    }
  }

  const attempts = 5
  for (let i = 0; i < attempts; i++) {
    const candidate = Math.random().toString(36).slice(2, 10)
    try {
      const link = await prisma.paymentLink.create({ data: { ...baseData, slug: candidate } })
      return new Response(JSON.stringify(link), { status: 201 })
    } catch (e: any) {
      if (e?.code !== 'P2002') {
        return new Response(JSON.stringify({ error: e?.message || 'Failed to create link' }), { status: 500 })
      }
      if (i === attempts - 1) {
        return new Response(JSON.stringify({ error: 'Could not generate unique slug' }), { status: 500 })
      }
    }
  }
  return new Response(JSON.stringify({ error: 'Unknown error' }), { status: 500 })
}
