import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { promises as fs } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

function isTooLarge(req: Request, limit = 10 * 1024 * 1024) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  return Number.isFinite(n) && n > limit
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const tickets = await prisma.supportTicket.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
  return new Response(JSON.stringify(tickets), { status: 200 })
}

export async function POST(req: Request) {
  if (isTooLarge(req)) return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const ctype = req.headers.get('content-type') || ''
  if (ctype.includes('multipart/form-data')) {
    const form = await req.formData().catch(() => null)
    if (!form) return new Response(JSON.stringify({ error: 'Invalid form' }), { status: 400 })
    const subject = String(form.get('subject') || '')
    const message = String(form.get('message') || '')
    if (!subject || !message) return new Response(JSON.stringify({ error: 'subject and message required' }), { status: 400 })
    let attachmentUrl: string | undefined
    const file = form.get('attachment') as File | null
    if (file && file.size > 0) {
      if (file.size > 5 * 1024 * 1024) return new Response(JSON.stringify({ error: 'file_too_large' }), { status: 413 })
      const buf = Buffer.from(await file.arrayBuffer())
      const ext = (file.type?.split('/')?.[1] || 'png').toLowerCase()
      const name = `${randomBytes(16).toString('hex')}.${ext}`
      const dir = path.join(process.cwd(), 'public', 'support')
      await fs.mkdir(dir, { recursive: true })
      await fs.writeFile(path.join(dir, name), buf)
      attachmentUrl = `/support/${name}`
    }
    const ticket = await prisma.supportTicket.create({ data: { userId: user.id, subject, message, attachmentUrl } })
    return new Response(JSON.stringify(ticket), { status: 201 })
  } else {
    const body = await req.json().catch(() => ({}))
    const { subject, message } = body || {}
    if (!subject || !message) return new Response(JSON.stringify({ error: 'subject and message required' }), { status: 400 })
    const ticket = await prisma.supportTicket.create({ data: { userId: user.id, subject, message } })
    return new Response(JSON.stringify(ticket), { status: 201 })
  }
}
