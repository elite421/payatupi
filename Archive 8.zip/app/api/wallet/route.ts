import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export const revalidate = 60 // Revalidate every 60 seconds
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })

    let wallet = await (prisma as any).wallet.findUnique({ where: { userId: user.id } }).catch(() => null)
    if (!wallet) {
      wallet = await (prisma as any).wallet.create({ data: { userId: user.id, balance: 10, trialCredited: true } })
      await (prisma as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: 10, reason: 'Trial credit' } })
    }

    const entries = await (prisma as any).walletEntry.findMany({
      where: { walletId: wallet.id },
      orderBy: { createdAt: 'desc' },
      take: 20,
    })

    return new Response(JSON.stringify({ wallet, entries }), { status: 200 })
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
