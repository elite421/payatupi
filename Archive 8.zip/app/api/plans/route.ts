export async function GET() {
  const plans = [
    { code: 'INDIVIDUAL', name: 'Individual', amount: 300, currency: 'INR', period: 'MONTHLY' },
    { code: 'ENTERPRISE', name: 'Enterprise', amount: 375, currency: 'INR', period: 'MONTHLY' },
    { code: 'INDIVIDUAL_PLUS', name: 'Individual Plus', amount: 2000, currency: 'INR', period: 'YEARLY' },
    { code: 'ENTERPRISE_PLUS', name: 'Enterprise Plus', amount: 2250, currency: 'INR', period: 'YEARLY' },
  ]
  return new Response(JSON.stringify(plans), {
    status: 200,
    headers: { 'content-type': 'application/json' },
  })
}
