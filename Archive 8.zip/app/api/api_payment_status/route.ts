import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { logApiRequest } from '@/lib/api-logging'
import { isValidPublicId, findUserByPublicId } from '@/lib/user-id'

export async function POST(req: Request) {
  try {
    const endpoint = new URL(req.url).pathname
    const body = await req.json().catch(() => ({} as any))
    const payload = body?.fetch_payment || body || {}

    const accountId = String(payload.account_id || '').trim()
    const secretKey = String(payload.secret_key || '').trim()
    const paymentId = String(payload.payment_id || '').trim()

    if (!accountId || !secretKey || !paymentId) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_request', req })
      return new Response(JSON.stringify({ error: 'invalid_request' }), { status: 400 })
    }

    let user = null as any
    if (isValidPublicId(accountId)) {
      user = await findUserByPublicId(accountId)
    }
    if (!user) {
      user = await prisma.user.findUnique({ where: { id: accountId } })
    }
    if (!user) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_account', req })
      return new Response(JSON.stringify({ error: 'invalid_account' }), { status: 400 })
    }

    const prefix = secretKey.slice(0, 8)
    const key = await prisma.apiKey.findFirst({ where: { userId: user.id, prefix, revoked: false } })
    if (!key) {
      await logApiRequest({ endpoint, method: 'POST', code: 401, status: 'ERROR', reason: 'invalid_key', req, userId: user.id })
      return new Response(JSON.stringify({ error: 'invalid_key' }), { status: 401 })
    }
    const ok = await bcrypt.compare(secretKey, key.hashedKey)
    if (!ok) {
      await logApiRequest({ endpoint, method: 'POST', code: 401, status: 'ERROR', reason: 'invalid_key', req, userId: user.id, apiKeyId: key.id })
      return new Response(JSON.stringify({ error: 'invalid_key' }), { status: 401 })
    }

    const { getClientIp } = await import('@/lib/ip')
    const ip = getClientIp(req)
    const count = await prisma.allowedIp.count({ where: { userId: user.id } })
    if (count === 0) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'ip_not_allowed', req, userId: user.id, apiKeyId: key.id, metadata: { ip, allowlist: 'empty' } })
      return new Response(JSON.stringify({ error: 'ip_not_allowed' }), { status: 403 })
    }
    const exists = ip ? await prisma.allowedIp.findFirst({ where: { userId: user.id, ip } }) : null
    if (!exists) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'ip_not_allowed', req, userId: user.id, apiKeyId: key.id, metadata: { ip } })
      return new Response(JSON.stringify({ error: 'ip_not_allowed' }), { status: 403 })
    }

    const tx = await prisma.transaction.findFirst({
      where: {
        userId: user.id,
        purpose: { startsWith: `PID:${paymentId}` },
      },
      orderBy: { createdAt: 'desc' },
    })

    if (!tx) {
      await logApiRequest({ endpoint, method: 'POST', code: 404, status: 'ERROR', reason: 'not_found', req, userId: user.id, apiKeyId: key.id })
      return new Response(JSON.stringify({ error: 'not_found' }), { status: 404 })
    }

    const out = {
      id: tx.id,
      status: tx.status,
      amount: tx.amount,
      mode: tx.mode,
      utr: tx.utr,
      screenshot: tx.screenshotUrl || null,
      purpose: tx.purpose,
      createdAt: tx.createdAt,
    }

    await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, apiKeyId: key.id, metadata: { paymentId } })
    return new Response(JSON.stringify({ ok: true, payment: out }), { status: 200 })
  } catch (err) {
    const endpoint = (()=>{ try { return new URL(req.url).pathname } catch { return '/api/api_payment_status' } })()
    await logApiRequest({ endpoint, method: 'POST', code: 500, status: 'ERROR', reason: 'server_error', req })
    return new Response(JSON.stringify({ error: 'server_error' }), { status: 500 })
  }
}
