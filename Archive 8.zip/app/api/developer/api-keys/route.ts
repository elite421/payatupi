import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { randomBytes } from 'crypto'
import { createActivity } from '@/lib/activity'
import { hasEntitlement } from '@/lib/subscription'

function generateKey() {
  const raw = randomBytes(24).toString('hex')
  const prefix = raw.slice(0, 8)
  return { raw, prefix }
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const keys = await prisma.apiKey.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
  const safe = keys.map(k => ({ id: k.id, prefix: k.prefix, revoked: k.revoked, createdAt: k.createdAt, lastUsedAt: k.lastUsedAt }))
  return new Response(JSON.stringify(safe), { status: 200 })
}

export async function POST() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const allowed = await hasEntitlement(user.id, 'apiAccess')
  if (!allowed) return new Response(JSON.stringify({ error: 'Requires Enterprise plan' }), { status: 403 })
  const ipCount = await prisma.allowedIp.count({ where: { userId: user.id } })
  if (ipCount === 0) {
    return new Response(JSON.stringify({ error: 'ip_required' }), { status: 400 })
  }
  const { raw, prefix } = generateKey()
  const hashedKey = await bcrypt.hash(raw, 10)
  const key = await prisma.apiKey.create({ data: { userId: user.id, prefix, hashedKey } })
  await createActivity(user.id, 'API_KEY_CREATED', 'Created API key', { prefix })
  return new Response(JSON.stringify({ id: key.id, key: raw, prefix }), { status: 201 })
}
