import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createActivity } from '@/lib/activity'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const sub = await prisma.subscription.findUnique({ where: { userId: user.id } })
  return new Response(JSON.stringify(sub), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { plan } = body || {}
  if (!plan) return new Response(JSON.stringify({ error: 'plan required' }), { status: 400 })
  const P = String(plan).toUpperCase()
  const allowed = ['FREE','INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS','TRIAL']
  if (!allowed.includes(P)) return new Response(JSON.stringify({ error: 'invalid plan' }), { status: 400 })

  // KYC required for any non-FREE activation (including TRIAL)
  if (P !== 'FREE') {
    const kyc = await prisma.kycSubmission.findUnique({ where: { userId: user.id }, select: { status: true } }).catch(()=>null)
    const status = (kyc as any)?.status || 'NOT_SUBMITTED'
    const eligible = status === 'PENDING' || status === 'APPROVED'
    if (!eligible) {
      return new Response(JSON.stringify({ error: 'KYC required to activate plan' }), { status: 403 })
    }
  }

  // One-time trial enforcement
  if (P === 'TRIAL') {
    const claimed = await (prisma as any).trialClaim.findUnique({ where: { userId: user.id } }).catch(()=>null)
    if (claimed) {
      return new Response(JSON.stringify({ error: 'Trial already used' }), { status: 400 })
    }
  }
  const now = new Date()
  let periodEnd: Date | null = null
  if (P === 'TRIAL') {
    periodEnd = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
  } else if (P === 'INDIVIDUAL' || P === 'ENTERPRISE') {
    periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
  } else if (P === 'INDIVIDUAL_PLUS' || P === 'ENTERPRISE_PLUS') {
    periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
  } else {
    periodEnd = null
  }
  const sub = await prisma.subscription.upsert({
    where: { userId: user.id },
    update: { plan: P as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
    create: { userId: user.id, plan: P as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
  })
  // Record trial claim
  if (P === 'TRIAL') {
    await (prisma as any).trialClaim.upsert({ where: { userId: user.id }, update: {}, create: { userId: user.id } })
  }
  await createActivity(user.id, 'SUBSCRIPTION_CHANGED', 'Subscription updated', { plan: P, periodEnd })
  return new Response(JSON.stringify(sub), { status: 200 })
}
