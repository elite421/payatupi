import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(_: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const user = await (prisma as any).user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      role: true,
      createdAt: true,
      subscription: { select: { plan: true, status: true, currentPeriodEnd: true } },
      kyc: { select: { status: true, proofType: true, documentUrl: true, selfieUrl: true, adminNote: true, updatedAt: true } },
    },
  })
  if (!user) return new Response('Not found', { status: 404 })
  return new Response(JSON.stringify(user), { status: 200 })
}

export async function PATCH(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const body = await req.json().catch(() => ({})) as { name?: string; phone?: string; role?: 'USER'|'ADMIN' }
  const data: any = {}
  if (typeof body.name === 'string' && body.name.trim()) data.name = body.name.trim()
  if (typeof body.phone === 'string') data.phone = body.phone.trim()
  if (body.role === 'USER' || body.role === 'ADMIN') data.role = body.role
  if (Object.keys(data).length === 0) return new Response(JSON.stringify({ error: 'No changes' }), { status: 400 })
  const updated = await prisma.user.update({ where: { id: userId }, data })
  const safe = { id: updated.id, name: updated.name, email: updated.email, phone: updated.phone, role: updated.role }
  return new Response(JSON.stringify(safe), { status: 200 })
}
