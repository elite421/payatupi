import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const url = new URL(req.url)
  const takeRaw = url.searchParams.get('take')
  const take = Math.min(Math.max(parseInt(takeRaw || '50') || 50, 1), 200)

  const txs = await (prisma as any).transaction.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take,
  })

  const items = (txs as any[]).map((t) => ({
    id: t.id,
    createdAt: t.createdAt,
    purpose: t.purpose,
    amount: t.amount,
    status: t.status,
    utr: t.utr || null,
    screenshotUrl: t.screenshotUrl || null,
    mode: t.mode || null,
    upiId: t.upiId || null,
    accountNumber: t.accountNumber || null,
    ifsc: t.ifsc || null,
    buyerName: t.buyerName || null,
    buyerPhone: t.buyerPhone || null,
    buyerEmail: t.buyerEmail || null,
  }))

  return new Response(JSON.stringify(items), { status: 200 })
}
