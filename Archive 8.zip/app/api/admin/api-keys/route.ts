import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const url = new URL(req.url)
  const take = Math.min(parseInt(url.searchParams.get('take') || '100', 10) || 100, 500)
  const revoked = url.searchParams.get('revoked')
  const q = (url.searchParams.get('q') || '').trim()

  const where: any = {}
  if (revoked === 'true') where.revoked = true
  if (revoked === 'false') where.revoked = false
  if (q) {
    where.OR = [
      { prefix: { contains: q, mode: 'insensitive' } },
      { user: { is: { name: { contains: q, mode: 'insensitive' } } } },
      { user: { is: { email: { contains: q, mode: 'insensitive' } } } },
    ]
  }

  const keys = await prisma.apiKey.findMany({
    where,
    include: { user: { select: { id: true, name: true, email: true } } },
    orderBy: { createdAt: 'desc' },
    take,
  })
  return new Response(JSON.stringify(keys), { status: 200 })
}
