import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { id } = await ctx.params
  const body = await req.json().catch(() => ({})) as { revoke?: boolean }
  const key = await prisma.apiKey.findUnique({ where: { id } })
  if (!key) return new Response('Not found', { status: 404 })
  if (body.revoke) {
    const updated = await prisma.apiKey.update({ where: { id }, data: { revoked: true } })
    return new Response(JSON.stringify(updated), { status: 200 })
  }
  return new Response(JSON.stringify(key), { status: 200 })
}
