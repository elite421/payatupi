import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const now = new Date()

  const [totalUsers, activeSubscribers, kycPending, txPending] = await Promise.all([
    prisma.user.count(),
    prisma.subscription.count({
      where: {
        plan: { not: 'FREE' as any } as any,
        status: 'ACTIVE' as any,
        OR: [
          { currentPeriodEnd: null },
          { currentPeriodEnd: { gt: now } },
        ],
      },
    }),
    prisma.kycSubmission.count({ where: { status: 'PENDING' as any } }),
    prisma.transaction.count({ where: { status: 'Pending' } }),
  ])

  return new Response(JSON.stringify({ totalUsers, activeSubscribers, kycPending, txPending }), { status: 200 })
}
