import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const url = new URL(req.url)
  const q = (url.searchParams.get('q') || '').trim()
  const status = (url.searchParams.get('status') || '').toUpperCase()
  const take = Math.min(parseInt(url.searchParams.get('take') || '100', 10) || 100, 500)

  const where: any = {}
  const allowed = ['NOT_SUBMITTED','PENDING','APPROVED','REJECTED']
  if (status && allowed.includes(status)) where.status = status as any
  if (q) {
    where.user = {
      is: {
        OR: [
          { name: { contains: q, mode: 'insensitive' } },
          { email: { contains: q, mode: 'insensitive' } },
          { phone: { contains: q } },
        ]
      }
    }
  }

  const items = await (prisma as any).kycSubmission.findMany({
    where,
    include: { user: { select: { id: true, name: true, email: true, phone: true } } },
    orderBy: { updatedAt: 'desc' },
    take,
  })

  return new Response(JSON.stringify(items), { status: 200 })
}
