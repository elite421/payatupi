import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { normalizeUtr } from '@/lib/normalize'

/**
 * Cleanup callback logs older than 10 days that haven't been matched to any transaction.
 * This endpoint should be called periodically (e.g., via cron job).
 */
export async function POST(req: Request) {
  try {
    const session = await auth()
    const role = (session?.user as any)?.role
    if (!session?.user?.email || role !== 'ADMIN') {
      return new Response('Unauthorized', { status: 401 })
    }

    const body = await req.json().catch(() => ({})) as { days?: number; dryRun?: boolean }
    const days = body.days || 10
    const dryRun = body.dryRun !== false // Default to true for safety

    const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)

    // Find logs older than cutoff date
    const oldLogs = await prisma.smsCallbackLog.findMany({
      where: {
        createdAt: { lt: cutoffDate },
        userId: { not: null },
      },
      select: {
        id: true,
        userId: true,
        utr: true,
        status: true,
        amount: true,
        createdAt: true,
      },
    })

    let deleted = 0
    let kept = 0

    for (const log of oldLogs) {
      if (!log.userId) {
        continue
      }

      try {
        // Check if this log has been matched to a transaction
        const utrIn = normalizeUtr(log.utr)
        const matchedTx = await prisma.transaction.findFirst({
          where: {
            userId: log.userId,
            utr: utrIn,
            status: log.status,
          },
        })

        if (matchedTx) {
          // This log was matched, keep it
          kept++
          continue
        }

        // Also check if there's any transaction with matching amount and UTR (even if status differs)
        // This handles cases where status might have changed
        const anyMatch = await prisma.transaction.findFirst({
          where: {
            userId: log.userId,
            utr: utrIn,
          },
        })

        if (anyMatch) {
          // There's a transaction with this UTR, keep the log
          kept++
          continue
        }

        // No match found, safe to delete
        if (!dryRun) {
          await prisma.smsCallbackLog.delete({ where: { id: log.id } })
        }
        deleted++
      } catch (error) {
        console.error(`Error checking/deleting callback log ${log.id}:`, error)
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        dryRun,
        deleted,
        kept,
        total: oldLogs.length,
        cutoffDate: cutoffDate.toISOString(),
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error cleaning up callback logs:', error)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}

