import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const url = new URL(req.url)
  const take = Math.min(parseInt(url.searchParams.get('take') || '100', 10) || 100, 500)
  const userId = url.searchParams.get('userId') || undefined
  const status = url.searchParams.get('status') || undefined
  const endpoint = url.searchParams.get('endpoint') || undefined
  const code = url.searchParams.get('code') ? parseInt(url.searchParams.get('code')!, 10) : undefined
  const prefix = url.searchParams.get('prefix') || undefined
  const q = (url.searchParams.get('q') || '').trim()

  const where: any = {}
  if (userId) where.userId = userId
  if (status) where.status = status
  if (typeof code === 'number' && Number.isFinite(code)) where.code = code
  if (endpoint) where.endpoint = { contains: endpoint, mode: 'insensitive' }
  if (prefix) where.apiKey = { is: { prefix: { contains: prefix, mode: 'insensitive' } } }
  if (q) {
    where.OR = [
      { endpoint: { contains: q, mode: 'insensitive' } },
      { user: { is: { name: { contains: q, mode: 'insensitive' } } } },
      { user: { is: { email: { contains: q, mode: 'insensitive' } } } },
      { reason: { contains: q, mode: 'insensitive' } }
    ]
  }

  try {
    const logs = await (prisma as any).apiRequestLog.findMany({
      where,
      include: { user: { select: { id: true, name: true, email: true } }, apiKey: { select: { id: true, prefix: true } } },
      orderBy: { createdAt: 'desc' },
      take,
    })
    return new Response(JSON.stringify(logs), { status: 200 })
  } catch {
    return new Response(JSON.stringify([]), { status: 200 })
  }
}
