import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createActivity } from '@/lib/activity'
import { createHmac } from 'crypto'

const ALLOWED: Array<'Pending' | 'Success' | 'Failed'> = ['Pending', 'Success', 'Failed']

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const { id } = await params
  if (!id) return new Response('Missing id', { status: 400 })

  const body = await req.json().catch(() => ({})) as { status?: string }
  const statusIn = body?.status
  if (!statusIn || !ALLOWED.includes(statusIn as any)) {
    return new Response(JSON.stringify({ error: 'Invalid status' }), { status: 400 })
  }

  const tx = await prisma.transaction.findUnique({ where: { id } })
  if (!tx) return new Response('Not found', { status: 404 })

  // Update status
  const updated = await prisma.transaction.update({ where: { id }, data: { status: statusIn, statusSource: 'ADMIN' } })

  // Wallet top-up auto-credit after admin marks Success
  try {
    if (statusIn === 'Success' && String(updated.mode || '').toUpperCase() === 'WALLET_TOPUP' && !(updated as any).walletCredited) {
      await prisma.$transaction(async (db) => {
        const fresh = await db.transaction.findUnique({ where: { id: updated.id } })
        if (fresh && String(fresh.status) === 'Success' && String(fresh.mode || '').toUpperCase() === 'WALLET_TOPUP' && !(fresh as any).walletCredited) {
          const w = await (db as any).wallet.findUnique({ where: { userId: fresh.userId } })
          const wallet = w || await (db as any).wallet.create({ data: { userId: fresh.userId, balance: 0 } })
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: fresh.amount } } })
          await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: fresh.amount, reason: `Wallet top-up via ${fresh.id}`, txId: fresh.id } })
          await (db as any).transaction.update({ where: { id: fresh.id }, data: { walletCredited: true } })
        }
      })
    }
  } catch {}

  let activated: { plan: string; periodEnd: Date | null } | null = null
  try {
    // If SUBSCRIPTION payment marked Success, activate plan
    if (statusIn === 'Success' && String(updated.mode).toUpperCase() === 'SUBSCRIPTION') {
      const allowed = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS'] as const
      const m = String(updated.purpose || '').match(/Subscription\s+([A-Z_]+)/i)
      const planIn = (m?.[1] || '').toUpperCase()
      if (allowed.includes(planIn as any)) {
        const now = new Date()
        let periodEnd: Date | null = null
        if (planIn === 'INDIVIDUAL' || planIn === 'ENTERPRISE') {
          periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
        } else if (planIn === 'INDIVIDUAL_PLUS' || planIn === 'ENTERPRISE_PLUS') {
          periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
        }
        const sub = await prisma.subscription.upsert({
          where: { userId: updated.userId },
          update: { plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
          create: { userId: updated.userId, plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
        })
        await createActivity(updated.userId, 'SUBSCRIPTION_CHANGED', 'Subscription activated from approved payment', { plan: planIn, periodEnd })
        activated = { plan: planIn, periodEnd }
      }
    }
  } catch (e) {
    // Swallow activation errors but still return status update
  }

  try {
    const hooks = await prisma.webhook.findMany({ where: { userId: updated.userId } })
    if (hooks.length > 0) {
      const payload = {
        event: 'transaction.updated',
        data: {
          id: updated.id,
          status: statusIn,
          purpose: updated.purpose,
          amount: updated.amount,
          mode: updated.mode,
          utr: updated.utr,
          createdAt: updated.createdAt,
        },
        subscription: activated ? { plan: activated.plan, periodEnd: activated.periodEnd } : undefined,
        userId: updated.userId,
      }
      const body = JSON.stringify(payload)
      await Promise.all(hooks.map(async (h: any) => {
        try {
          const headers: Record<string,string> = { 'Content-Type': 'application/json', 'X-Payatupi-Event': 'transaction.updated' }
          if (h.secret) {
            const sig = createHmac('sha256', h.secret).update(body).digest('hex')
            headers['X-Payatupi-Signature'] = sig
          }
          await fetch(h.url, { method: 'POST', headers, body, redirect: 'manual' as any })
        } catch {}
      }))
    }
  } catch {}

  return new Response(JSON.stringify({ id, status: statusIn, subscription: activated || undefined }), { status: 200 })
}
