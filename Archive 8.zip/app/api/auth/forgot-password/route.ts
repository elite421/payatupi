import { prisma } from '@/lib/prisma'
import { randomBytes } from 'crypto'

export async function POST(req: Request) {
  try {
    const { email } = await req.json().catch(() => ({}))

    if (!email || typeof email !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Email is required' }),
        { status: 400 }
      )
    }

    const normalizedEmail = email.toLowerCase().trim()

    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      select: { id: true, email: true }
    }).catch(() => null)

    if (!user) {
      return new Response(
        JSON.stringify({
          success: true,
          message: 'If this email exists, a password reset link has been sent'
        }),
        { status: 200 }
      )
    }

    const resetToken = randomBytes(32).toString('hex')
    const expires = new Date(Date.now() + 1 * 60 * 60 * 1000)

    await prisma.passwordResetToken.deleteMany({
      where: { email: normalizedEmail }
    }).catch(() => null)

    await prisma.passwordResetToken.create({
      data: {
        email: normalizedEmail,
        token: resetToken,
        expires
      }
    }).catch(() => null)

    const resetUrl = `${process.env.NEXTAUTH_URL}/reset-password?token=${resetToken}`

    console.log(`Password reset link for ${normalizedEmail}: ${resetUrl}`)

    return new Response(
      JSON.stringify({
        success: true,
        message: 'If this email exists, a password reset link has been sent'
      }),
      { status: 200 }
    )
  } catch (err) {
    console.error('Forgot password error:', err)
    return new Response(
      JSON.stringify({ error: 'Server error' }),
      { status: 500 }
    )
  }
}
