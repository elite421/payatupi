import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'

export async function POST(req: Request) {
  try {
    const { token, password } = await req.json().catch(() => ({}))

    if (!token || !password) {
      return new Response(
        JSON.stringify({ error: 'Token and password are required' }),
        { status: 400 }
      )
    }

    if (password.length < 8) {
      return new Response(
        JSON.stringify({ error: 'Password must be at least 8 characters' }),
        { status: 400 }
      )
    }

    const resetTokenRecord = await prisma.passwordResetToken.findUnique({
      where: { token }
    }).catch(() => null)

    if (!resetTokenRecord || resetTokenRecord.expires < new Date()) {
      return new Response(
        JSON.stringify({ error: 'Invalid or expired reset token' }),
        { status: 400 }
      )
    }

    const user = await prisma.user.findUnique({
      where: { email: resetTokenRecord.email }
    }).catch(() => null)

    if (!user) {
      return new Response(
        JSON.stringify({ error: 'User not found' }),
        { status: 400 }
      )
    }

    const hashedPassword = await bcrypt.hash(password, 10)

    await prisma.user.update({
      where: { id: user.id },
      data: { password: hashedPassword }
    }).catch(() => null)

    await prisma.passwordResetToken.delete({
      where: { token }
    }).catch(() => null)

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Password reset successful. Please log in with your new password.'
      }),
      { status: 200 }
    )
  } catch (err) {
    console.error('Reset password error:', err)
    return new Response(
      JSON.stringify({ error: 'Server error' }),
      { status: 500 }
    )
  }
}
