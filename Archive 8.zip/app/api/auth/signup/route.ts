import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { ensureUserPublicId } from '@/lib/user-id'
import { hashPassword } from '@/lib/password'

const schema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().min(1),
  password: z.string().min(6),
})

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}))
    const parsed = schema.safeParse(body)
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: 'Invalid input' }), { status: 400 })
    }
    const { name, email, phone, password } = parsed.data

    const existing = await prisma.user.findUnique({ where: { email } })
    if (existing) {
      return new Response(JSON.stringify({ error: 'Email already in use' }), { status: 400 })
    }

    const hashed = await hashPassword(password)
    const user = await prisma.user.create({ data: { name, email, phone, password: hashed } })
    const publicId = await ensureUserPublicId(user.id)

    return new Response(JSON.stringify({ ok: true, id: user.id, publicId }), { status: 200 })
  } catch (e) {
    console.error(e)
    return new Response(JSON.stringify({ error: 'Server error' }), { status: 500 })
  }
}
