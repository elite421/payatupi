import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const items = await prisma.bankAccount.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' } })
  return new Response(JSON.stringify(items), { status: 200 })
}

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { accountHolder, accountNumber, ifsc, bankName } = body || {}
  if (!accountHolder || !accountNumber || !ifsc || !bankName) return new Response(JSON.stringify({ error: 'All fields required' }), { status: 400 })
  const item = await prisma.bankAccount.create({ data: { userId: user.id, accountHolder, accountNumber, ifsc, bankName } })
  return new Response(JSON.stringify(item), { status: 201 })
}
