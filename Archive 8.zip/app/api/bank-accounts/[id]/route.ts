import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const { id } = await context.params
  const item = await prisma.bankAccount.findUnique({ where: { id } })
  if (!item || item.userId !== user.id) return new Response('Not found', { status: 404 })
  await prisma.bankAccount.delete({ where: { id: item.id } })
  return new Response(null, { status: 204 })
}
