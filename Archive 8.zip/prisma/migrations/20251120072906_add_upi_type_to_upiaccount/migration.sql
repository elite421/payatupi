-- CreateEnum
CREATE TYPE "Role" AS ENUM ('USER', 'ADMIN');

-- CreateEnum
CREATE TYPE "UPIType" AS ENUM ('MERCHANT', 'NON_MERCHANT');

-- AlterTable
ALTER TABLE "PaymentLink" ADD COLUMN     "redirectUrl" TEXT;

-- AlterTable
ALTER TABLE "SupportTicket" ADD COLUMN     "attachmentUrl" TEXT;

-- AlterTable
ALTER TABLE "UPIAccount" ADD COLUMN     "upiType" "UPIType" NOT NULL DEFAULT 'NON_MERCHANT';

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "role" "Role" NOT NULL DEFAULT 'USER';

-- CreateTable
CREATE TABLE "Transaction" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "purpose" TEXT NOT NULL,
    "amount" INTEGER NOT NULL,
    "status" TEXT NOT NULL,
    "mode" TEXT,
    "upiId" TEXT,
    "accountNumber" TEXT,
    "ifsc" TEXT,
    "utr" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Transaction_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
