// Lightweight fetch caching utility to reduce server load

const CACHE_DURATION = {
  SHORT: 30 * 1000, // 30 seconds
  MEDIUM: 2 * 60 * 1000, // 2 minutes
  LONG: 5 * 60 * 1000, // 5 minutes
}

// Maximum number of cache entries to prevent unbounded memory growth
const MAX_CACHE_SIZE = 500

type CacheEntry = {
  data: any
  timestamp: number
  duration: number
}

const cache = new Map<string, CacheEntry>()

// Clean up old cache entries periodically
const cleanupInterval = setInterval(() => {
  const now = Date.now()
  for (const [key, entry] of cache.entries()) {
    if (now - entry.timestamp > entry.duration) {
      cache.delete(key)
    }
  }
}, 60000) // Clean every minute

// Unref the interval in Node.js so it doesn't prevent the process from exiting
if (typeof cleanupInterval === 'object' && cleanupInterval !== null && 'unref' in cleanupInterval) {
  (cleanupInterval as any).unref()
}

// Evict oldest entries if cache exceeds size limit
function evictOldest() {
  if (cache.size <= MAX_CACHE_SIZE) return

  // Find and delete oldest entries until we're under the limit
  const entries = Array.from(cache.entries())
  entries.sort((a, b) => a[1].timestamp - b[1].timestamp)

  const toDelete = cache.size - MAX_CACHE_SIZE
  for (let i = 0; i < toDelete && i < entries.length; i++) {
    cache.delete(entries[i][0])
  }
}

export async function cachedFetch(
  url: string,
  options: RequestInit = {},
  cacheDuration: number = CACHE_DURATION.MEDIUM
): Promise<Response> {
  const cacheKey = `${url}:${JSON.stringify(options)}`
  const cached = cache.get(cacheKey)
  const now = Date.now()

  // Return cached data if still valid
  if (cached && (now - cached.timestamp) < cached.duration) {
    return new Response(JSON.stringify(cached.data), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    })
  }

  try {
    const response = await fetch(url, {
      ...options,
      cache: options.cache || 'default', // Use default caching instead of no-store
    })

    if (response.ok) {
      const data = await response.json()
      // Cache successful responses
      cache.set(cacheKey, {
        data,
        timestamp: now,
        duration: cacheDuration,
      })
      // Evict oldest entries if cache is too large
      evictOldest()
    }

    return response
  } catch (error) {
    // Return cached data on error if available
    if (cached) {
      return new Response(JSON.stringify(cached.data), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      })
    }
    throw error
  }
}

export function clearCache(url?: string) {
  if (url) {
    for (const key of cache.keys()) {
      if (key.startsWith(url)) {
        cache.delete(key)
      }
    }
  } else {
    cache.clear()
  }
}
