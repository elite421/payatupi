/**
 * Shared formatting utilities
 */

/**
 * Format a Date object into a human-readable timestamp string
 * Format: DD-MM-YYYY HH:MM:SS AM/PM
 */
export function formatTimestamp(date: Date): string {
    const pad = (n: number) => n.toString().padStart(2, '0')
    const d = new Date(date)
    const day = pad(d.getDate())
    const month = pad(d.getMonth() + 1)
    const year = d.getFullYear()
    let hours = d.getHours()
    const ampm = hours >= 12 ? 'PM' : 'AM'
    hours = hours % 12
    if (hours === 0) hours = 12
    const minutes = pad(d.getMinutes())
    const seconds = pad(d.getSeconds())
    return `${day}-${month}-${year} ${pad(hours)}:${minutes}:${seconds} ${ampm}`
}
