import { auth } from '@/lib/auth'

export default auth((req: any) => {
  if (!req.auth && (req.nextUrl.pathname.startsWith('/account') || req.nextUrl.pathname.startsWith('/dashboard'))) {
    const url = new URL('/login', req.nextUrl.origin)
    return Response.redirect(url)
  }
  if (req.nextUrl.pathname.startsWith('/admin')) {
    if (!req.auth) {
      const url = new URL('/login', req.nextUrl.origin)
      return Response.redirect(url)
    }
    const role = (req.auth.user as any)?.role
    if (role !== 'ADMIN') {
      const url = new URL('/account', req.nextUrl.origin)
      return Response.redirect(url)
    }
  }
})

export const config = {
  matcher: ['/account/:path*', '/dashboard/:path*', '/admin/:path*'],
}
