export default function Footer() {
  return (
    <footer className="w-full bg-white/40 backdrop-blur-xl border-t border-white/50 mt-20">
      <div className="max-w-7xl mx-auto px-6 py-8 text-center text-gray-700">
        <p className="font-medium text-gray-900 text-lg">Payatupi</p>
        <p className="mt-2 text-sm text-gray-600">
          © {new Date().getFullYear()} Payatupi. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
