export default function Background() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <svg className="absolute -top-40 left-1/2 -translate-x-1/2 blur-3xl opacity-50" width="1600" height="600" viewBox="0 0 1600 600" fill="none">
        <defs>
          <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#b9d0ff" />
            <stop offset="100%" stopColor="#f6f9ff" />
          </linearGradient>
        </defs>
        <path d="M0,200 C300,350 500,50 800,200 C1100,350 1300,50 1600,200 L1600,600 L0,600 Z" fill="url(#g1)" />
      </svg>
      <div className="absolute inset-0 bg-gradient-to-b from-white/40 to-transparent" />
    </div>
  )
}
