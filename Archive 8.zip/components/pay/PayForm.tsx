"use client"

import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'

export default function PayForm({
  linkIdOrSlug,
  fixedAmount,
  defaultAmount,
  purpose,
  allowEditPurpose = false,
  showPurpose = true,
  enableName = true,
  enablePhone = false,
  enableEmail = false,
  checkoutMessage,
  themeColor,
}: {
  linkIdOrSlug: string
  fixedAmount: boolean
  defaultAmount: number | null
  purpose: string
  allowEditPurpose?: boolean
  showPurpose?: boolean
  enableName?: boolean
  enablePhone?: boolean
  enableEmail?: boolean
  checkoutMessage?: string
  themeColor?: string
}) {
  const router = useRouter()
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [email, setEmail] = useState('')
  const [amount, setAmount] = useState<string>(defaultAmount != null ? String(defaultAmount) : '')
  const [errors, setErrors] = useState({ name: '', amount: '', purpose: '', phone: '', email: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [touched, setTouched] = useState({ name: false, amount: false, purpose: false, phone: false, email: false })
  const [purposeVal, setPurposeVal] = useState<string>(allowEditPurpose ? '' : (purpose || ''))

  // Validate form on mount and when dependencies change
  useEffect(() => {
    if (touched.name || touched.amount || touched.purpose) {
      validateForm()
    }
  }, [name, phone, email, amount, purposeVal, touched])

  const validateForm = (): boolean => {
    const newErrors = { name: '', amount: '', purpose: '', phone: '', email: '' }
    let isValid = true

    // Name validation (only when enabled)
    if (enableName) {
      if (!name.trim()) {
        newErrors.name = 'Name is required'
        isValid = false
      } else if (name.trim().length < 2) {
        newErrors.name = 'Name must be at least 2 characters'
        isValid = false
      } else if (name.trim().length > 100) {
        newErrors.name = 'Name must be less than 100 characters'
        isValid = false
      }
    }

    // Amount validation
    const amountValue = fixedAmount ? Number(defaultAmount) : Number(amount)
    if (!Number.isFinite(amountValue) || amountValue <= 0) {
      newErrors.amount = 'Enter a valid amount'
      isValid = false
    } else if (amountValue < 1) {
      newErrors.amount = 'Amount must be at least ₹1'
      isValid = false
    } else if (amountValue > 1000000) { // 10 lakh limit
      newErrors.amount = 'Amount cannot exceed ₹10,00,000'
      isValid = false
    }

    // Purpose validation (required for default link) when enabled
    if (showPurpose && allowEditPurpose) {
      if (!purposeVal.trim()) {
        newErrors.purpose = 'Purpose is required'
        isValid = false
      } else if (purposeVal.trim().length > 60) {
        newErrors.purpose = 'Purpose must be 60 characters or less'
        isValid = false
      }
    }

    // Phone validation (optional but validate if present), only when enabled
    if (enablePhone) {
      const ph = phone.trim()
      if (ph && !/^[0-9]{7,15}$/.test(ph)) {
        newErrors.phone = 'Enter a valid phone number'
        isValid = false
      }
    }

    // Email validation (optional but validate if present), only when enabled
    if (enableEmail) {
      const em = email.trim()
      if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) {
        newErrors.email = 'Enter a valid email address'
        isValid = false
      }
    }

    setErrors(newErrors)
    return isValid
  }

  const handleBlur = (field: 'name' | 'amount' | 'purpose' | 'phone' | 'email') => {
    setTouched(prev => ({ ...prev, [field]: true }))
  }

  const formatCurrency = (value: string): string => {
    // Remove any non-digit characters except decimal point
    const numericValue = value.replace(/[^\d.]/g, '')
    
    // Ensure only one decimal point
    const parts = numericValue.split('.')
    if (parts.length > 2) {
      return parts[0] + '.' + parts.slice(1).join('')
    }
    
    return numericValue
  }

  const handleAmountChange = (value: string) => {
    const formattedValue = formatCurrency(value)
    setAmount(formattedValue)
    if (touched.amount) {
      validateForm()
    }
  }

  const onProceed = async () => {
    setTouched({ 
      name: true, 
      amount: true, 
      purpose: (showPurpose && allowEditPurpose) ? true : touched.purpose,
      phone: enablePhone ? true : touched.phone,
      email: enableEmail ? true : touched.email,
    })
    
    if (!validateForm()) {
      // Scroll to first error
      const firstErrorElement = document.querySelector('[data-error="true"]')
      firstErrorElement?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      return
    }

    setIsSubmitting(true)

    try {
      const amountValue = fixedAmount ? Number(defaultAmount) : Number(amount)
      const finalPurpose = (allowEditPurpose ? purposeVal : (purpose || '')).trim()

      // Write cookie with checkout data to avoid leaking details in the URL
      try {
        const data: any = {
          amount: amountValue,
          purpose: finalPurpose || undefined,
        }
        if (enableName) data.name = name.trim()
        if (enablePhone && phone.trim()) data.phone = phone.trim()
        if (enableEmail && email.trim()) data.email = email.trim()
        const key = `chk_${encodeURIComponent(linkIdOrSlug)}`
        const val = encodeURIComponent(JSON.stringify(data))
        const path = `/pay/${encodeURIComponent(linkIdOrSlug)}`
        document.cookie = `${key}=${val}; path=${path}; Max-Age=1800; SameSite=Lax`
      } catch {}

      const url = `/pay/${encodeURIComponent(linkIdOrSlug)}/checkout`

      // Prefer full navigation to ensure cookie is sent on first SSR load
      window.location.href = url
    } catch (error) {
      console.error('Navigation error:', error)
      window.location.href = `/pay/${encodeURIComponent(linkIdOrSlug)}/checkout`
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onProceed()
    }
  }

  const getFieldClassName = (field: 'name' | 'amount' | 'purpose' | 'phone' | 'email', hasError: boolean) => {
    const baseClasses = "w-full rounded-xl border px-4 py-3.5 transition-all duration-200 focus:ring-2 focus:outline-none"
    
    if (hasError) {
      return `${baseClasses} border-red-300 bg-red-50 focus:border-red-500 focus:ring-red-200`
    }
    
    return `${baseClasses} border-gray-300 bg-white focus:border-blue-500 focus:ring-blue-200`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900">Payment Details</h2>
        <p className="mt-2 text-gray-600">Enter your information to proceed with payment</p>
      </div>

      {/* Amount Field */}
      <div data-error={!!errors.amount}>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Amount {fixedAmount && <span className="text-gray-500">(Fixed)</span>}
        </label>
        {fixedAmount ? (
          <div className="relative">
            <input
              type="text"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3.5 text-gray-700 font-semibold"
              value={defaultAmount != null ? `₹${defaultAmount.toLocaleString('en-IN')}` : ''}
              disabled
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              <span className="text-gray-500 text-sm">Fixed</span>
            </div>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-gray-500 font-medium">₹</span>
            </div>
            <input
              type="text"
              inputMode="decimal"
              min="0"
              className={`pl-10 ${getFieldClassName('amount', !!errors.amount)}`}
              placeholder="0.00"
              value={amount}
              onChange={(e) => handleAmountChange(e.target.value)}
              onBlur={() => handleBlur('amount')}
              onKeyPress={handleKeyPress}
              disabled={isSubmitting}
            />
          </div>
        )}
        {errors.amount && (
          <div className="mt-2 flex items-center text-sm text-red-600">
            <svg className="w-4 h-4 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {errors.amount}
          </div>
        )}
      </div>

      {/* Purpose Field */}
      {showPurpose && (
      <div data-error={!!errors.purpose}>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Purpose {allowEditPurpose && <span className="text-red-500">*</span>}
        </label>
        {allowEditPurpose ? (
          <div className="relative">
            <input
              type="text"
              className={getFieldClassName('purpose', !!errors.purpose)}
              placeholder="Enter purpose"
              value={purposeVal}
              onChange={(e)=>setPurposeVal(e.target.value)}
              onBlur={() => handleBlur('purpose')}
              maxLength={60}
              disabled={isSubmitting}
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 text-xs text-gray-400">{purposeVal.length}/60</div>
          </div>
        ) : (
          <div className="relative">
            <input
              type="text"
              className="w-full rounded-xl border border-gray-300 bg-gray-50 px-4 py-3.5 text-gray-700"
              value={purpose}
              disabled
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
        )}
        {errors.purpose && (
          <div className="mt-2 flex items-center text-sm text-red-600">
            <svg className="w-4 h-4 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {errors.purpose}
          </div>
        )}
      </div>
      )}

      {/* Name Field */}
      {enableName && (
      <div data-error={!!errors.name}>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Your Full Name <span className="text-red-500">*</span>
        </label>
        <div className="relative">
          <input
            type="text"
            name="name_field"
            id="name_field"
            className={`pl-10 ${getFieldClassName('name', !!errors.name)}`}
            placeholder="Enter your full name"
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => handleBlur('name')}
            onKeyPress={handleKeyPress}
            disabled={isSubmitting}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
        </div>
        {errors.name && (
          <div className="mt-2 flex items-center text-sm text-red-600">
            <svg className="w-4 h-4 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {errors.name}
          </div>
        )}
      </div>
      )}

      {/* Phone Field */}
      {enablePhone && (
      <div data-error={!!errors.phone}>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Phone (optional)
        </label>
        <div className="relative">
          <input
            type="tel"
            className={`pl-10 ${getFieldClassName('phone', !!errors.phone)}`}
            placeholder="Enter your phone number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            onBlur={() => handleBlur('phone')}
            onKeyPress={handleKeyPress}
            disabled={isSubmitting}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h2l3 7-1.34 2.68a2 2 0 00.66 2.45l3.3 2.2a2 2 0 002.45-.14l2.3-2.3a2 2 0 00.58-1.41V12h2a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2z" />
            </svg>
          </div>
        </div>
        {errors.phone && (
          <div className="mt-2 flex items-center text-sm text-red-600">
            <svg className="w-4 h-4 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {errors.phone}
          </div>
        )}
      </div>
      )}

      {/* Email Field */}
      {enableEmail && (
      <div data-error={!!errors.email}>
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Email (optional)
        </label>
        <div className="relative">
          <input
            type="email"
            className={`pl-10 ${getFieldClassName('email', !!errors.email)}`}
            placeholder="your@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onBlur={() => handleBlur('email')}
            onKeyPress={handleKeyPress}
            disabled={isSubmitting}
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12H8m8 0l-8-6m8 6l-8 6" />
            </svg>
          </div>
        </div>
        {errors.email && (
          <div className="mt-2 flex items-center text-sm text-red-600">
            <svg className="w-4 h-4 mr-1 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            {errors.email}
          </div>
        )}
      </div>
      )}

      {/* Action Button */}
      <button
        type="button"
        id="customLink"
        onClick={onProceed}
        disabled={isSubmitting}
        className="w-full bg-[#366870] hover:bg-[#2f5b62] disabled:bg-gray-500 text-white font-semibold py-4 px-6 rounded-xl shadow-lg hover:shadow-xl focus:ring-2 focus:ring-[#366870] transition-all duration-200 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isSubmitting ? (
          <>
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            Processing...
          </>
        ) : (
          <>
            Continue to Payment
            <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </>
        )}
      </button>

      {/* Security Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
        <div className="flex items-start space-x-3">
          <svg className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <div>
            <p className="text-sm font-medium text-blue-900">Secure Payment</p>
            <p className="text-sm text-blue-700 mt-1">Your payment information is protected with bank-level security</p>
          </div>
        </div>
      </div>
    </div>
  )
}