"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"

export default function RefreshButton({ className }: { className?: string }){
  const router = useRouter()
  const [spinning, setSpinning] = useState(false)

  function onClick(){
    setSpinning(true)
    try {
      router.refresh()
    } finally {
      // Stop spinner a bit later to allow re-render visual
      setTimeout(() => setSpinning(false), 600)
    }
  }

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Refresh"
      title="Refresh"
      className={`inline-flex items-center justify-center rounded-lg border border-white/30 text-white bg-white/0 hover:bg-white/10 transition-colors px-3 py-2 ${className || ""}`}
    >
      <svg className={`w-5 h-5 ${spinning ? "animate-spin" : ""}`} fill="#000000" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <g id="SVGRepo_bgCarrier" strokeWidth="0"></g>
        <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"></g>
        <g id="SVGRepo_iconCarrier">
          <path d="M19.146 4.854l-1.489 1.489A8 8 0 1 0 12 20a8.094 8.094 0 0 0 7.371-4.886 1 1 0 1 0-1.842-.779A6.071 6.071 0 0 1 12 18a6 6 0 1 1 4.243-10.243l-1.39 1.39a.5.5 0 0 0 .354.854H19.5A.5.5 0 0 0 20 9.5V5.207a.5.5 0 0 0-.854-.353z"></path>
        </g>
      </svg>
    </button>
  )
}
