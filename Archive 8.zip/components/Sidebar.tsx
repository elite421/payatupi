"use client"

import Link from 'next/link'
import Image from 'next/image'
import { usePathname, useRouter } from 'next/navigation'
import { useMemo } from 'react'
import { useSession } from 'next-auth/react'
import { signOut } from 'next-auth/react'

export default function Sidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { data: session } = useSession()
  const role = (session?.user as any)?.role

  const nav = useMemo(() => {
    const items: any[] = [
      {
        Image: 'dots',
        src: '/dots-menu.png',
        href: '/dashboard',
      },
      { label: 'Dashboard', href: '/account' },
      {
        label: 'Payment Link',
        children: [
          { label: 'Default Link', href: '/account/payment-link/default' },
          { label: 'Custom Link', href: '/account/payment-link/custom' },
        ],
      },
      {
        label: 'Smart Route',
        children: [
          { label: 'Add UPI', href: '/account/smart-route/add-upi' },
          { label: 'Add Bank', href: '/account/smart-route/add-bank' },
        ],
      },
      { label: 'Checkout Settings', href: '/account/checkout-settings' },
      {label: 'App Settings', href: '/account/app_settings'},
      { label: 'Developer', href: '/account/developer' },
      {
        label: 'Wallet',
        children: [
          { label: 'Overview', href: '/account/wallet' },
          { label: 'Add Money', href: '/account/wallet/add' },
        ],
      },
    ]

    if (role === 'ADMIN') items.push({ label: 'Admin', href: '/admin' })

    items.push(
      { label: 'Subscription', href: '/account/subscription' },
      { label: 'Profile', href: '/account/profile' },
      { label: 'Support', href: '/account/support' },
      { label: 'Logout', action: 'logout' },
    )

    return items
  }, [role])

  function isActive(href: string) {
    if (href === '/account') return pathname === '/account'
    return pathname?.startsWith(href)
  }

  return (
    <aside className="w-64 shrink-0 glass rounded-xl">
      <div className="rounded-xl p-4 sticky top-4">

        <nav className="space-y-2 text-sm">
          {nav.map((item) => (
            <div key={item.label || item.src}>

              {/* ---------- IMAGE ITEM (Dots Icon) ---------- */}
              {item.src && (
                <div
                  className="
                      px-3 py-2 rounded-lg cursor-pointer 
                      hover:bg-white/60 transition flex items-center
                  "
                  onClick={() => item.href && router.push(item.href)}
                >
                  <Image
                    src={item.src}
                    alt={item.label || "icon"}
                    width={22}
                    height={22}
                    className="opacity-80 hover:opacity-100 transition"
                  />
                </div>
              )}

              {/* ---------- LOGOUT BUTTON ---------- */}
              {item.action === 'logout' ? (
                <button
                  onClick={() => signOut({ callbackUrl: '/login' })}
                  className="block w-full text-left rounded-lg px-3 py-2 transition hover:bg-white/60 text-slate-700"
                >
                  {item.label}
                </button>
              ) : item.href ? (
                /* ---------- NORMAL LINKS ---------- */
                <Link
                  href={item.href}
                  className={`block rounded-lg px-3 py-2 transition ${
                    isActive(item.href)
                      ? 'bg-[#366870] text-white'
                      : 'hover:bg-white/60 text-slate-700'
                  }`}
                >
                  {item.label}
                </Link>
              ) : (
                /* ---------- SECTION LABEL ---------- */
                <div className="px-3 py-2 text-slate-500 uppercase tracking-wide text-xs">
                  {item.label}
                </div>
              )}

              {/* ---------- CHILDREN LINKS ---------- */}
              {item.children && (
                <div className="mt-1 ml-2 space-y-1">
                  {item.children.map((child: any) => (
                    <Link
                      key={child.href}
                      href={child.href}
                      className={`block rounded-md px-3 py-2 transition ${
                        isActive(child.href)
                          ? 'bg-[#366870] text-white'
                          : 'hover:bg-white/60 text-slate-700'
                      }`}
                    >
                      {child.label}
                    </Link>
                  ))}
                </div>
              )}

            </div>
          ))}
        </nav>

      </div>
    </aside>
  )
}
