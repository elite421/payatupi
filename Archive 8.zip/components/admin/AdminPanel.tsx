"use client"

import { useEffect, useState } from 'react'

type UserRow = {
  id: string
  name: string
  email: string
  role: 'USER'|'ADMIN'
  subscription: { plan: string; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null } | null
}

export default function AdminPanel({ defaultTab, hideTabs }: { defaultTab?: 'dashboard'|'users'|'transactions'|'support'|'manage'; hideTabs?: boolean }){
  const [loading, setLoading] = useState(true)
  const [users, setUsers] = useState<UserRow[]>([])
  const [msg, setMsg] = useState<string|null>(null)
  const [detailOpen, setDetailOpen] = useState(false)
  const [detail, setDetail] = useState<any>(null)
  const [logs, setLogs] = useState<any[]>([])
  const [txs, setTxs] = useState<any[]>([])
  const [tab, setTab] = useState<'dashboard'|'users'|'transactions'|'support'|'manage'>(defaultTab || 'dashboard')
  const [stats, setStats] = useState<any>(null)
  const [q, setQ] = useState('')
  const [txList, setTxList] = useState<any[]>([])
  const [txLoading, setTxLoading] = useState(false)
  const [txFilter, setTxFilter] = useState<string>('all')
  const [txUserId, setTxUserId] = useState('')
  const [txTake, setTxTake] = useState<number>(50)
  const [tickets, setTickets] = useState<any[]>([])
  const [ticketLoading, setTicketLoading] = useState(false)
  const [ticketFilter, setTicketFilter] = useState<'all'|'OPEN'|'CLOSED'>('all')
  const [imgPreview, setImgPreview] = useState<string | null>(null)

  // Load functions remain the same...
  async function load(){
    setLoading(true)
    const r = await fetch('/api/admin/users', { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setUsers(await r.json())
  }

  async function loadTickets(){
    setTicketLoading(true)
    const url = new URL('/api/admin/support/tickets', window.location.origin)
    if (ticketFilter !== 'all') url.searchParams.set('status', ticketFilter)
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setTicketLoading(false)
    if (r.ok) setTickets(await r.json())
  }

  async function updateTicket(id: string, status: 'OPEN'|'CLOSED'){
    const r = await fetch(`/api/admin/support/tickets/${encodeURIComponent(id)}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (r.ok) { setMsg('Ticket updated'); await loadTickets() } else { setMsg('Failed to update ticket') }
  }

  async function loadStats(){
    try {
      const r = await fetch('/api/admin/dashboard/stats', { cache: 'no-store' })
      if (r.ok) setStats(await r.json())
    } catch {}
  }

  async function loadUsers(search?: string){
    setLoading(true)
    const url = new URL('/api/admin/users', window.location.origin)
    const qv = (search ?? q).trim()
    if (qv) url.searchParams.set('q', qv)
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setUsers(await r.json())
  }

  async function loadTransactions(){
    setTxLoading(true)
    const url = new URL('/api/admin/transactions', window.location.origin)
    if (txFilter !== 'all') url.searchParams.set('status', txFilter)
    if (txUserId.trim()) url.searchParams.set('userId', txUserId.trim())
    if (txTake) url.searchParams.set('take', String(txTake))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setTxLoading(false)
    if (r.ok) setTxList(await r.json())
  }

  useEffect(() => { 
    loadStats()
    loadUsers() 
  }, [])
  
  useEffect(() => { 
    if (tab === 'transactions') {
      const timer = setTimeout(() => loadTransactions(), 100) // Debounce
      return () => clearTimeout(timer)
    }
  }, [tab, txFilter, txUserId, txTake])
  
  useEffect(() => { 
    if (tab === 'support') {
      const timer = setTimeout(() => loadTickets(), 100) // Debounce
      return () => clearTimeout(timer)
    }
  }, [tab, ticketFilter])
  
  useEffect(() => { 
    const timer = setTimeout(() => load(), 100) // Debounce
    return () => clearTimeout(timer)
  }, [])

  async function save(u: UserRow, idx: number){
    const plan = (document.getElementById(`plan-${u.id}`) as HTMLSelectElement)?.value as any
    const status = (document.getElementById(`status-${u.id}`) as HTMLSelectElement)?.value as any
    const periodEnd = (document.getElementById(`end-${u.id}`) as HTMLInputElement)?.value
    const body: any = { plan, status }
    if (periodEnd) body.periodEnd = periodEnd
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    if (r.ok) { await loadUsers(); setMsg('Updated') } else { setMsg('Failed') }
  }

  async function extend(u: UserRow, days: number){
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ extendDays: days }) })
    if (r.ok) { await loadUsers(); setMsg(`Extended by ${days} days`) } else { setMsg('Failed') }
  }

  async function activate(u: UserRow){
    const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(u.id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'ACTIVE' }) })
    if (r.ok) { await loadUsers(); setMsg('Account activated') } else { setMsg('Failed to activate') }
  }

  async function openManage(u: UserRow){
    setDetailOpen(true)
    setDetail(null)
    setLogs([])
    setTxs([])
    try {
      const [pr, lr, tr] = await Promise.all([
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/profile`, { cache: 'no-store' }),
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/activities?take=50`, { cache: 'no-store' }),
        fetch(`/api/admin/users/${encodeURIComponent(u.id)}/transactions?take=50`, { cache: 'no-store' }),
      ])
      if (pr.ok) setDetail(await pr.json())
      if (lr.ok) setLogs(await lr.json())
      if (tr.ok) setTxs(await tr.json())
    } catch {}
  }

  async function updateKyc(userId: string){
    const status = (document.getElementById('kyc-status') as HTMLSelectElement)?.value
    const note = (document.getElementById('kyc-note') as HTMLInputElement)?.value
    const r = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/kyc`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status, adminNote: note }) })
    if (r.ok) {
      setMsg('KYC updated')
      const pr = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { cache: 'no-store' })
      if (pr.ok) setDetail(await pr.json())
    } else {
      setMsg('Failed to update KYC')
    }
  }

  async function saveProfile(userId: string){
    const name = (document.getElementById('profile-name') as HTMLInputElement)?.value
    const phone = (document.getElementById('profile-phone') as HTMLInputElement)?.value
    const role = (document.getElementById('profile-role') as HTMLSelectElement)?.value
    const r = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, phone, role }) })
    if (r.ok) {
      setMsg('Profile updated')
      const pr = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/profile`, { cache: 'no-store' })
      if (pr.ok) setDetail(await pr.json())
      await loadUsers()
    } else {
      setMsg('Failed to update profile')
    }
  }

  async function updateTxStatus(id: string, status: 'Pending'|'Success'|'Failed'){
    const r = await fetch(`/api/admin/transactions/${encodeURIComponent(id)}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (r.ok) {
      setMsg('Transaction updated')
      await loadTransactions()
    } else {
      setMsg('Failed to update transaction')
    }
  }

  function exportTxCsv(){
    const rows = [
      ['Date','User Name','User Email','Purpose','Amount','Status','Mode','UTR','Screenshot','PaymentID10'].join(',')
    ]
    for (const t of txList) {
      const base = Math.floor(new Date(t.createdAt).getTime()/1000).toString(36).toUpperCase()
      const suf = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g,'X')
      const pid = (base + suf).slice(0,10).padEnd(10,'0')
      const row = [
        new Date(t.createdAt).toLocaleString(),
        (t.user?.name || '').replaceAll(',',' '),
        (t.user?.email || ''),
        String(t.purpose || '').replaceAll(',',' '),
        String(t.amount || ''),
        String(t.status || ''),
        String(t.mode || ''),
        String(t.utr || ''),
        String(t.screenshotUrl || ''),
        pid,
      ]
      rows.push(row.join(','))
    }
    const blob = new Blob([rows.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'transactions.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  // Status badge components
  const StatusBadge = ({ status, children }: { status: string, children: React.ReactNode }) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium"
    const statusClasses = {
      'ACTIVE': 'bg-emerald-100 text-emerald-800',
      'CANCELED': 'bg-red-100 text-red-800',
      'PAST_DUE': 'bg-amber-100 text-amber-800',
      'Success': 'bg-emerald-100 text-emerald-800',
      'Pending': 'bg-amber-100 text-amber-800',
      'Failed': 'bg-red-100 text-red-800',
      'OPEN': 'bg-emerald-100 text-emerald-800',
      'CLOSED': 'bg-gray-100 text-gray-800',
      'APPROVED': 'bg-emerald-100 text-emerald-800',
      'PENDING': 'bg-amber-100 text-amber-800',
      'REJECTED': 'bg-red-100 text-red-800',
      'NOT_SUBMITTED': 'bg-gray-100 text-gray-800'
    }
    
    return (
      <span className={`${baseClasses} ${statusClasses[status as keyof typeof statusClasses] || 'bg-gray-100 text-gray-800'}`}>
        {children}
      </span>
    )
  }

  // Dynamic header title/subtitle based on current tab
  const headerTitle = (
    tab === 'dashboard' ? 'Dashboard' :
    tab === 'users' ? 'Users' :
    tab === 'transactions' ? 'Transactions' :
    tab === 'support' ? 'Support' :
    tab === 'manage' ? 'Manage User' : 'Admin'
  )
  const headerSubtitle = (
    tab === 'dashboard' ? 'Overview and key stats' :
    tab === 'users' ? 'Manage users and subscriptions' :
    tab === 'transactions' ? 'Monitor and update transactions' :
    tab === 'support' ? 'Handle support tickets' :
    tab === 'manage' ? 'Search and open a user to manage' : 'Administrative tools'
  )

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">{headerTitle}</h1>
              <p className="mt-2 text-slate-600">{headerSubtitle}</p>
            </div>
            {msg && (
              <div className="px-4 py-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 text-sm font-medium">
                {msg}
              </div>
            )}
          </div>

          {/* Tabs */}
          {!hideTabs && (
            <div className="mt-8 flex space-x-2">
              {(['dashboard', 'users', 'transactions', 'support', 'manage'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`px-6 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                    tab === t
                      ? 'bg-[#366870] text-white shadow-lg'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-white hover:shadow-md'
                  }`}
                >
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="p-8">
        {/* Dashboard Overview */}
        {tab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                label: 'Total Users', 
                value: stats?.totalUsers ?? '—', 
                color: 'blue',
                icon: (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" />
                  </svg>
                )
              },
              { 
                label: 'Active Subscribers', 
                value: stats?.activeSubscribers ?? '—', 
                color: 'emerald',
                icon: (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )
              },
              { 
                label: 'KYC Pending', 
                value: stats?.kycPending ?? '—', 
                color: 'amber',
                icon: (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )
              },
              { 
                label: 'Payments Pending', 
                value: stats?.txPending ?? '—', 
                color: 'rose',
                icon: (
                  <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                )
              }
            ].map((stat, index) => (
              <div key={index} className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm hover:shadow-md transition-all duration-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-slate-600 uppercase tracking-wide">{stat.label}</p>
                    <p className="text-3xl font-bold text-slate-900 mt-2">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-xl bg-${stat.color}-100`}>
                    <div className={`text-${stat.color}-600`}>
                      {stat.icon}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Manage Tab */}
        {tab === 'manage' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-slate-50/50">
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="flex-1 w-full">
                  <div className="relative max-w-md">
                    <input
                      value={q}
                      onChange={e => setQ(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') loadUsers() }}
                      placeholder="Search by name, email, or phone..."
                      className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white"
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => loadUsers()}
                  className="px-6 py-3 bg-[#366870] text-white rounded-xl hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] focus:ring-offset-2 transition-colors font-semibold shadow-sm"
                >
                  Search
                </button>
              </div>
            </div>

            <div className="overflow-hidden">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    {['User', 'Action'].map((header) => (
                      <th key={header} className="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {loading ? (
                    <tr>
                      <td colSpan={2} className="px-6 py-12 text-center">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        </div>
                        <p className="mt-2 text-sm text-slate-500">Loading users...</p>
                      </td>
                    </tr>
                  ) : users.length === 0 ? (
                    <tr>
                      <td colSpan={2} className="px-6 py-12 text-center text-slate-500">
                        <svg className="w-12 h-12 mx-auto text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p className="mt-2 text-slate-600">No users found</p>
                      </td>
                    </tr>
                  ) : (
                    users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div>
                            <div className="font-semibold text-slate-900">{u.name}</div>
                            <div className="text-sm text-slate-500">{u.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => openManage(u)}
                            className="px-4 py-2 bg-[#366870] text-white rounded-lg hover:bg-[#2f5b62] text-sm font-semibold"
                          >
                            Manage user
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {tab === 'users' && (
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-slate-50/50">
              <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <div className="flex-1 w-full">
                  <div className="relative max-w-md">
                    <input
                      value={q}
                      onChange={e => setQ(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') loadUsers() }}
                      placeholder="Search by name, email, or phone..."
                      className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white"
                    />
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => loadUsers()}
                  className="px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-semibold shadow-sm"
                >
                  Search
                </button>
              </div>
            </div>

            <div className="overflow-hidden">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    {['User', 'Plan', 'Status', 'Period End', 'Actions'].map((header) => (
                      <th key={header} className="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                        {header}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center">
                        <div className="flex justify-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        </div>
                        <p className="mt-2 text-sm text-slate-500">Loading users...</p>
                      </td>
                    </tr>
                  ) : users.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-slate-500">
                        <svg className="w-12 h-12 mx-auto text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <p className="mt-2 text-slate-600">No users found</p>
                      </td>
                    </tr>
                  ) : (
                    users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-4">
                          <div>
                            <div className="font-semibold text-slate-900">{u.name}</div>
                            <div className="text-sm text-slate-500">{u.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            id={`plan-${u.id}`}
                            defaultValue={u.subscription?.plan || 'FREE'}
                            onChange={() => save(u, 0)}
                            className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                          >
                            <option>FREE</option>
                            <option>INDIVIDUAL</option>
                            <option>ENTERPRISE</option>
                            <option>INDIVIDUAL_PLUS</option>
                            <option>ENTERPRISE_PLUS</option>
                            <option>TRIAL</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            id={`status-${u.id}`}
                            defaultValue={u.subscription?.status || 'ACTIVE'}
                            onChange={() => save(u, 0)}
                            className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                          >
                            <option>ACTIVE</option>
                            <option>CANCELED</option>
                            <option>PAST_DUE</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <input
                            id={`end-${u.id}`}
                            type="datetime-local"
                            defaultValue={u.subscription?.currentPeriodEnd ? new Date(u.subscription.currentPeriodEnd).toISOString().slice(0, 16) : ''}
                            onBlur={() => save(u, 0)}
                            className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <select
                            defaultValue=""
                            onChange={(e) => {
                              const v = e.target.value
                              if (!v) return
                              if (v === 'save') save(u, 0)
                              else if (v === 'activate') activate(u)
                              else if (v === 'extend30') extend(u, 30)
                              else if (v === 'extend365') extend(u, 365)
                              else if (v === 'manage') openManage(u)
                              e.currentTarget.selectedIndex = 0
                            }}
                            className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                          >
                            <option value="">Quick actions...</option>
                            <option value="save">Save subscription</option>
                            <option value="activate">Activate now</option>
                            <option value="extend30">Extend +30 days</option>
                            <option value="extend365">Extend +365 days</option>
                            <option value="manage">Manage user</option>
                          </select>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Transactions Tab */}
        {tab === 'transactions' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex flex-col lg:flex-row gap-4">
                <select
                  value={txFilter}
                  onChange={e => setTxFilter(e.target.value)}
                  className="flex-1 rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white py-3"
                >
                  <option value="all">All Status</option>
                  <option>Pending</option>
                  <option>Success</option>
                  <option>Failed</option>
                </select>
                <input
                  value={txUserId}
                  onChange={e => setTxUserId(e.target.value)}
                  placeholder="Filter by User ID"
                  className="flex-1 rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white py-3 px-4"
                />
                <select
                  value={String(txTake)}
                  onChange={e => setTxTake(parseInt(e.target.value) || 50)}
                  className="flex-1 rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white py-3"
                >
                  <option value="50">50 rows</option>
                  <option value="100">100 rows</option>
                  <option value="200">200 rows</option>
                </select>
                <div className="flex gap-2">
                  <button
                    onClick={loadTransactions}
                    className="px-6 py-3 bg-[#366870] text-white rounded-xl hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] transition-colors font-semibold shadow-sm"
                  >
                    Refresh
                  </button>
                  <button
                    onClick={exportTxCsv}
                    className="px-6 py-3 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 focus:ring-2 focus:ring-blue-500 transition-colors font-semibold flex items-center gap-2"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    Export CSV
                  </button>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      {['Date', 'Payment ID', 'User', 'Purpose', 'Amount', 'Status', 'Mode', 'UTR', 'Screenshot', 'Action'].map((header) => (
                        <th key={header} className="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {txLoading ? (
                      <tr>
                        <td colSpan={10} className="px-6 py-12 text-center">
                          <div className="flex justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                          </div>
                          <p className="mt-2 text-sm text-slate-500">Loading transactions...</p>
                        </td>
                      </tr>
                    ) : txList.length === 0 ? (
                      <tr>
                        <td colSpan={10} className="px-6 py-12 text-center text-slate-500">
                          <svg className="w-12 h-12 mx-auto text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
                          </svg>
                          <p className="mt-2 text-slate-600">No transactions found</p>
                        </td>
                      </tr>
                    ) : (
                      txList.map((t: any) => (
                        <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4 text-sm text-slate-900">
                            {new Date(t.createdAt).toLocaleString()}
                          </td>
                          <td className="px-6 py-4 text-sm font-mono text-slate-600">
                            {(() => {
                              const m = String(t.purpose || '').match(/PID:([^|]+)/i)
                              if (m && m[1]) return m[1].trim()
                              const b = Math.floor(new Date(t.createdAt).getTime() / 1000).toString(36).toUpperCase()
                              const s = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g, 'X')
                              return (b + s).slice(0, 10).padEnd(10, '0')
                            })()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-semibold text-slate-900">{t.user?.name || '—'}</div>
                            <div className="text-sm text-slate-500">{t.user?.email}</div>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-900">{(() => { const s = String(t.purpose || ''); return s.replace(/^PID:[^|]+\s*\|\s*/i, ''); })()}</td>
                          <td className="px-6 py-4 text-sm font-semibold text-slate-900">₹{t.amount}</td>
                          <td className="px-6 py-4">
                            <StatusBadge status={t.status}>
                              {t.status}
                            </StatusBadge>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-500">{t.mode || '—'}</td>
                          <td className="px-6 py-4 text-sm font-mono text-slate-600">{t.utr || '—'}</td>
                          <td className="px-6 py-4">
                            {t.screenshotUrl ? (
                              /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(t.screenshotUrl) ? (
                                <button
                                  onClick={() => setImgPreview(t.screenshotUrl)}
                                  className="inline-flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium"
                                >
                                  <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                  </svg>
                                  View
                                </button>
                              ) : (
                                <a
                                  href={t.screenshotUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium"
                                >
                                  <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                                  </svg>
                                  View
                                </a>
                              )
                            ) : (
                              <span className="text-slate-400 text-sm">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <select
                              defaultValue={t.status}
                              onChange={(e) => updateTxStatus(t.id, e.target.value as any)}
                              className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                            >
                              <option>Pending</option>
                              <option>Success</option>
                              <option>Failed</option>
                            </select>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Support Tab */}
        {tab === 'support' && (
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
              <div className="flex items-center gap-4">
                <select
                  value={ticketFilter}
                  onChange={e => setTicketFilter(e.target.value as any)}
                  className="flex-1 rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 bg-white py-3"
                >
                  <option value="all">All Tickets</option>
                  <option value="OPEN">Open</option>
                  <option value="CLOSED">Closed</option>
                </select>
                <button
                  onClick={loadTickets}
                  className="px-6 py-3 bg-[#366870] text-white rounded-xl hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] transition-colors font-semibold shadow-sm"
                >
                  Refresh
                </button>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      {['Date', 'User', 'Subject', 'Message', 'Attachment', 'Status', 'Action'].map((header) => (
                        <th key={header} className="px-6 py-4 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {ticketLoading ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center">
                          <div className="flex justify-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                          </div>
                          <p className="mt-2 text-sm text-slate-500">Loading tickets...</p>
                        </td>
                      </tr>
                    ) : tickets.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                          <svg className="w-12 h-12 mx-auto text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
                          </svg>
                          <p className="mt-2 text-slate-600">No tickets found</p>
                        </td>
                      </tr>
                    ) : (
                      tickets.map((t: any) => (
                        <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4 text-sm text-slate-900">
                            {new Date(t.createdAt).toLocaleString()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="text-sm font-semibold text-slate-900">{t.user?.name || '—'}</div>
                            <div className="text-sm text-slate-500">{t.user?.email}</div>
                          </td>
                          <td className="px-6 py-4 text-sm font-semibold text-slate-900">{t.subject}</td>
                          <td className="px-6 py-4 text-sm text-slate-600 max-w-xs">
                            <div className="line-clamp-2">{t.message}</div>
                          </td>
                          <td className="px-6 py-4">
                            {t.attachmentUrl ? (
                              /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(t.attachmentUrl) ? (
                                <button
                                  onClick={() => setImgPreview(t.attachmentUrl)}
                                  className="inline-flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium"
                                >
                                  <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                                  </svg>
                                  View
                                </button>
                              ) : (
                                <a
                                  href={t.attachmentUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="inline-flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium"
                                >
                                  <svg className="w-4 h-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                                  </svg>
                                  View
                                </a>
                              )
                            ) : (
                              <span className="text-slate-400 text-sm">—</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <StatusBadge status={t.status}>
                              {t.status}
                            </StatusBadge>
                          </td>
                          <td className="px-6 py-4">
                            <select
                              defaultValue={t.status}
                              onChange={(e) => updateTicket(t.id, e.target.value as 'OPEN' | 'CLOSED')}
                              className="block w-full rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm bg-white"
                            >
                              <option value="OPEN">OPEN</option>
                              <option value="CLOSED">CLOSED</option>
                            </select>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* User Detail Modal */}
      {detailOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl my-8 border border-slate-200">
            <div className="flex items-center justify-between p-6 border-b border-[#366870] bg-[#366870] text-white rounded-t-2xl">
              <div>
                <h2 className="text-2xl font-bold text-white">Manage User</h2>
                <p className="text-white/80 mt-1">Detailed user information and management</p>
              </div>
              <button
                onClick={() => setDetailOpen(false)}
                className="p-2 hover:bg-white/10 rounded-xl transition-colors"
              >
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {!detail ? (
              <div className="p-12 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                <p className="mt-4 text-slate-500">Loading user details...</p>
              </div>
            ) : (
              <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 max-h-[70vh] overflow-y-auto">
                {/* Left Column - Profile Info */}
                <div className="space-y-6">
                  {/* Profile Card */}
                  <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 text-lg">Profile Information</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Name</label>
                        <input
                          id="profile-name"
                          defaultValue={detail.name}
                          className="w-full rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm py-3 px-4 bg-slate-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Email</label>
                        <input
                          disabled
                          value={detail.email}
                          className="w-full rounded-xl border-slate-300 bg-slate-100 text-slate-600 text-sm py-3 px-4"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Phone</label>
                        <input
                          id="profile-phone"
                          defaultValue={detail.phone || ''}
                          className="w-full rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm py-3 px-4 bg-slate-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Role</label>
                        <select
                          id="profile-role"
                          defaultValue={detail.role}
                          className="w-full rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm py-3 px-4 bg-slate-50"
                        >
                          <option>USER</option>
                          <option>ADMIN</option>
                        </select>
                      </div>
                      <button
                        onClick={() => saveProfile(detail.id)}
                        className="w-full bg-[#366870] text-white py-3 px-4 rounded-xl hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] transition-colors font-semibold shadow-sm"
                      >
                        Save Profile
                      </button>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-200 text-xs text-slate-500">
                      Joined: {new Date(detail.createdAt).toLocaleString()}
                    </div>
                  </div>

                  {/* Subscription Card */}
                  <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 text-lg">Subscription</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between items-center py-2 border-b border-slate-100">
                        <span className="text-slate-600">Plan:</span>
                        <span className="font-semibold text-slate-900">{detail.subscription?.plan || 'FREE'}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-slate-100">
                        <span className="text-slate-600">Status:</span>
                        <StatusBadge status={detail.subscription?.status || 'ACTIVE'}>
                          {detail.subscription?.status || 'ACTIVE'}
                        </StatusBadge>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-slate-600">Period End:</span>
                        <span className="font-semibold text-slate-900">
                          {detail.subscription?.currentPeriodEnd ? 
                            new Date(detail.subscription.currentPeriodEnd).toLocaleDateString() : '—'
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Middle Column - KYC */}
                <div className="space-y-6">
                  <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 text-lg">KYC Verification</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <span className="text-sm text-slate-600">Current Status:</span>
                        <StatusBadge status={detail.kyc?.status || 'NOT_SUBMITTED'}>
                          {detail.kyc?.status || 'NOT_SUBMITTED'}
                        </StatusBadge>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Update Status</label>
                        <select
                          id="kyc-status"
                          defaultValue={detail.kyc?.status || 'NOT_SUBMITTED'}
                          className="w-full rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm py-3 px-4 bg-slate-50"
                        >
                          <option>NOT_SUBMITTED</option>
                          <option>PENDING</option>
                          <option>APPROVED</option>
                          <option>REJECTED</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Admin Note</label>
                        <input
                          id="kyc-note"
                          placeholder="Add a note..."
                          defaultValue={detail.kyc?.adminNote || ''}
                          className="w-full rounded-xl border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm py-3 px-4 bg-slate-50"
                        />
                      </div>
                      <button
                        onClick={() => updateKyc(detail.id)}
                        className="w-full bg-[#366870] text-white py-3 px-4 rounded-xl hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] transition-colors font-semibold shadow-sm"
                      >
                        Update KYC
                      </button>
                      {(detail.kyc?.documentUrl || detail.kyc?.selfieUrl) && (
                        <div className="pt-4 border-t border-slate-200">
                          <h4 className="text-sm font-semibold text-slate-700 mb-3">Documents</h4>
                          <div className="space-y-2">
                            {detail.kyc?.documentUrl && (
                              /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(detail.kyc.documentUrl) ? (
                                <button
                                  onClick={() => setImgPreview(detail.kyc.documentUrl)}
                                  className="flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium p-2 hover:bg-slate-50 rounded-lg transition-colors"
                                >
                                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                  View Document
                                </button>
                              ) : (
                                <a
                                  href={detail.kyc.documentUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium p-2 hover:bg-slate-50 rounded-lg transition-colors"
                                >
                                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                  </svg>
                                  View Document
                                </a>
                              )
                            )}
                            {detail.kyc?.selfieUrl && (
                              /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(detail.kyc.selfieUrl) ? (
                                <button
                                  onClick={() => setImgPreview(detail.kyc.selfieUrl)}
                                  className="flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium p-2 hover:bg-slate-50 rounded-lg transition-colors"
                                >
                                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                  </svg>
                                  View Selfie
                                </button>
                              ) : (
                                <a
                                  href={detail.kyc.selfieUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="flex items-center text-blue-600 hover:text-blue-500 text-sm font-medium p-2 hover:bg-slate-50 rounded-lg transition-colors"
                                >
                                  <svg className="w-4 h-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                  </svg>
                                  View Selfie
                                </a>
                              )
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Column - Activity & Transactions */}
                <div className="lg:col-span-1 space-y-6">
                  {/* Activity Logs */}
                  <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 text-lg">Recent Activity</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto">
                      {logs.length === 0 ? (
                        <p className="text-sm text-slate-500 text-center py-4">No activity logs</p>
                      ) : (
                        logs.map((log) => (
                          <div key={log.id} className="text-sm border-l-2 border-blue-500 pl-3 py-2 bg-blue-50/50 rounded-r-lg">
                            <div className="font-semibold text-slate-900">{log.type}</div>
                            <div className="text-slate-600 text-xs mt-1">{log.message || '—'}</div>
                            <div className="text-slate-400 text-xs mt-2">
                              {new Date(log.createdAt).toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Transactions */}
                  <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
                    <h3 className="font-bold text-slate-900 mb-4 text-lg">Recent Transactions</h3>
                    <div className="space-y-3 max-h-48 overflow-y-auto">
                      {txs.length === 0 ? (
                        <p className="text-sm text-slate-500 text-center py-4">No transactions</p>
                      ) : (
                        txs.map((t) => (
                          <div key={t.id} className="text-sm border-l-2 border-emerald-500 pl-3 py-2 bg-emerald-50/50 rounded-r-lg">
                            <div className="flex justify-between items-start">
                              <div>
                                <div className="font-semibold text-slate-900">{(() => { const s = String(t.purpose || ''); return s.replace(/^PID:[^|]+\s*\|\s*/i, ''); })()}</div>
                                <div className="text-slate-600 text-xs mt-1">₹{t.amount}</div>
                              </div>
                              <select
                                defaultValue={t.status}
                                onChange={(e) => updateTxStatus(t.id, e.target.value as any)}
                                className="text-xs rounded-lg border-slate-300 focus:border-blue-500 focus:ring-blue-500 bg-white"
                              >
                                <option>Pending</option>
                                <option>Success</option>
                                <option>Failed</option>
                              </select>
                            </div>
                            <div className="text-slate-400 text-xs mt-2">
                              {new Date(t.createdAt).toLocaleString()}
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {imgPreview && (
        <div onClick={() => setImgPreview(null)} className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 p-4">
          <img src={imgPreview || ''} alt="" className="max-h-[90vh] max-w-[90vw] rounded shadow-lg" />
        </div>
      )}
    </div>
  )
}