-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "buyerEmail" TEXT,
ADD COLUMN     "buyerName" TEXT,
ADD COLUMN     "buyerPhone" TEXT,
ADD COLUMN     "screenshotUrl" TEXT;
