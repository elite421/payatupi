/*
  Warnings:

  - A unique constraint covering the columns `[userId,utr]` on the table `Transaction` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateTable
CREATE TABLE "SmsCallbackLog" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "utr" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "amount" INTEGER,
    "payerUpiId" TEXT,
    "bank" TEXT,
    "ip" TEXT,
    "method" TEXT,
    "raw" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SmsCallbackLog_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SmsCallbackLog_userId_utr_idx" ON "SmsCallbackLog"("userId", "utr");

-- CreateIndex
CREATE UNIQUE INDEX "Transaction_userId_utr_key" ON "Transaction"("userId", "utr");

-- AddForeignKey
ALTER TABLE "SmsCallbackLog" ADD CONSTRAINT "SmsCallbackLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
