-- AlterTable
ALTER TABLE "CheckoutSettings" ADD COLUMN     "advertisementImageUrl" TEXT,
ADD COLUMN     "advertisementLink" TEXT,
ADD COLUMN     "checkoutMessage" TEXT,
ADD COLUMN     "enableEmail" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "enableName" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "enablePhone" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "enablePurpose" BOOLEAN NOT NULL DEFAULT true;
