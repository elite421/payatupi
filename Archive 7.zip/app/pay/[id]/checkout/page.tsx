import { prisma } from '@/lib/prisma'
import type { Metadata } from 'next'
import { notFound, redirect } from 'next/navigation'
import { cookies } from 'next/headers'
import UpiModal from '@/components/pay/UpiModal'
import HideDuringUtr from '@/components/pay/HideDuringUtr'
import { planEntitlements } from '@/lib/subscription'
import Image from "next/image"
import DownloadQRButton from '@/components/pay/DownloadQR'

function genPaymentId(len = 12) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let out = ''
  for (let i = 0; i < len; i++) out += chars[Math.floor(Math.random() * chars.length)]
  return out
}

function looksLikeCuid(s: string) {
  return typeof s === 'string' && s.length >= 24 && s.startsWith('c')
}

async function getLinkByIdOrSlug(idOrSlug: string) {
  if (looksLikeCuid(idOrSlug)) {
    const byId = await prisma.paymentLink
      .findUnique({
        where: { id: idOrSlug },
        select: {
          id: true,
          userId: true,
          amount: true,
          title: true,
          redirectUrl: true,
          active: true,
          user: { select: { name: true, publicId: true } },
        },
      })
      .catch(() => null)
    if (byId && byId.active) return byId
  }
  const bySlug = await prisma.paymentLink
    .findFirst({
      where: { slug: idOrSlug, active: true },
      select: {
        id: true,
        userId: true,
        amount: true,
        title: true,
        redirectUrl: true,
        active: true,
        user: { select: { name: true, publicId: true } },
      },
    })
    .catch(() => null)
  return bySlug
}

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: 'Checkout - Payatupi',
    description: 'Accept free and unlimited online payments with instant bank settlement with Payatupi.',
    keywords: [
      'UPI payment gateway',
      'UPI payment link',
      'UPI payment gateway plugin',
      'free payment gateway',
      'NEFT',
      'IMPS',
      'payment gateway',
      'best payment gateway',
    ],
  }
}

export default async function CheckoutPage({ params, searchParams }: { params: Promise<{ id: string }>, searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const { id } = await params
  const sp = await searchParams as Record<string, string | string[] | undefined>
  const link = await getLinkByIdOrSlug(id)
  if (!link) return notFound()

  // Merchant eligibility gating temporarily disabled for testing

  const settings = await (prisma as any).checkoutSettings.findUnique({ where: { userId: link.userId }, select: { logoUrl: true, advertisementImageUrl: true, advertisementLink: true, successRedirectUrl: true, maskMerchantName: true, maskedMerchantName: true, themeColor: true, checkoutMessage: true } }).catch(()=>null)
  const dp = (settings as any)?.logoUrl || '/file.svg'
  const rawName = link.user?.name || 'Merchant'
  const displayName = (((settings as any)?.maskMerchantName) ? (((settings as any)?.maskedMerchantName || '').trim() || 'Merchant') : rawName)
  const themeColor = String((settings as any)?.themeColor || '').trim() || '#366870'
  const checkoutMessage = String((settings as any)?.checkoutMessage || '').trim()

  const upiAccount = await prisma.uPIAccount
    .findFirst({ where: { userId: link.userId, active: true } as any, select: { upiId: true }, orderBy: { createdAt: 'desc' } as any })
    .catch(() => null)
  const upiId = (upiAccount as any)?.upiId || ''

  const bank = await prisma.bankAccount
    .findFirst({ where: { userId: link.userId, active: true } as any, select: { accountHolder: true, accountNumber: true, ifsc: true, bankName: true }, orderBy: { createdAt: 'desc' } as any })
    .catch(() => null) as any

  // Ads entitlement: only Enterprise tiers (and legacy BUSINESS)
  const sub = await prisma.subscription.findUnique({ where: { userId: link.userId }, select: { plan: true, status: true, currentPeriodEnd: true } }).catch(()=>null)
  const adsEntitled = (() => {
    if (!sub) return false
    const end = sub.currentPeriodEnd ? sub.currentPeriodEnd.getTime() : 0
    const activeSub = sub.status === 'ACTIVE' && (end === 0 || end > Date.now()) && sub.plan !== 'FREE'
    const ent = planEntitlements((sub as any).plan)
    return activeSub && ent.checkoutAds
  })()

  const ck = await cookies()
  const rawCk = ck.get(`chk_${id}`)?.value || ''
  let ckObj: any = null
  try { ckObj = rawCk ? JSON.parse(decodeURIComponent(rawCk)) : null } catch {}

  let chosenAmount: number | null = (link.amount != null && link.amount > 0) ? link.amount : null
  if (chosenAmount == null) {
    const spVal = typeof sp?.amount === 'string' ? sp.amount : Array.isArray(sp?.amount) ? sp?.amount[0] : undefined
    const parsed = spVal != null ? Number(spVal) : NaN
    if (Number.isFinite(parsed) && parsed > 0) {
      chosenAmount = Math.round(parsed)
    } else {
      const cka = Number(ckObj?.amount)
      if (Number.isFinite(cka) && cka > 0) chosenAmount = Math.round(cka)
    }
  }
  if (!chosenAmount || chosenAmount <= 0) {
    // Missing amount for variable link: send the user back to the amount entry page instead of 404
    redirect(`/pay/${encodeURIComponent(id)}`)
  }

  const buyerName = (typeof sp?.name === 'string' ? sp.name : Array.isArray(sp?.name) ? sp?.name[0] : '') || (ckObj?.name || '')
  const buyerPhone = (typeof sp?.phone === 'string' ? sp.phone : Array.isArray(sp?.phone) ? sp?.phone[0] : '') || (ckObj?.phone || '')
  const buyerEmail = (typeof sp?.email === 'string' ? sp.email : Array.isArray(sp?.email) ? sp?.email[0] : '') || (ckObj?.email || '')
  const pid = (typeof sp?.pid === 'string' ? sp.pid : Array.isArray(sp?.pid) ? sp?.pid[0] : '') || (ckObj?.pid || '')
  const purpose = (() => {
    const p = (typeof sp?.purpose === 'string' ? sp.purpose : Array.isArray(sp?.purpose) ? sp?.purpose[0] : '') || (ckObj?.purpose || '')
    const base = (p || '').trim()
    const withPid = (pid || '').trim() ? `PID:${(pid || '').trim()} | ${base || (link as any).title || ''}` : (base || (link as any).title || '')
    return withPid
  })()

  const paymentId = pid || genPaymentId()
  const upiQr = upiId ? `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(displayName)}&am=${encodeURIComponent(String(chosenAmount))}&tn=${encodeURIComponent(paymentId)}&cu=INR` : ''
  const qrImg = upiQr ? `https://quickchart.io/qr?size=160&text=${encodeURIComponent(upiQr)}` : ''

  return (
    <>
    <script dangerouslySetInnerHTML={{ __html: `
(function(){try{if(typeof window!=='undefined'){var qs=new URLSearchParams(window.location.search);if(qs.toString()){var data={amount:qs.get('amount'),name:qs.get('name'),purpose:qs.get('purpose'),pid:qs.get('pid'),r:qs.get('r')};var k='chk_'+encodeURIComponent('${id}');var v=encodeURIComponent(JSON.stringify(data));var p='; path=/pay/${encodeURIComponent(id)}; Max-Age=1800';document.cookie=k+'='+v+p+'; SameSite=Lax';var u=window.location.pathname+window.location.hash;window.history.replaceState({},document.title,u);}}}catch(e){}})();
` }} />
    <style dangerouslySetInnerHTML={{ __html: `
      #bank { display: none; }
      #upi { display: block; }
      #bank:target { display: block; }
      #bank:target ~ #upi { display: none; }
      #bank .bank-details{display:none}
      #bank:target .bank-details{display:block}
      .action-bar .next-btn-bank { display: none; }
      #bank:target ~ .action-bar .next-btn-upi { display: none; }
      #bank:target ~ .action-bar .next-btn-bank { display: inline-flex; }
      :root:has(#bank:target) a.tab-upi { background-color: #f1f5f9 !important; color: ${themeColor} !important; }
      :root:has(#bank:target) a.tab-bank { background-color: ${themeColor} !important; color: #ffffff !important; }
    ` }} />
    <div className="w-full flex justify-center py-10">
      <div className="w-full max-w-lg rounded-xl bg-white text-black shadow-md">
        {/* Header */}
        <div className="flex items-center gap-3 p-4 text-white" style={{ backgroundColor: themeColor }}>
          <div className="shrink-0">
            <img src={dp} alt="Logo" className="h-12 w-12 rounded-full object-cover border" />
          </div>
          <div className="flex-1">
            <div className="text-xs text-white/80">Paying to</div>
            <div className="flex items-center gap-2">
              <div className="text-base font-semibold">{displayName}</div>
              <span title="KYC Verified">
                <img src="/verified.png" alt="KYC Verified" className="h-4 w-4" />
              </span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="mb-4 text-sm">
            <div className="flex items-center justify-between"><span>Payment ID</span><span className="font-mono">{paymentId}</span></div>
            <div className="flex items-center justify-between mt-1"><span>Amount</span><span className="font-semibold">₹ {chosenAmount}</span></div>
            {link.user?.publicId ? (
              <div className="flex items-center justify-between mt-1"><span>Public ID</span><span className="font-mono">{link.user.publicId}</span></div>
            ) : null}
            {purpose ? (
              <div className="flex items-center justify-between mt-1"><span>Purpose</span><span className="truncate max-w-[60%] text-right" title={purpose}>{purpose}</span></div>
            ) : null}
          </div>

          <div className="mt-4">
            <div className="grid grid-cols-2 gap-2">
              <a href="#upi" className="tab-upi px-3 py-2 rounded-md text-white text-center" style={{ backgroundColor: themeColor }}>UPI</a>
              <a href="#bank" className="tab-bank px-3 py-2 rounded-md bg-slate-100 text-center" style={{ color: themeColor }}>Bank</a>
            </div>
          </div>

          {/* Advertisement on checkout page */}
          {adsEntitled && (settings as any)?.advertisementImageUrl && (
            <div className="mt-4 rounded-lg overflow-hidden ring-1 ring-slate-200">
              { (settings as any)?.advertisementLink ? (
                <a href={(settings as any).advertisementLink} target="_blank" rel="noreferrer" className="block">
                  <img src={(settings as any).advertisementImageUrl} alt="Advertisement" className="w-full h-40 sm:h-52 md:h-60 object-cover" />
                </a>
              ) : (
                <img src={(settings as any).advertisementImageUrl} alt="Advertisement" className="w-full h-40 sm:h-52 md:h-60 object-cover" />
              )}
            </div>
          )}

          {checkoutMessage && (
            <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">
              {checkoutMessage}
            </div>
          )}

          <HideDuringUtr>
            {/* Bank block */}
            <div id="bank" className="mt-6 text-sm">
              <div className="flex items-center justify-between">
                <div className="font-medium">Bank Transfer</div>
              </div>
              {!bank ? (
                <div className="mt-2 rounded-md border p-3 bg-slate-50 text-slate-600">user does not enable the bank services yet.</div>
              ) : (
                <div className="mt-3 rounded-md border p-3 bank-details">
                  <div className="grid grid-cols-1 gap-2 text-slate-800">
                    <div className="flex items-center justify-between"><span>Account Holder</span><span className="font-medium">{bank.accountHolder}</span></div>
                    <div className="flex items-center justify-between"><span>Bank</span><span className="font-medium">{bank.bankName}</span></div>
                    <div className="flex items-center justify-between"><span>Account No.</span><span className="font-mono">{bank.accountNumber}</span></div>
                    <div className="flex items-center justify-between"><span>IFSC</span><span className="font-mono">{bank.ifsc}</span></div>
                  </div>
                </div>
              )}
            </div>

            {/* UPI block */}
            <div id="upi" className="mt-4">
              <div className="flex items-center justify-between text-sm">
                <div className="font-medium">Pay With UPI &nbsp;
                   {qrImg ? (
                  <DownloadQRButton
                    qrUrl={qrImg}
                    publicId={link.user?.publicId || null}
                    paymentId={paymentId}
                    themeColor={themeColor}
                  />
                ) : null}
                </div>
                {/* <a className="inline-flex items-center gap-1 px-4 py-2 rounded-md bg-blue-600 text-white shadow hover:bg-blue-700" href="#upi-modal-upi">
                  Next
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/></svg>
                </a> */}
              </div>

              <div className="mt-3 flex items-center gap-4">
                <div className="rounded-md border p-3">
                  {qrImg ? (
                    <img src={qrImg} alt="UPI QR Code" className="h-32 w-32" />
                  ) : (
                    <div className="text-xs text-slate-600">UPI not enabled</div>
                  )}
                </div>
                <div className="text-xs text-slate-600">
                 
                  <div>Scan the QR using any UPI app on your phone</div>
                  <div><Image src="/app_logo.png" alt="logos" width={280} height={10} /></div>
                </div>
                
              </div>
            </div>

            <div className="action-bar mt-6 pt-4 border-t flex justify-end">
              {upiId ? (
                <a className="next-btn-upi inline-flex items-center gap-1 px-4 py-2 rounded-md bg-[#366870] text-white shadow hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870]" href="#upi-modal-upi">
                  Next
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/></svg>
                </a>
              ) : null}
              {bank && (
                <a className="next-btn-bank inline-flex items-center gap-1 px-4 py-2 rounded-md bg-[#366870] text-white shadow hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870]" href="#upi-modal-bank">
                  Next
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7"/></svg>
                </a>
              )}
            </div>
          </HideDuringUtr>

          {/* UPI Modal with Confirm handler */}
          <UpiModal
            paymentId={paymentId}
            displayName={displayName}
            upiId={upiId}
            amount={chosenAmount}
            linkIdOrSlug={id}
            buyerName={buyerName}
            buyerPhone={buyerPhone || undefined}
            buyerEmail={buyerEmail || undefined}
            purpose={purpose}
            adImageUrl={adsEntitled ? (settings?.advertisementImageUrl || null) : null}
            adLink={adsEntitled ? (settings?.advertisementLink || null) : null}
            redirectUrl={(typeof sp?.r === 'string' ? sp.r : Array.isArray(sp?.r) ? sp.r[0] : '') || (ckObj?.r || '') || link.redirectUrl || settings?.successRedirectUrl || null}
            themeColor={themeColor}
          />
        </div>
      </div>
    </div>
    <div className="fixed bottom-3 right-3 text-xs">
      <span className="rounded-full bg-slate-900/90 text-white px-3 py-1 shadow-lg">
        powered by <span className="font-semibold">payatupi</span>
      </span>
    </div>
    </>
  )
}
