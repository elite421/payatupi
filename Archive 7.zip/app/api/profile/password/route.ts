import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { verifyPassword, hashPassword } from '@/lib/password'

export async function POST(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { currentPassword, newPassword } = body || {}
  if (!currentPassword || !newPassword) return new Response(JSON.stringify({ error: 'Both passwords required' }), { status: 400 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const ok = await verifyPassword(currentPassword, user.password)
  if (!ok) return new Response(JSON.stringify({ error: 'Current password incorrect' }), { status: 400 })
  const hashed = await hashPassword(newPassword)
  await prisma.user.update({ where: { id: user.id }, data: { password: hashed } })
  return new Response(JSON.stringify({ ok: true }), { status: 200 })
}
