import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { randomBytes } from 'crypto'
import { hasEntitlement } from '@/lib/subscription'

function generateKey() {
  const raw = randomBytes(24).toString('hex')
  const prefix = raw.slice(0, 8)
  return { raw, prefix }
}

export async function POST() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const allowed = await hasEntitlement(user.id, 'apiAccess')
  if (!allowed) return new Response(JSON.stringify({ error: 'Requires Enterprise plan' }), { status: 403 })

  const ipCount = await prisma.allowedIp.count({ where: { userId: user.id } })
  if (ipCount === 0) {
    return new Response(JSON.stringify({ error: 'ip_required' }), { status: 400 })
  }

  // Revoke all existing keys
  await prisma.apiKey.updateMany({ where: { userId: user.id, revoked: false }, data: { revoked: true } })

  // Create a new key
  const { raw, prefix } = generateKey()
  const hashedKey = await bcrypt.hash(raw, 10)
  const key = await prisma.apiKey.create({ data: { userId: user.id, prefix, hashedKey } })

  return new Response(JSON.stringify({ id: key.id, key: raw, prefix }), { status: 201 })
}
