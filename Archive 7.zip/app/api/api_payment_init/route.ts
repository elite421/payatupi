import { prisma } from '@/lib/prisma'
import bcrypt from 'bcryptjs'
import { getMerchantEligibility } from '@/lib/eligibility'
import { logApiRequest } from '@/lib/api-logging'
import { getClientIp } from '@/lib/ip'
import { isValidPublicId, findUserByPublicId } from '@/lib/user-id'

function originFromRequest(req: Request) {
  const u = new URL(req.url)
  const proto = (req.headers.get('x-forwarded-proto') || u.protocol || 'http:').replace(':','')
  const host = req.headers.get('x-forwarded-host') || req.headers.get('host') || u.host
  return `${proto}://${host}`
}

export async function POST(req: Request) {
  try {
    const endpoint = new URL(req.url).pathname
    const body = await req.json().catch(() => ({} as any))
    const payload = body?.init_payment || body || {}

    const accountId = String(payload.account_id || '').trim()
    const secretKey = String(payload.secret_key || '').trim()
    const paymentId = String(payload.payment_id || '').trim()
    const purposeIn = String(payload.payment_purpose || '').trim()
    const amountStr = String(payload.payment_amount || '').trim()
    const buyerName = String(payload.payment_name || '').trim()
    const redirectUrlIn = String(payload.redirect_url || '').trim()

    const amount = Number(amountStr)
    if (!accountId || !secretKey || !paymentId || !Number.isFinite(amount) || amount <= 0 || !redirectUrlIn) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_request', req })
      return new Response(JSON.stringify({ error: 'invalid_request' }), { status: 400 })
    }

    let user = null as any
    if (isValidPublicId(accountId)) {
      user = await findUserByPublicId(accountId)
    }
    if (!user) {
      user = await prisma.user.findUnique({ where: { id: accountId } })
    }
    if (!user) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_account', req })
      return new Response(JSON.stringify({ error: 'invalid_account' }), { status: 400 })
    }

    const prefix = secretKey.slice(0, 8)
    const key = await prisma.apiKey.findFirst({ where: { userId: user.id, prefix, revoked: false } })
    if (!key) {
      await logApiRequest({ endpoint, method: 'POST', code: 401, status: 'ERROR', reason: 'invalid_key', req, userId: user.id })
      return new Response(JSON.stringify({ error: 'invalid_key' }), { status: 401 })
    }
    const ok = await bcrypt.compare(secretKey, key.hashedKey)
    if (!ok) {
      await logApiRequest({ endpoint, method: 'POST', code: 401, status: 'ERROR', reason: 'invalid_key', req, userId: user.id, apiKeyId: key.id })
      return new Response(JSON.stringify({ error: 'invalid_key' }), { status: 401 })
    }

    const ip = getClientIp(req)
    const count = await prisma.allowedIp.count({ where: { userId: user.id } })
    if (count === 0) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'ip_not_allowed', req, userId: user.id, apiKeyId: key.id, metadata: { ip, allowlist: 'empty' } })
      return new Response(JSON.stringify({ error: 'ip_not_allowed' }), { status: 403 })
    }
    const exists = ip ? await prisma.allowedIp.findFirst({ where: { userId: user.id, ip } }) : null
    if (!exists) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'ip_not_allowed', req, userId: user.id, apiKeyId: key.id, metadata: { ip } })
      return new Response(JSON.stringify({ error: 'ip_not_allowed' }), { status: 403 })
    }

    const eligibility = await getMerchantEligibility(user.id)
    if (!eligibility.eligible) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'subscription_inactive', req, userId: user.id, apiKeyId: key.id, metadata: { subscription: eligibility.subscription } })
      return new Response(JSON.stringify({ error: 'subscription_inactive' }), { status: 403 })
    }

    let link = await prisma.paymentLink.findFirst({ where: { userId: user.id, type: 'DEFAULT', active: true } as any, select: { id: true } }).catch(()=>null)
    if (!link) {
      link = await prisma.paymentLink.create({ data: { userId: user.id, type: 'DEFAULT' as any, title: 'Payments', active: true }, select: { id: true } })
    }

    const base = originFromRequest(req)
    const params = new URLSearchParams()
    params.set('amount', String(Math.round(amount)))
    if (buyerName) params.set('name', buyerName)
    if (purposeIn) params.set('purpose', purposeIn)
    params.set('pid', paymentId)
    params.set('r', redirectUrlIn)

    const pay_url = `${base}/pay/${link!.id}/checkout?${params.toString()}`
    await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, apiKeyId: key.id, metadata: { paymentId } })
    return new Response(JSON.stringify({ ok: true, pay_url }), { status: 200 })
  } catch (err) {
    const endpoint = (()=>{ try { return new URL(req.url).pathname } catch { return '/api/api_payment_init' } })()
    console.error('Payment init error:', err)
    await logApiRequest({ endpoint, method: 'POST', code: 500, status: 'ERROR', reason: 'server_error', req })
    return new Response(JSON.stringify({ error: 'server_error' }), { status: 500 })
  }
}
