import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

function formatTimestamp(date: Date) {
  const pad = (n: number) => n.toString().padStart(2, '0')
  const d = new Date(date)
  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)
  const year = d.getFullYear()
  let hours = d.getHours()
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12
  if (hours === 0) hours = 12
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())
  return `${day}-${month}-${year} ${pad(hours)}:${minutes}:${seconds} ${ampm}`
}

export async function GET(req: Request) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })

  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const url = new URL(req.url)
  const i = (url.searchParams.get('i') || '').toLowerCase()
  const takeRaw = url.searchParams.get('take')
  const take = Math.min(Math.max(parseInt(takeRaw || '0') || 0, 0), 1000) || undefined

  const where: any = {
    userId: user.id,
    AND: [
      { NOT: { purpose: { startsWith: 'subscription ', mode: 'insensitive' } } },
      { OR: [ { mode: null }, { mode: { not: 'SUBSCRIPTION' } } ] },
    ],
  }
  if (i === 'today') {
    const now = new Date()
    where.createdAt = { gte: new Date(now.getFullYear(), now.getMonth(), now.getDate()) }
  } else if (i === 'pending') {
    where.status = 'Pending'
  } else if (i === 'success') {
    where.status = 'Success'
  } else if (i === 'failed') {
    where.status = 'Failed'
  }

  const txs = await (prisma as any).transaction.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    ...(take ? { take } : {}),
  })

  const items = (txs as any[]).map((t) => ({
    id: t.id,
    timestamp: formatTimestamp(t.createdAt),
    purpose: t.purpose,
    amount: t.amount,
    utr: t.utr ?? null,
    screenshot: t.screenshotUrl ?? null,
    status: t.status as 'Pending' | 'Success' | 'Failed',
    name: t.buyerName ?? null,
    phone: t.buyerPhone ?? null,
    email: t.buyerEmail ?? null,
    payMode: t.mode ? (["UPI", "BANK"].includes(String(t.mode).toUpperCase()) ? (String(t.mode).toUpperCase() as 'UPI' | 'BANK') : 'NA') : 'NA',
    payUpiId: t.upiId ?? null,
    payAccountNumber: t.accountNumber ?? null,
    payIfsc: t.ifsc ?? null,
  }))

  return new Response(JSON.stringify({ items }), { status: 200 })
}
