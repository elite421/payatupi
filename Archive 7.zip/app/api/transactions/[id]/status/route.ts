import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

const ALLOWED: Array<'Pending' | 'Success' | 'Failed'> = ['Pending', 'Success', 'Failed']

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await auth()
    if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })

    const user = await prisma.user.findUnique({ where: { email: session.user.email } })
    if (!user) return new Response('Unauthorized', { status: 401 })

    const { id } = await params
    if (!id) return new Response('Missing id', { status: 400 })

    const body = await req.json().catch(() => ({})) as { status?: string }
    const statusIn = body?.status
    if (!statusIn || !ALLOWED.includes(statusIn as any)) {
      return new Response(JSON.stringify({ error: 'Invalid status' }), { status: 400 })
    }

    const tx = await prisma.transaction.findUnique({ where: { id } })
    if (!tx || tx.userId !== user.id) {
      return new Response('Not found', { status: 404 })
    }

    try {
      await (prisma as any).transaction.update({ where: { id }, data: { status: statusIn, statusSource: 'MANUAL' } })
    } catch (err: any) {
      try {
        await (prisma as any).transaction.update({ where: { id }, data: { status: statusIn } })
      } catch (err2: any) {
        const code = (err2 && typeof err2 === 'object' ? (err2 as any).code : undefined)
        const msg = String((err2 && (err2 as any).message) || '')
        if (code === 'P2025' || /Record to update not found|Expected 1 records to be found, found 0/i.test(msg)) {
          return new Response('Not found', { status: 404 })
        }
        throw err2
      }
    }

    return new Response(JSON.stringify({ id, status: statusIn }), { status: 200 })
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}
