import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { isKycApproved } from '@/lib/kyc'

export const revalidate = 30 // Revalidate every 30 seconds
export const dynamic = 'force-dynamic'

function formatTimestamp(date: Date) {
  const pad = (n: number) => n.toString().padStart(2, '0')
  const d = new Date(date)
  const day = pad(d.getDate())
  const month = pad(d.getMonth() + 1)
  const year = d.getFullYear()
  let hours = d.getHours()
  const ampm = hours >= 12 ? 'PM' : 'AM'
  hours = hours % 12
  if (hours === 0) hours = 12
  const minutes = pad(d.getMinutes())
  const seconds = pad(d.getSeconds())
  return `${day}-${month}-${year} ${pad(hours)}:${minutes}:${seconds} ${ampm}`
}

export async function GET() {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })

  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })

  const now = new Date()
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate())
 
  const prismaAny = prisma as any
  const excludeSubscription = { AND: [
    { NOT: { purpose: { startsWith: 'subscription ', mode: 'insensitive' } } },
    { OR: [{ mode: null }, { mode: { not: 'SUBSCRIPTION' } }] }
  ] }
  const [todayAgg, pendingAgg, successAgg, failedAgg, txs, kycApproved] = await Promise.all([
    prismaAny.transaction.aggregate({
      where: { userId: user.id, createdAt: { gte: startOfToday }, ...excludeSubscription },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Pending', ...excludeSubscription },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Success', ...excludeSubscription },
      _sum: { amount: true },
    }),
    prismaAny.transaction.aggregate({
      where: { userId: user.id, status: 'Failed', ...excludeSubscription },
      _sum: { amount: true },
    }),
    prismaAny.transaction.findMany({
      where: { userId: user.id, ...excludeSubscription },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
    isKycApproved(user.id),
  ])

  const recent = (txs as any[]).map((t: any) => {
    const m = String(t.purpose || '').match(/PID:([^|]+)/i)
    const paymentId = m && m[1] ? m[1].trim() : ''
    const fallback = (() => {
      const base = Math.floor(new Date(t.createdAt).getTime() / 1000).toString(36).toUpperCase()
      const suf = String(t.id || '').slice(-2).toUpperCase().replace(/[^A-Z0-9]/g, 'X')
      const mix = (base + suf).slice(0, 10)
      return mix.padEnd(10, '0')
    })()
    const displayId = paymentId || fallback
    return {
      id: t.id,
      displayId,
      timestamp: formatTimestamp(t.createdAt),
      purpose: t.purpose,
      amount: t.amount,
      utr: t.utr ?? null,
      screenshot: t.screenshotUrl ?? null,
      status: (t.status as 'Pending' | 'Success' | 'Failed'),
      statusSource: t.statusSource ?? null,
      name: t.buyerName ?? null,
      phone: t.buyerPhone ?? null,
      email: t.buyerEmail ?? null,
      payMode: t.mode ? (['UPI', 'BANK'].includes(t.mode.toUpperCase()) ? (t.mode.toUpperCase() as 'UPI' | 'BANK') : 'NA') : 'NA',
      payUpiId: t.upiId ?? null,
      payAccountNumber: t.accountNumber ?? null,
      payIfsc: t.ifsc ?? null,
    }
  })

  const json = {
    todayTotal: todayAgg._sum.amount ?? 0,
    pendingTotal: pendingAgg._sum.amount ?? 0,
    successTotal: successAgg._sum.amount ?? 0,
    failedTotal: failedAgg._sum.amount ?? 0,
    recent,
    kyc: {
      approved: kycApproved,
      notification: !kycApproved ? {
        type: 'info',
        title: 'KYC Verification Pending',
        message: 'Your KYC verification is not approved yet. You can use all services with your current package, but please complete KYC verification to unlock additional benefits.',
        action: 'Complete KYC'
      } : null
    }
  }

  return new Response(JSON.stringify(json), { status: 200 })
}
