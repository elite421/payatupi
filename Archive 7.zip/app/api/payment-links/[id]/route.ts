import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(_: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const { id } = await context.params
  const link = await prisma.paymentLink.findUnique({ where: { id } })
  if (!link || link.userId !== user.id) return new Response('Not found', { status: 404 })
  return new Response(JSON.stringify(link), { status: 200 })
}

export async function PUT(req: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const body = await req.json().catch(() => ({}))
  const { title, description, amount, active, redirectUrl } = body || {}
  const { id } = await context.params
  const link = await prisma.paymentLink.findUnique({ where: { id } })
  if (!link || link.userId !== user.id) return new Response('Not found', { status: 404 })
  const updated = await prisma.paymentLink.update({ where: { id: link.id }, data: {
    title: title ?? link.title,
    description: description !== undefined ? description : link.description,
    amount: amount !== undefined ? (amount != null ? +amount : null) : link.amount,
    active: active !== undefined ? !!active : link.active,
    redirectUrl: redirectUrl !== undefined ? (redirectUrl || null) : link.redirectUrl,
  }})
  return new Response(JSON.stringify(updated), { status: 200 })
}

export async function DELETE(_: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth()
  if (!session?.user?.email) return new Response('Unauthorized', { status: 401 })
  const user = await prisma.user.findUnique({ where: { email: session.user.email } })
  if (!user) return new Response('Unauthorized', { status: 401 })
  const { id } = await context.params
  const link = await prisma.paymentLink.findUnique({ where: { id } })
  if (!link || link.userId !== user.id) return new Response('Not found', { status: 404 })
  await prisma.paymentLink.delete({ where: { id: link.id } })
  return new Response(null, { status: 204 })
}
