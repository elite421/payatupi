import { prisma } from '@/lib/prisma'
import { createHmac } from 'crypto'
import { logApiRequest } from '@/lib/api-logging'
import { createActivity } from '@/lib/activity'
import { isValidPublicId, findUserByPublicId } from '@/lib/user-id'
import { normalizeUtr } from '@/lib/normalize'
import { getClientIp } from '@/lib/ip'
import { matchCallbackLogToTransaction } from '@/lib/sms-callback-matcher'

const ALLOWED: Array<'Pending' | 'Success' | 'Failed'> = ['Pending', 'Success', 'Failed']

function isTooLarge(req: Request, limit = 131072) {
  const cl = req.headers.get('content-length')
  if (!cl) return false
  const n = Number(cl)
  if (!Number.isFinite(n)) return false
  return n > limit
}

async function parseBody(req: Request): Promise<any> {
  try {
    const ct = (req.headers.get('content-type') || '').toLowerCase()
    if (ct.includes('application/json')) {
      try { return await req.json() } catch {}
    }
    if (ct.includes('application/x-www-form-urlencoded') || ct.includes('multipart/form-data')) {
      try {
        const fd = await req.formData()
        const obj: any = {}
        fd.forEach((v, k) => { obj[k] = typeof v === 'string' ? v : ((v as File)?.name || 'file') })
        return obj
      } catch {}
    }
    try { return await req.json() } catch {}
    try {
      const text = await req.text()
      if (text) {
        if (/^[^=]+=[\s\S]+/.test(text)) {
          const sp = new URLSearchParams(text)
          const obj: any = {}
          for (const [k, v] of sp.entries()) obj[k] = v
          return obj
        }
        // Treat raw text/plain as the message itself
        return { message: text }
      }
    } catch {}

  } catch {}
  return {}
}

function getAny(o: any, keys: string[]): any {
  if (!o || typeof o !== 'object') return undefined
  const map = new Map<string, any>()
  for (const k of Object.keys(o)) map.set(k.toLowerCase(), (o as any)[k])
  for (const key of keys) {
    const v = map.get(key.toLowerCase())
    if (v !== undefined) return v
  }
  return undefined
}

function safePayload(input: any): any {
  try {
    if (!input || typeof input !== 'object') return undefined
    const allow = new Set([
      'account_id','userid','id','utr','status','amount','upi_id','vpa','payer_vpa','from_vpa','bank','message','pid','payment_id','paymentid'
    ])
    const out: any = {}
    for (const k of Object.keys(input)) {
      const kl = k.toLowerCase()
      if (!allow.has(kl)) continue
      const v = (input as any)[k]
      if (typeof v === 'string') out[k] = v.length > 500 ? v.slice(0, 500) : v
      else if (typeof v === 'number' || typeof v === 'boolean') out[k] = v
    }
    return out
  } catch {
    return undefined
  }
}

function normalizeStatus(input: string | undefined | null): 'Pending' | 'Success' | 'Failed' | null {
  const s = String(input || '').trim()
  if (!s) return null
  const l = s.toLowerCase()
  if (l === 'success' || l === 'successful' || l === 'ok' || l === 'done' || l === 'paid' || l === 'credit' || l === 'credited' || l === 'receive' || l === 'received' || l === 'approved' || l === '1' || l === 'true' || l === 'y' || l === 'yes') return 'Success'
  if (l === 'failed' || l === 'failure' || l === 'declined' || l === 'rejected' || l === 'error' || l === '0' || l === 'false' || l === 'n' || l === 'no' || l === 'timeout') return 'Failed'
  if (l === 'pending' || l === 'processing' || l === 'initiated' || l === 'created' || l === 'init' || l === 'wait' || l === 'waiting' || l === 'hold') return 'Pending'
  if (ALLOWED.includes(s as any)) return s as any
  return null
}

function extractUtrFromText(txt: string): string | null {
  const t = String(txt || '').toUpperCase()
  const m1 = t.match(/\b(\d{12,18})\b/)
  if (m1) return normalizeUtr(m1[1])
  const m2 = t.match(/\b([A-Z0-9]{10,20})\b/)
  if (m2 && /[A-Z]/.test(m2[1]) && /\d/.test(m2[1])) return normalizeUtr(m2[1])
  return null
}

function extractAmountFromText(txt: string): number | undefined {
  const t = String(txt || '')
  const m = t.match(/(?:rs|inr|amount|amt)[^\d]{0,5}(\d+(?:\.\d{1,2})?)/i) || t.match(/\b(\d+(?:\.\d{1,2})?)\b\s*(?:rs|inr)\b/i)
  if (m) {
    const n = Number(String(m[1]).replace(/[\,\s]/g, ''))
    if (!Number.isNaN(n)) return Math.round(n)
  }
  return undefined
}

function extractStatusFromText(txt: string): 'Pending' | 'Success' | 'Failed' | null {
  const t = String(txt || '').toLowerCase()
  if (!t) return null
  const hasSuccess = /(success|successful|paid|credit(?:ed)?|receive(?:d)?|approved|completed|done|ok)\b/.test(t)
  const hasFailed = /(failed|failure|declined|rejected|reversal|reversed|chargeback|cancelled|canceled|error|timeout)\b/.test(t)
  const hasPending = /(pending|processing|initiated|created|waiting|wait|on\s+hold|hold|in\s+progress)\b/.test(t)
  if (hasSuccess) return 'Success'
  if (hasFailed) return 'Failed'
  if (hasPending) return 'Pending'
  return null
}

export async function POST(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const endpoint = (()=>{ try { return new URL(req.url).pathname } catch { return '/api/sms/callback/[userId]' } })()
  try {
    if (isTooLarge(req)) {
      await logApiRequest({ endpoint, method: 'POST', code: 413, status: 'ERROR', reason: 'payload_too_large', req })
      return new Response(JSON.stringify({ error: 'payload_too_large' }), { status: 413 })
    }
    const { userId } = await params
    const url = new URL(req.url)
    const bodyParsed: any = await parseBody(req)
    const payload = (bodyParsed?.sms_callback || bodyParsed || {}) as any

    const accountIdRaw = String(userId || '').trim()
    const utrRawOriginal = String(
      getAny(payload, ['utr','rrn','ref','ref_id','reference','txn','txn_id','transaction_id','utrn'])
      || url.searchParams.get('utr')
      || url.searchParams.get('rrn')
      || url.searchParams.get('ref')
      || url.searchParams.get('reference')
      || url.searchParams.get('txn')
      || url.searchParams.get('txn_id')
      || url.searchParams.get('transaction_id')
      || ''
    ).trim()
    let utrIn = utrRawOriginal ? normalizeUtr(utrRawOriginal) : ''
    const statusRaw = (getAny(payload, ['status','state','result']) ?? url.searchParams.get('status')) as any
    let statusIn = normalizeStatus(statusRaw)
    const amountRaw = (getAny(payload, ['amount','amt','value','total']) ?? url.searchParams.get('amount') ?? url.searchParams.get('amt')) as any
    let amountIn = amountRaw != null && amountRaw !== '' ? Number(String(amountRaw).replace(/[\,\s]/g, '')) : undefined
    const payerUpiIdIn = String((getAny(payload, ['upi_id','vpa','payer_vpa','from_vpa']) ?? url.searchParams.get('upi_id') ?? url.searchParams.get('vpa') ?? '') || '').trim() || undefined
    const bankIn = String((getAny(payload, ['bank']) ?? url.searchParams.get('bank') ?? '') || '').trim() || undefined
    const messageIn = String((getAny(payload, ['message','body','content','text','msg']) ?? url.searchParams.get('message') ?? '') || '').trim()
    const pidIn = String((getAny(payload, ['pid','payment_id','paymentId']) ?? url.searchParams.get('pid') ?? url.searchParams.get('payment_id') ?? '') || '').trim() || undefined

    if (!utrIn && messageIn) {
      const u = extractUtrFromText(messageIn)
      if (u) utrIn = u
    }
    if ((amountIn == null || Number.isNaN(amountIn)) && messageIn) {
      const a = extractAmountFromText(messageIn)
      if (a != null) amountIn = a
    } else if (messageIn) {
      const a = extractAmountFromText(messageIn)
      if (a != null && (amountIn == null || a > amountIn)) amountIn = a
    }
    if (!statusIn && messageIn) {
      const s = extractStatusFromText(messageIn)
      if (s) statusIn = s
    }

    if (!accountIdRaw || !utrIn) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_request', req, metadata: { accountId: accountIdRaw, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'invalid_request' }), { status: 400 })
    }

    let user = null as any
    if (isValidPublicId(accountIdRaw)) {
      user = await findUserByPublicId(accountIdRaw)
    }
    if (!user) {
      user = await prisma.user.findUnique({ where: { id: accountIdRaw } })
    }
    if (!user) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_account', req, metadata: { accountId: accountIdRaw, utr: utrIn, status: statusIn, amount: amountIn } })
      return new Response(JSON.stringify({ error: 'invalid_account' }), { status: 400 })
    }

    // Check if data already exists in smscalllog - if so, automatically process it
    try {
      const existingLog = await prisma.smsCallbackLog.findFirst({
        where: { userId: user.id, utr: utrIn },
        orderBy: { createdAt: 'desc' },
      }).catch(() => null)

      if (existingLog) {
        // Use existing log data for missing fields
        if (!statusIn && existingLog.status) statusIn = existingLog.status as any
        if ((amountIn == null || Number.isNaN(amountIn)) && typeof existingLog.amount === 'number') {
          amountIn = existingLog.amount
        }

        // If existing log has Success status, try to match and update transaction immediately
        if (existingLog.status === 'Success' && existingLog.amount != null) {
          const matchResult = await matchCallbackLogToTransaction(existingLog)
          if (matchResult.matched && matchResult.txId) {
            const matchedTx = await prisma.transaction.findUnique({ where: { id: matchResult.txId } })
            if (matchedTx) {
              await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: matchedTx.id, utr: utrIn, status: 'Success', fromExistingLog: true } })
              return new Response(JSON.stringify({ ok: true, id: matchedTx.id, status: matchedTx.status }), { status: 200 })
            }
          }
        }
      }
    } catch {}

    // Persist a log entry for incoming callback with simple dedupe (avoid floods)
    let callbackLog: any = null
    try {
      const since = new Date(Date.now() - 10 * 60 * 1000)
      const existing = await prisma.smsCallbackLog.findFirst({
        where: {
          userId: user.id,
          utr: utrIn,
          ...(statusIn ? { status: statusIn } : {} as any),
          ...(typeof amountIn === 'number' && Number.isFinite(amountIn) ? { amount: Math.round(amountIn) } : {} as any),
          createdAt: { gte: since },
        },
      }).catch(() => null)
      if (!existing) {
        callbackLog = await prisma.smsCallbackLog.create({
          data: {
            userId: user.id,
            utr: utrIn,
            status: (statusIn || undefined) as any,
            amount: (typeof amountIn === 'number' && Number.isFinite(amountIn)) ? Math.round(amountIn) : undefined,
            payerUpiId: payerUpiIdIn,
            bank: bankIn,
            ip: getClientIp(req) || undefined,
            method: 'POST',
            raw: safePayload(payload) || undefined,
          }
        })
      } else {
        callbackLog = existing
      }
    } catch {}

    const cs = await prisma.checkoutSettings.findUnique({ where: { userId: user.id } }).catch(() => null) as any
    if (!(cs && cs.smsAutomation)) {
      await logApiRequest({ endpoint, method: 'POST', code: 403, status: 'ERROR', reason: 'automation_disabled', req, userId: user.id, metadata: { accountId: accountIdRaw, utr: utrIn, status: statusIn, amount: amountIn } })
      return new Response(JSON.stringify({ error: 'automation_disabled' }), { status: 403 })
    }

    let tx = await prisma.transaction.findFirst({
      where: { userId: user.id, utr: utrIn },
      orderBy: { createdAt: 'desc' },
    })
    if (!tx && utrRawOriginal && utrRawOriginal !== utrIn) {
      tx = await prisma.transaction.findFirst({ where: { userId: user.id, utr: utrRawOriginal }, orderBy: { createdAt: 'desc' } })
    }
    // Fallback: match by PID when provided
    if (!tx && pidIn) {
      tx = await prisma.transaction.findFirst({
        where: { userId: user.id, purpose: { startsWith: `PID:${pidIn}` } as any },
        orderBy: { createdAt: 'desc' },
      })
    }
    // Fallback: match by amount within a recent window when amount is provided and exactly one candidate exists
    if (!tx && typeof amountIn === 'number' && Number.isFinite(amountIn)) {
      const since = new Date(Date.now() - 48 * 60 * 60 * 1000) // last 48h
      const candidates = await prisma.transaction.findMany({
        where: {
          userId: user.id,
          status: 'Pending',
          amount: Math.round(amountIn),
          OR: [{ utr: null }, { utr: '' }],
          createdAt: { gte: since },
        },
        orderBy: { createdAt: 'desc' },
        select: { id: true, createdAt: true },
        take: 2,
      })
      if (candidates.length === 1) {
        tx = await prisma.transaction.findUnique({ where: { id: candidates[0].id } })
        if (tx && (!tx.utr || tx.utr === '')) {
          // attach UTR for future idempotency
          await prisma.transaction.update({ where: { id: tx.id }, data: { utr: utrIn } })
        }
      }
    }

    // If transaction not found immediately, try using the matcher with the callback log
    if (!tx && callbackLog) {
      const matchResult = await matchCallbackLogToTransaction(callbackLog)
      if (matchResult.matched && matchResult.txId) {
        tx = await prisma.transaction.findUnique({ where: { id: matchResult.txId } })
        if (tx) {
          await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn, status: statusIn, matched: true } })
          return new Response(JSON.stringify({ ok: true, id: tx.id, status: tx.status }), { status: 200 })
        }
      }
    }

    if (!tx) {
      // Log is already stored, return success so callback doesn't retry
      await logApiRequest({ endpoint, method: 'POST', code: 202, status: 'OK', reason: 'pending_match', req, userId: user.id, metadata: { utr: utrIn } })
      return new Response(JSON.stringify({ ok: true, message: 'Callback received, will be processed' }), { status: 202 })
    }

    // Finalize missing fields from the matched transaction where possible
    if (!statusIn) statusIn = tx.status as any
    if ((amountIn == null || Number.isNaN(amountIn)) && typeof (tx as any).amount === 'number') amountIn = (tx as any).amount
    const matchedByUtr = !!(tx.utr && (normalizeUtr(tx.utr) === utrIn || (utrRawOriginal && normalizeUtr(tx.utr) === normalizeUtr(utrRawOriginal))))
    if (matchedByUtr && typeof (tx as any).amount === 'number') {
      amountIn = (tx as any).amount
    }

    // Validate after fallbacks
    if (!statusIn || !ALLOWED.includes(statusIn as any)) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'invalid_status', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'invalid_status' }), { status: 400 })
    }
    if (!(typeof amountIn === 'number' && Number.isFinite(amountIn) && amountIn > 0)) {
      await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'amount_required', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'amount_required' }), { status: 400 })
    }

    if (!matchedByUtr && typeof amountIn === 'number' && Number.isFinite(amountIn) && amountIn > 0) {
      const a = Math.round(amountIn)
      if (Math.abs((tx.amount || 0) - a) > 0) {
        await logApiRequest({ endpoint, method: 'POST', code: 400, status: 'ERROR', reason: 'amount_mismatch', req, userId: user.id, metadata: { txId: tx.id, amountIn } })
        return new Response(JSON.stringify({ error: 'amount_mismatch' }), { status: 400 })
      }
    }

    if (tx.status === statusIn) {
      if (tx.statusSource !== 'SMS') {
        await prisma.transaction.update({ where: { id: tx.id }, data: { statusSource: 'SMS' } })
      }
      await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn, status: statusIn, noop: true } })
      return new Response(JSON.stringify({ ok: true, id: tx.id, status: tx.status }), { status: 200 })
    }

    // Charge automation fee (Rs.1) once per transaction when automation updates the status
    let updated: any = null
    try {
      updated = await prisma.$transaction(async (db) => {
        // Get or create wallet
        let wallet = await (db as any).wallet.findUnique({ where: { userId: user.id } })
        if (!wallet) {
          wallet = await (db as any).wallet.create({ data: { userId: user.id, balance: 0 } })
        }

        // Charge automation fee (1 rupee) if not already charged
        if (!(tx as any).automationFeeCharged) {
          // Check if wallet has sufficient balance (for non-topup transactions)
          const isWalletTopup = String(tx.mode || '').toUpperCase() === 'WALLET_TOPUP'
          if (!isWalletTopup && wallet.balance < 1) {
            throw new Error('INSUFFICIENT_WALLET')
          }
          
          // Deduct automation fee
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { decrement: 1 } } })
          await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'DEBIT', amount: 1, reason: `Automation fee for ${tx.id}`, txId: tx.id } })
        }

        // Update transaction status
        const u = await (db as any).transaction.update({ where: { id: tx.id }, data: { status: statusIn, statusSource: 'SMS', automationFeeCharged: true } })

        // Handle wallet top-up auto-credit (after fee deduction)
        if (statusIn === 'Success' && String(u.mode || '').toUpperCase() === 'WALLET_TOPUP' && !(u as any).walletCredited) {
          // Credit the full transaction amount to wallet
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: u.amount } } })
          await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: u.amount, reason: `Wallet top-up via ${u.id}`, txId: u.id } })
          await (db as any).transaction.update({ where: { id: u.id }, data: { walletCredited: true } })
        }

        return u
      })
    } catch (e: any) {
      if (e && typeof e.message === 'string' && e.message === 'INSUFFICIENT_WALLET') {
        await logApiRequest({ endpoint, method: 'POST', code: 402, status: 'ERROR', reason: 'insufficient_wallet', req, userId: user.id, metadata: { txId: tx.id } })
        return new Response(JSON.stringify({ error: 'insufficient_wallet' }), { status: 402 })
      }
      throw e
    }

    // Subscription activation (mirror admin route behavior)
    try {
      if (statusIn === 'Success' && String(updated.mode).toUpperCase() === 'SUBSCRIPTION') {
        const allowed = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS'] as const
        const m = String(updated.purpose || '').match(/Subscription\s+([A-Z_]+)/i)
        const planIn = (m?.[1] || '').toUpperCase()
        if ((allowed as readonly string[]).includes(planIn)) {
          const now = new Date()
          let periodEnd: Date | null = null
          if (planIn === 'INDIVIDUAL' || planIn === 'ENTERPRISE') {
            periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
          } else if (planIn === 'INDIVIDUAL_PLUS' || planIn === 'ENTERPRISE_PLUS') {
            periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
          }
          await prisma.subscription.upsert({
            where: { userId: updated.userId },
            update: { plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
            create: { userId: updated.userId, plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
          })
          await createActivity(updated.userId, 'SUBSCRIPTION_CHANGED', 'Subscription activated from SMS callback', { plan: planIn, periodEnd })
        }
      }
    } catch {}

    // Webhooks (fire-and-forget with short timeout)
    try {
      Promise.resolve().then(async () => {
        try {
          const hooks = await prisma.webhook.findMany({ where: { userId: updated.userId } })
          if (hooks.length > 0) {
            const payload = {
              event: 'transaction.updated',
              data: {
                id: updated.id,
                status: statusIn,
                purpose: updated.purpose,
                amount: updated.amount,
                mode: updated.mode,
                utr: updated.utr,
                createdAt: updated.createdAt,
              },
              userId: updated.userId,
            }
            const body = JSON.stringify(payload)
            await Promise.all(hooks.map(async (h: any) => {
              try {
                const headers: Record<string,string> = { 'Content-Type': 'application/json', 'X-Payatupi-Event': 'transaction.updated' }
                if (h.secret) {
                  const sig = createHmac('sha256', h.secret).update(body).digest('hex')
                  headers['X-Payatupi-Signature'] = sig
                }
                const ac = new AbortController()
                const to = setTimeout(() => ac.abort(), 3000)
                try {
                  await fetch(h.url, { method: 'POST', headers, body, redirect: 'manual' as any, signal: ac.signal })
                } finally {
                  clearTimeout(to)
                }
              } catch {}
            }))
          }
        } catch {}
      }).catch(() => {})
    } catch {}

    await createActivity(updated.userId, 'PAYMENT_CONFIRMED', 'Payment marked via SMS callback', { txId: updated.id, utr: utrIn, status: statusIn })
    await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: updated.id, utr: utrIn, status: statusIn } })

    return new Response(JSON.stringify({ ok: true, id: updated.id, status: updated.status }), { status: 200 })
  } catch (err) {
    await logApiRequest({ endpoint, method: 'POST', code: 500, status: 'ERROR', reason: 'server_error', req })
    return new Response(JSON.stringify({ error: 'server_error' }), { status: 500 })
  }
}

export async function GET(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const endpoint = (()=>{ try { return new URL(req.url).pathname } catch { return '/api/sms/callback/[userId]' } })()
  try {
    const { userId } = await params
    const url = new URL(req.url)
    const accountIdRaw = String(userId || '').trim()
    const utrRawOriginal = String(
      url.searchParams.get('utr')
      || url.searchParams.get('rrn')
      || url.searchParams.get('ref')
      || url.searchParams.get('reference')
      || url.searchParams.get('txn')
      || url.searchParams.get('txn_id')
      || url.searchParams.get('transaction_id')
      || ''
    ).trim()
    let utrIn = normalizeUtr(utrRawOriginal)
    let statusIn = normalizeStatus(url.searchParams.get('status'))
    const amountRaw = url.searchParams.get('amount') ?? url.searchParams.get('amt')
    let amountIn = amountRaw != null && amountRaw !== '' ? Number(amountRaw) : undefined
    const payerUpiIdIn = String(url.searchParams.get('upi_id') || '').trim() || undefined
    const bankIn = String(url.searchParams.get('bank') || '').trim() || undefined
    const messageIn = String(url.searchParams.get('message') || '').trim()
    const pidIn = String((url.searchParams.get('pid') ?? url.searchParams.get('payment_id') ?? '') || '').trim() || undefined

    // Try extracting from raw message when missing
    if (!utrIn && messageIn) {
      const u = extractUtrFromText(messageIn)
      if (u) utrIn = u
    }
    if ((amountIn == null || Number.isNaN(amountIn)) && messageIn) {
      const a = extractAmountFromText(messageIn)
      if (a != null) amountIn = a
    }
    if (!statusIn && messageIn) {
      const s = extractStatusFromText(messageIn)
      if (s) statusIn = s
    }

    if (!accountIdRaw || !utrIn) {
      await logApiRequest({ endpoint, method: 'GET', code: 400, status: 'ERROR', reason: 'invalid_request', req, metadata: { accountId: accountIdRaw, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'invalid_request' }), { status: 400 })
    }

    let user = null as any
    if (isValidPublicId(accountIdRaw)) {
      user = await findUserByPublicId(accountIdRaw)
    }
    if (!user) {
      user = await prisma.user.findUnique({ where: { id: accountIdRaw } })
    }
    if (!user) {
      await logApiRequest({ endpoint, method: 'GET', code: 400, status: 'ERROR', reason: 'invalid_account', req, metadata: { accountId: accountIdRaw, utr: utrIn, status: statusIn, amount: amountIn } })
      return new Response(JSON.stringify({ error: 'invalid_account' }), { status: 400 })
    }

    // Check if data already exists in smscalllog - if so, automatically process it
    try {
      const existingLog = await prisma.smsCallbackLog.findFirst({
        where: { userId: user.id, utr: utrIn },
        orderBy: { createdAt: 'desc' },
      }).catch(() => null)

      if (existingLog) {
        // Use existing log data for missing fields
        if (!statusIn && existingLog.status) statusIn = existingLog.status as any
        if ((amountIn == null || Number.isNaN(amountIn)) && typeof existingLog.amount === 'number') {
          amountIn = existingLog.amount
        }

        // If existing log has Success status, try to match and update transaction immediately
        if (existingLog.status === 'Success' && existingLog.amount != null) {
          const matchResult = await matchCallbackLogToTransaction(existingLog)
          if (matchResult.matched && matchResult.txId) {
            const matchedTx = await prisma.transaction.findUnique({ where: { id: matchResult.txId } })
            if (matchedTx) {
              await logApiRequest({ endpoint, method: 'POST', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: matchedTx.id, utr: utrIn, status: 'Success', fromExistingLog: true } })
              return new Response(JSON.stringify({ ok: true, id: matchedTx.id, status: matchedTx.status }), { status: 200 })
            }
          }
        }
      }
    } catch {}

    // Persist a log entry for incoming callback with simple dedupe (avoid floods)
    let callbackLog: any = null
    try {
      const since = new Date(Date.now() - 10 * 60 * 1000)
      const existing = await prisma.smsCallbackLog.findFirst({
        where: {
          userId: user.id,
          utr: utrIn,
          ...(statusIn ? { status: statusIn } : {} as any),
          ...(typeof amountIn === 'number' && Number.isFinite(amountIn) ? { amount: Math.round(amountIn) } : {} as any),
          createdAt: { gte: since },
        },
      }).catch(() => null)
      if (!existing) {
        callbackLog = await prisma.smsCallbackLog.create({
          data: {
            userId: user.id,
            utr: utrIn,
            status: (statusIn || undefined) as any,
            amount: (typeof amountIn === 'number' && Number.isFinite(amountIn)) ? Math.round(amountIn) : undefined,
            payerUpiId: payerUpiIdIn,
            bank: bankIn,
            ip: getClientIp(req) || undefined,
            method: 'GET',
            raw: Object.fromEntries(url.searchParams.entries()) as any,
          }
        })
      } else {
        callbackLog = existing
      }
    } catch {}

    const cs = await prisma.checkoutSettings.findUnique({ where: { userId: user.id } }).catch(() => null) as any
    if (!(cs && cs.smsAutomation)) {
      await logApiRequest({ endpoint, method: 'GET', code: 403, status: 'ERROR', reason: 'automation_disabled', req, userId: user.id, metadata: { accountId: accountIdRaw, utr: utrIn, status: statusIn, amount: amountIn } })
      return new Response(JSON.stringify({ error: 'automation_disabled' }), { status: 403 })
    }

    let tx = await prisma.transaction.findFirst({ where: { userId: user.id, utr: utrIn }, orderBy: { createdAt: 'desc' } })
    if (!tx && utrRawOriginal && utrRawOriginal !== utrIn) {
      tx = await prisma.transaction.findFirst({ where: { userId: user.id, utr: utrRawOriginal }, orderBy: { createdAt: 'desc' } })
    }
    if (!tx && pidIn) {
      tx = await prisma.transaction.findFirst({ where: { userId: user.id, purpose: { startsWith: `PID:${pidIn}` } as any }, orderBy: { createdAt: 'desc' } })
    }
    if (!tx && typeof amountIn === 'number' && Number.isFinite(amountIn)) {
      const since = new Date(Date.now() - 48 * 60 * 60 * 1000)
      const candidates = await prisma.transaction.findMany({
        where: { userId: user.id, status: 'Pending', amount: Math.round(amountIn), OR: [{ utr: null }, { utr: '' }], createdAt: { gte: since } },
        orderBy: { createdAt: 'desc' },
        select: { id: true, createdAt: true },
        take: 2,
      })
      if (candidates.length === 1) {
        tx = await prisma.transaction.findUnique({ where: { id: candidates[0].id } })
        if (tx && (!tx.utr || tx.utr === '')) {
          await prisma.transaction.update({ where: { id: tx.id }, data: { utr: utrIn } })
        }
      }
    }
    // If transaction not found immediately, try using the matcher with the callback log
    if (!tx && callbackLog) {
      const matchResult = await matchCallbackLogToTransaction(callbackLog)
      if (matchResult.matched && matchResult.txId) {
        tx = await prisma.transaction.findUnique({ where: { id: matchResult.txId } })
        if (tx) {
          await logApiRequest({ endpoint, method: 'GET', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn, status: statusIn, matched: true } })
          return new Response(JSON.stringify({ ok: true, id: tx.id, status: tx.status }), { status: 200 })
        }
      }
    }

    if (!tx) {
      // Log is already stored, return success so callback doesn't retry
      await logApiRequest({ endpoint, method: 'GET', code: 202, status: 'OK', reason: 'pending_match', req, userId: user.id, metadata: { utr: utrIn } })
      return new Response(JSON.stringify({ ok: true, message: 'Callback received, will be processed' }), { status: 202 })
    }

    // Finalize missing fields from the matched transaction where possible
    if (!statusIn) statusIn = tx.status as any
    if ((amountIn == null || Number.isNaN(amountIn)) && typeof (tx as any).amount === 'number') amountIn = (tx as any).amount
    const matchedByUtr = !!(tx.utr && (normalizeUtr(tx.utr) === utrIn || (utrRawOriginal && normalizeUtr(tx.utr) === normalizeUtr(utrRawOriginal))))
    if (matchedByUtr && typeof (tx as any).amount === 'number') {
      amountIn = (tx as any).amount
    }

    // Validate after fallbacks
    if (!statusIn || !ALLOWED.includes(statusIn as any)) {
      await logApiRequest({ endpoint, method: 'GET', code: 400, status: 'ERROR', reason: 'invalid_status', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'invalid_status' }), { status: 400 })
    }
    if (!(typeof amountIn === 'number' && Number.isFinite(amountIn) && amountIn > 0)) {
      await logApiRequest({ endpoint, method: 'GET', code: 400, status: 'ERROR', reason: 'amount_required', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn } })
      return new Response(JSON.stringify({ error: 'amount_required' }), { status: 400 })
    }

    if (!matchedByUtr && typeof amountIn === 'number' && Number.isFinite(amountIn) && amountIn > 0) {
      const a = Math.round(amountIn)
      if (Math.abs((tx.amount || 0) - a) > 0) {
        await logApiRequest({ endpoint, method: 'GET', code: 400, status: 'ERROR', reason: 'amount_mismatch', req, userId: user.id, metadata: { txId: tx.id, amountIn } })
        return new Response(JSON.stringify({ error: 'amount_mismatch' }), { status: 400 })
      }
    }

    if (tx.status === statusIn) {
      if (tx.statusSource !== 'SMS') {
        await prisma.transaction.update({ where: { id: tx.id }, data: { statusSource: 'SMS' } })
      }
      await logApiRequest({ endpoint, method: 'GET', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: tx.id, utr: utrIn, status: statusIn, noop: true } })
      return new Response(JSON.stringify({ ok: true, id: tx.id, status: tx.status }), { status: 200 })
    }

    // Charge automation fee (Rs.1) once per transaction when automation updates the status
    let updated: any = null
    try {
      updated = await prisma.$transaction(async (db) => {
        // Get or create wallet
        let wallet = await (db as any).wallet.findUnique({ where: { userId: user.id } })
        if (!wallet) {
          wallet = await (db as any).wallet.create({ data: { userId: user.id, balance: 0 } })
        }

        // Charge automation fee (1 rupee) if not already charged
        if (!(tx as any).automationFeeCharged) {
          // Check if wallet has sufficient balance (for non-topup transactions)
          const isWalletTopup = String(tx.mode || '').toUpperCase() === 'WALLET_TOPUP'
          if (!isWalletTopup && wallet.balance < 1) {
            throw new Error('INSUFFICIENT_WALLET')
          }
          
          // Deduct automation fee
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { decrement: 1 } } })
          await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'DEBIT', amount: 1, reason: `Automation fee for ${tx.id}`, txId: tx.id } })
        }

        // Update transaction status
        const u = await (db as any).transaction.update({ where: { id: tx.id }, data: { status: statusIn, statusSource: 'SMS', automationFeeCharged: true } })

        // Handle wallet top-up auto-credit (after fee deduction)
        if (statusIn === 'Success' && String(u.mode || '').toUpperCase() === 'WALLET_TOPUP' && !(u as any).walletCredited) {
          // Credit the full transaction amount to wallet
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: u.amount } } })
          await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount: u.amount, reason: `Wallet top-up via ${u.id}`, txId: u.id } })
          await (db as any).transaction.update({ where: { id: u.id }, data: { walletCredited: true } })
        }

        return u
      })
    } catch (e: any) {
      if (e && typeof e.message === 'string' && e.message === 'INSUFFICIENT_WALLET') {
        await logApiRequest({ endpoint, method: 'GET', code: 402, status: 'ERROR', reason: 'insufficient_wallet', req, userId: user.id, metadata: { txId: tx.id } })
        return new Response(JSON.stringify({ error: 'insufficient_wallet' }), { status: 402 })
      }
      throw e
    }

    try {
      if (statusIn === 'Success' && String(updated.mode).toUpperCase() === 'SUBSCRIPTION') {
        const allowed = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS'] as const
        const m = String(updated.purpose || '').match(/Subscription\s+([A-Z_]+)/i)
        const planIn = (m?.[1] || '').toUpperCase()
        if ((allowed as readonly string[]).includes(planIn)) {
          const now = new Date()
          let periodEnd: Date | null = null
          if (planIn === 'INDIVIDUAL' || planIn === 'ENTERPRISE') {
            periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
          } else if (planIn === 'INDIVIDUAL_PLUS' || planIn === 'ENTERPRISE_PLUS') {
            periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
          }
          await prisma.subscription.upsert({ where: { userId: updated.userId }, update: { plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd }, create: { userId: updated.userId, plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd } })
          await createActivity(updated.userId, 'SUBSCRIPTION_CHANGED', 'Subscription activated from SMS callback', { plan: planIn, periodEnd })
        }
      }
    } catch {}

    try {
      Promise.resolve().then(async () => {
        try {
          const hooks = await prisma.webhook.findMany({ where: { userId: updated.userId } })
          if (hooks.length > 0) {
            const payload = { event: 'transaction.updated', data: { id: updated.id, status: statusIn, purpose: updated.purpose, amount: updated.amount, mode: updated.mode, utr: updated.utr, createdAt: updated.createdAt }, userId: updated.userId }
            const body = JSON.stringify(payload)
            await Promise.all(hooks.map(async (h: any) => {
              try {
                const headers: Record<string,string> = { 'Content-Type': 'application/json', 'X-Payatupi-Event': 'transaction.updated' }
                if (h.secret) {
                  const sig = createHmac('sha256', h.secret).update(body).digest('hex')
                  headers['X-Payatupi-Signature'] = sig
                }
                const ac = new AbortController()
                const to = setTimeout(() => ac.abort(), 3000)
                try {
                  await fetch(h.url, { method: 'POST', headers, body, redirect: 'manual' as any, signal: ac.signal })
                } finally {
                  clearTimeout(to)
                }
              } catch {}
            }))
          }
        } catch {}
      }).catch(() => {})
    } catch {}

    await createActivity(updated.userId, 'PAYMENT_CONFIRMED', 'Payment marked via SMS callback', { txId: updated.id, utr: utrIn, status: statusIn })
    await logApiRequest({ endpoint, method: 'GET', code: 200, status: 'OK', req, userId: user.id, metadata: { txId: updated.id, utr: utrIn, status: statusIn } })
    return new Response(JSON.stringify({ ok: true, id: updated.id, status: updated.status }), { status: 200 })
  } catch (err) {
    await logApiRequest({ endpoint, method: 'GET', code: 500, status: 'ERROR', reason: 'server_error', req })
    return new Response(JSON.stringify({ error: 'server_error' }), { status: 500 })
  }
}
