import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const url = new URL(req.url)
  const status = url.searchParams.get('status') || undefined
  const userId = url.searchParams.get('userId') || undefined
  const takeRaw = url.searchParams.get('take')
  const take = Math.min(Math.max(parseInt(takeRaw || '50') || 50, 1), 200)

  const where: any = {}
  if (status) where.status = status
  if (userId) where.userId = userId

  const txs = await prisma.transaction.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take,
    select: {
      id: true,
      userId: true,
      purpose: true,
      amount: true,
      status: true,
      mode: true,
      utr: true,
      screenshotUrl: true,
      createdAt: true,
      user: { select: { id: true, name: true, email: true } },
    },
  })

  return new Response(JSON.stringify(txs), { status: 200 })
}
