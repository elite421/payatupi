import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { matchCallbackLogToTransaction } from '@/lib/sms-callback-matcher'
import { normalizeUtr } from '@/lib/normalize'

/**
 * Process unmatched callback logs and attempt to match them with transactions.
 * This endpoint should be called periodically (e.g., via cron job).
 */
export async function POST(req: Request) {
  try {
    const session = await auth()
    const role = (session?.user as any)?.role
    if (!session?.user?.email || role !== 'ADMIN') {
      return new Response('Unauthorized', { status: 401 })
    }

    const body = await req.json().catch(() => ({})) as { limit?: number; userId?: string }
    const limit = Math.min(body.limit || 100, 500) // Process up to 500 at a time
    const userId = body.userId || undefined

    function normalizeStatus(input: string | undefined | null): 'Pending' | 'Success' | 'Failed' | null {
      const s = String(input || '').trim()
      if (!s) return null
      const l = s.toLowerCase()
      if (l === 'success' || l === 'successful' || l === 'ok' || l === 'done' || l === 'paid' || l === 'credit' || l === 'credited' || l === 'receive' || l === 'received' || l === 'approved' || l === '1' || l === 'true' || l === 'y' || l === 'yes') return 'Success'
      if (l === 'failed' || l === 'failure' || l === 'declined' || l === 'rejected' || l === 'error' || l === '0' || l === 'false' || l === 'n' || l === 'no' || l === 'timeout') return 'Failed'
      if (l === 'pending' || l === 'processing' || l === 'initiated' || l === 'created' || l === 'init' || l === 'wait' || l === 'waiting' || l === 'hold') return 'Pending'
      return null
    }

    // Find recent callback logs (including those with non-standard status strings)
    const unmatchedLogs = await prisma.smsCallbackLog.findMany({
      where: {
        userId: userId || { not: null },
        createdAt: {
          gte: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // Last 10 days
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    let processed = 0
    let matched = 0
    let errors = 0

    for (const log of unmatchedLogs) {
      if (!log.userId) {
        continue
      }

      try {
        // Normalize status for matching and idempotency check
        const statusNorm = normalizeStatus(log.status)
        if (!statusNorm) {
          continue
        }

        // Check if already matched by looking for a transaction with this UTR and normalized status
        const utrIn = normalizeUtr(log.utr)
        const existingTx = await prisma.transaction.findFirst({
          where: {
            userId: log.userId,
            utr: utrIn,
            status: statusNorm,
          },
        })

        if (existingTx) {
          // Already matched, skip
          continue
        }

        // Attempt to match
        const result = await matchCallbackLogToTransaction({
          id: log.id,
          userId: log.userId,
          utr: log.utr,
          status: statusNorm,
          amount: log.amount as any,
          createdAt: log.createdAt,
        })
        processed++

        if (result.matched) {
          matched++
        }
      } catch (error) {
        console.error(`Error processing callback log ${log.id}:`, error)
        errors++
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        processed,
        matched,
        errors,
        total: unmatchedLogs.length,
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error processing callback logs:', error)
    return new Response(JSON.stringify({ error: 'Internal server error' }), { status: 500 })
  }
}

