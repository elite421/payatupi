import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { isValidPublicId, findUserByPublicId } from '@/lib/user-id'

export async function POST(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const body = await req.json().catch(()=>null) as { accountId?: string; amount?: number; reason?: string }
  if (!body || !body.accountId || typeof body.amount !== 'number' || !Number.isFinite(body.amount)) {
    return new Response(JSON.stringify({ error: 'invalid_request' }), { status: 400 })
  }
  const amount = Math.round(body.amount)
  if (amount === 0) return new Response(JSON.stringify({ error: 'amount_required' }), { status: 400 })

  let user: any = null
  const id = String(body.accountId).trim()
  if (isValidPublicId(id)) user = await findUserByPublicId(id)
  if (!user) user = await prisma.user.findUnique({ where: { id } })
  if (!user) return new Response(JSON.stringify({ error: 'user_not_found' }), { status: 404 })

  const reason = String(body.reason || (amount > 0 ? 'Admin credit' : 'Admin debit'))

  await prisma.$transaction(async (db) => {
    const w0 = await (db as any).wallet.findUnique({ where: { userId: user.id } })
    const wallet = w0 || await (db as any).wallet.create({ data: { userId: user.id, balance: 0 } })
    if (amount > 0) {
      await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: amount } } })
      await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'CREDIT', amount, reason } })
    } else {
      const debit = Math.abs(amount)
      await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { decrement: debit } } })
      await (db as any).walletEntry.create({ data: { walletId: wallet.id, type: 'DEBIT', amount: debit, reason } })
    }
  })

  return new Response(JSON.stringify({ ok: true }), { status: 200 })
}
