import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createActivity } from '@/lib/activity'

export async function PATCH(req: Request, { params }: { params: Promise<{ userId: string }> }) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const { userId } = await params
  const body = await req.json().catch(() => ({})) as { status?: string; adminNote?: string }
  const allowed = ['NOT_SUBMITTED','PENDING','APPROVED','REJECTED']
  const data: any = {}
  if (body.status && allowed.includes(body.status)) data.status = body.status
  if (body.adminNote !== undefined) data.adminNote = String(body.adminNote || '')
  const sub = await (prisma as any).kycSubmission.upsert({
    where: { userId },
    update: data,
    create: { userId, status: data.status || 'PENDING', adminNote: data.adminNote },
  })
  await createActivity(userId, 'KYC_STATUS_CHANGED', 'KYC status updated by admin', { status: sub.status })
  return new Response(JSON.stringify(sub), { status: 200 })
}
