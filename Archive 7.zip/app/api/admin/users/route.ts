import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })
  const url = new URL(req.url)
  const q = (url.searchParams.get('q') || '').trim()
  const where: any = {}
  if (q) {
    where.OR = [
      { name: { contains: q, mode: 'insensitive' } },
      { email: { contains: q, mode: 'insensitive' } },
      { phone: { contains: q } },
    ]
  }
  const users = await (prisma as any).user.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 200,
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      role: true,
      createdAt: true,
      subscription: {
        select: { plan: true, status: true, currentPeriodEnd: true }
      },
      kyc: { select: { status: true } },
    }
  })
  return new Response(JSON.stringify(users), { status: 200 })
}
