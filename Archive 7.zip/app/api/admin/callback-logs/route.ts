import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: Request) {
  const session = await auth()
  const role = (session?.user as any)?.role
  if (!session?.user?.email || role !== 'ADMIN') return new Response('Unauthorized', { status: 401 })

  const url = new URL(req.url)
  const q = String(url.searchParams.get('q') || '').trim()
  const status = String(url.searchParams.get('status') || '').toUpperCase()
  const codeStr = String(url.searchParams.get('code') || '').trim()
  const take = Math.max(1, Math.min(500, parseInt(String(url.searchParams.get('take') || '100')) || 100))

  const where: any = {
    endpoint: { startsWith: '/api/sms/callback' },
  }
  if (q) {
    where.OR = [
      { endpoint: { contains: q } },
      { reason: { contains: q } },
    ]
  }
  if (status === 'OK' || status === 'ERROR') where.status = status
  const code = parseInt(codeStr)
  if (!Number.isNaN(code)) where.code = code

  const rows = await (prisma as any).apiRequestLog.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take,
    select: {
      id: true,
      endpoint: true,
      method: true,
      status: true,
      code: true,
      reason: true,
      metadata: true,
      createdAt: true,
      user: { select: { id: true, name: true, email: true } },
    },
  })

  return new Response(JSON.stringify(rows), { status: 200 })
}
