'use client'

import { useState, useEffect } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'

export default function ResetPassword() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [token, setToken] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const [tokenValid, setTokenValid] = useState(true)

  useEffect(() => {
    const t = searchParams.get('token')
    if (!t) {
      setError('Invalid reset link')
      setTokenValid(false)
      return
    }
    setToken(t)
  }, [searchParams])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setMessage('')

    if (password !== confirmPassword) {
      setError('Passwords do not match')
      return
    }

    if (password.length < 8) {
      setError('Password must be at least 8 characters')
      return
    }

    setLoading(true)

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, password })
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Failed to reset password')
        return
      }

      setMessage(data.message)
      setTimeout(() => router.push('/login'), 2000)
    } catch (err) {
      setError('Network error. Please try again.')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (!tokenValid) {
    return (
      <div className="flex items-center justify-center min-h-screen px-4">
        <div className="max-w-md w-full bg-white/70 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/40">
          <h2 className="text-2xl font-bold mb-4 text-gray-900 text-center">Invalid Reset Link</h2>
          <p className="text-gray-600 text-center mb-6">This password reset link is invalid or has expired.</p>
          <Link href="/forget" className="block w-full bg-[#366870] text-white p-3 rounded-lg hover:bg-[#2f5b62] transition font-medium shadow-md text-center">
            Request New Reset Link
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center min-h-screen px-4">
      <div className="max-w-md w-full bg-white/70 backdrop-blur-xl p-8 rounded-2xl shadow-xl border border-white/40">
        <h2 className="text-3xl font-bold mb-2 text-gray-900 text-center">Reset Password</h2>
        <p className="text-gray-600 text-center mb-6 text-sm">Enter your new password below</p>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}

        {message && (
          <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded-lg text-sm">
            {message}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <label className="block mb-2 font-medium text-gray-700" htmlFor="password">
            New Password
          </label>
          <input
            className="w-full p-3 border border-gray-300 rounded-lg mb-4 focus:outline-none focus:ring-2 focus:ring-[#366870] transition"
            type="password"
            id="password"
            placeholder="At least 8 characters"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            disabled={loading}
          />

          <label className="block mb-2 font-medium text-gray-700" htmlFor="confirmPassword">
            Confirm Password
          </label>
          <input
            className="w-full p-3 border border-gray-300 rounded-lg mb-6 focus:outline-none focus:ring-2 focus:ring-[#366870] transition"
            type="password"
            id="confirmPassword"
            placeholder="Confirm your password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
            disabled={loading}
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#366870] text-white p-3 rounded-lg hover:bg-[#2f5b62] transition font-medium shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Resetting...' : 'Reset Password'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <Link href="/login" className="text-[#366870] hover:underline text-sm font-medium">
            Back to Login
          </Link>
        </div>
      </div>
    </div>
  )
}
