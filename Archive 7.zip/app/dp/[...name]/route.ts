import { promises as fs } from 'fs'
import path from 'path'

function getContentType(ext: string) {
  switch (ext) {
    case 'png': return 'image/png'
    case 'jpg':
    case 'jpeg': return 'image/jpeg'
    case 'webp': return 'image/webp'
    case 'gif': return 'image/gif'
    case 'bmp': return 'image/bmp'
    case 'svg': return 'image/svg+xml'
    case 'pdf': return 'application/pdf'
    case 'heic': return 'image/heic'
    case 'heif': return 'image/heif'
    default: return 'application/octet-stream'
  }
}

export async function GET(_req: Request, ctx: { params: { name: string[] } } | { params: Promise<{ name: string[] }> }) {
  const params = 'then' in (ctx as any).params ? await (ctx as any).params : (ctx as any).params
  const parts: string[] = Array.isArray(params?.name) ? params.name : []
  if (parts.length === 0) return new Response('Not found', { status: 404 })
  if (parts.some(p => p.includes('..') || p.includes('\\'))) return new Response('Bad path', { status: 400 })
  const filePath = path.join(process.cwd(), 'public', 'dp', ...parts)
  try {
    const buf = await fs.readFile(filePath)
    const ext = path.extname(filePath).replace('.', '').toLowerCase()
    const ct = getContentType(ext)
    return new Response(buf, { headers: { 'Content-Type': ct } })
  } catch {
    return new Response('Not found', { status: 404 })
  }
}
