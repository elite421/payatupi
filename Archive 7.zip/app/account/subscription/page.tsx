"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from 'next/navigation'
import { useToast } from '@/components/Toast'

type PlanCode = 'FREE'|'PRO'|'BUSINESS'|'INDIVIDUAL'|'ENTERPRISE'|'INDIVIDUAL_PLUS'|'ENTERPRISE_PLUS'|'TRIAL'
type Sub = { plan: PlanCode; status: 'ACTIVE'|'CANCELED'|'PAST_DUE'; currentPeriodEnd?: string | null }

export default function SubscriptionPage(){
  const [sub, setSub] = useState<Sub | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [kyc, setKyc] = useState<any | null>(null)
  const [kycLoaded, setKycLoaded] = useState(false)
  const router = useRouter()
  const { show } = useToast()
  const notifiedRef = useRef({ expire: false, kyc: false, sub: false })

  useEffect(() => {
    let active = true
    
    const fetchSubscription = async () => {
      try {
        setLoading(true)
        const r = await fetch('/api/subscription', { 
          cache: 'default',
          next: { revalidate: 300 } // Revalidate every 5 minutes
        })
        if (r.ok) {
          const data = await r.json()
          if (active) setSub(data)
        } else if (active) {
          setMsg('Failed to load subscription data')
        }
      } catch (error) {
        if (active) {
          console.error('Error fetching subscription:', error)
          setMsg('Network error occurred')
        }
      } finally {
        if (active) setLoading(false)
      }
    }

    const fetchKyc = async () => {
      try {
        const r = await fetch('/api/kyc', { 
          cache: 'default',
          next: { revalidate: 300 } // Revalidate every 5 minutes
        })
        if (r.ok) {
          const data = await r.json()
          if (active) setKyc(data)
        }
      } catch {} finally {
        if (active) setKycLoaded(true)
      }
    }

    fetchSubscription()
    fetchKyc()
    
    return () => { active = false }
  }, [])

  // Direct matching only; no aliases
  const planHierarchy: Record<string, PlanCode[]> = {}

  const kycEligible = !!kyc && (String(kyc.status) === 'PENDING' || String(kyc.status) === 'APPROVED')

  const subActive = (() => {
    try {
      if (!sub) return false
      if (String(sub.plan) === 'FREE') return false
      if (String(sub.status) !== 'ACTIVE') return false
      if (sub.currentPeriodEnd) {
        const end = new Date(sub.currentPeriodEnd).getTime()
        if (Number.isFinite(end) && end <= Date.now()) return false
      }
      return true
    } catch {
      return false
    }
  })()

  const cards = [
    {
      key: 'individual',
      title: 'Individual',
      price: 300,
      oldPrice: 999,
      duration: '30 Days',
      plan: 'INDIVIDUAL' as PlanCode,
      features: [
        { label: '70% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: false },
        { label: 'WooCommerce Plugin', ok: false },
        { label: 'API access', ok: false },
      ],
    },
    {
      key: 'enterprise',
      title: 'Enterprise',
      price: 375,
      oldPrice: 1499,
      duration: '30 Days',
      plan: 'ENTERPRISE' as PlanCode,
      features: [
        { label: '75% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: true },
        { label: 'WooCommerce Plugin', ok: true },
        { label: 'API access', ok: true },
      ],
    },
    {
      key: 'individual_plus',
      title: 'Individual Plus',
      price: 2000,
      oldPrice: 9999,
      duration: '365 Days',
      plan: 'INDIVIDUAL_PLUS' as PlanCode,
      features: [
        { label: '80% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: false },
        { label: 'WooCommerce Plugin', ok: false },
        { label: 'API access', ok: false },
      ],
    },
    {
      key: 'enterprise_plus',
      title: 'Enterprise Plus',
      price: 2250,
      oldPrice: 14999,
      duration: '365 Days',
      plan: 'ENTERPRISE_PLUS' as PlanCode,
      features: [
        { label: '85% Discount', ok: true },
        { label: '0% Transaction Fee', ok: true },
        { label: 'Instant Settlement', ok: true },
        { label: 'UPI Intent Support', ok: true },
        { label: 'Unlimited UPI Payments', ok: true },
        { label: 'Unlimited NEFT / IMPS', ok: true },
        { label: 'Checkout ads', ok: true },
        { label: 'WooCommerce Plugin', ok: true },
        { label: 'API access', ok: true },
      ],
    },
  ]

  function isPlanActive(cardPlan: PlanCode, currentSub: Sub | null): boolean {
    if (!currentSub) return false
    return currentSub.plan === cardPlan
  }

  useEffect(() => {
    try {
      const daysRemaining = sub?.currentPeriodEnd
        ? Math.ceil((new Date(sub.currentPeriodEnd).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
        : null

      if (!notifiedRef.current.expire && daysRemaining != null && daysRemaining <= 7 && daysRemaining >= 0) {
        notifiedRef.current.expire = true
        show({
          title: 'Plan expiring soon',
          description: `Your plan expires in ${daysRemaining} day${daysRemaining === 1 ? '' : 's'}. Renew to avoid interruption.`,
          variant: 'warning',
          actionText: 'Renew now',
          onAction: () => router.push('/account/subscription'),
        })
      }

      if (!notifiedRef.current.sub && sub && String(sub.status) !== 'ACTIVE') {
        notifiedRef.current.sub = true
        show({
          title: 'Subscription inactive',
          description: 'Your subscription is not active. Choose a plan to activate your account.',
          variant: 'warning',
          actionText: 'Choose plan',
          onAction: () => router.push('/account/subscription'),
        })
      }

      const kycStatus = String(kyc?.status || 'NOT_SUBMITTED')
      if (!notifiedRef.current.kyc && kycLoaded) {
        if (kycStatus === 'NOT_SUBMITTED' || kycStatus === 'REJECTED') {
          notifiedRef.current.kyc = true
          show({
            title: 'KYC required',
            description: kycStatus === 'REJECTED' ? 'Your KYC was rejected. Please re-submit to continue.' : 'Please complete your KYC to unlock features.',
            variant: 'warning',
            actionText: 'Go to KYC',
            onAction: () => router.push('/account/kyc'),
          })
        } else if (kycStatus === 'PENDING') {
          notifiedRef.current.kyc = true
          show({
            title: 'KYC pending',
            description: 'Your KYC is under review. We will notify you once approved.',
            variant: 'info',
          })
        }
      }
    } catch {}
  }, [sub, kyc, kycLoaded, router, show])

  async function selectPlan(plan: PlanCode, amount: number) {
    if (plan === 'FREE') return
    
    setSaving(true)
    setMsg(null)
    
    try {
      if (!kycEligible) { setMsg('Please complete KYC before purchasing a package.'); router.push('/account/kyc'); return }
      const q = new URLSearchParams({ 
        plan: String(plan), 
        amt: String(amount) 
      })
      router.push(`/account/subscription/pay?${q.toString()}`)
    } catch (error) {
      console.error('Error selecting plan:', error)
      setMsg('Failed to proceed with plan selection')
    } finally {
      setSaving(false)
    }
  }

  async function startTrial() {
    setSaving(true)
    setMsg(null)
    try {
      const r = await fetch('/api/subscription', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ plan: 'TRIAL' })
      })
      if (r.ok) {
        const data = await r.json().catch(()=>null)
        setSub(data)
        show({ title: 'Trial activated', description: 'You have 7 days of access.', variant: 'success' })
        router.push('/account')
      } else {
        const d = await r.json().catch(()=>({ error: 'Failed to start trial' }))
        setMsg(d.error || 'Failed to start trial')
      }
    } catch (e) {
      setMsg('Network error occurred')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading subscription information...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {!subActive && (
        <button
          onClick={() => { if (!kycEligible) { router.push('/account/kyc'); return } startTrial() }}
          className="absolute right-2 top-2 rounded-full bg-gray-100 px-3 py-1 text-sm text-gray-800 hover:bg-gray-200 border border-gray-300 shadow-sm disabled:opacity-50"
          disabled={saving}
          >
          Skip (7-day trial)
        </button>
      )}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Choose Your Plan</h1>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          Select the perfect plan to unlock powerful features and enjoy better transaction rates.
        </p>
      </div>

      {/* Promotional Banner */}
      <div className="mb-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-6 text-center text-white shadow-lg">
        <div className="flex items-center justify-center space-x-2">
          <span className="text-2xl">🎁</span>
          <p className="text-lg font-semibold">
            Get an Amazon voucher worth ₹225 when you subscribe to Enterprise Plus!
          </p>
        </div>
      </div>

      {/* Subscription Cards Grid */}
      {kycLoaded && !kycEligible && (
        <div className="mb-6 rounded-xl border border-yellow-200 bg-yellow-50 p-4 text-sm text-yellow-800">
          KYC is required before purchasing a package. Please complete your KYC to continue. <button onClick={()=>router.push('/account/kyc')} className="ml-2 underline font-medium">Go to KYC</button>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {cards.map(card => {
          const active = isPlanActive(card.plan, sub)
          const discount = Math.round(((card.oldPrice - card.price) / card.oldPrice) * 100)
          
          return (
            <div 
              key={card.key}
              className={`relative rounded-2xl border-2 p-6 shadow-lg transition-all duration-300 hover:shadow-xl ${
                active 
                  ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' 
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              {/* Discount Badge */}
              <div className="absolute -top-3 -right-3 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg">
                Save {discount}%
              </div>

              {/* Plan Header */}
              <div className="text-center mb-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{card.title}</h3>
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <span className="text-3xl font-bold text-gray-900">₹{card.price}</span>
                  <span className="text-lg text-gray-500 line-through">₹{card.oldPrice}</span>
                </div>
                <div className="text-sm text-gray-600 bg-gray-100 rounded-full px-3 py-1 inline-block">
                  {card.duration}
                </div>
              </div>

              {/* Features List */}
              <div className="space-y-3 mb-6">
                {card.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      feature.ok 
                        ? 'bg-green-100 text-green-600' 
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      {feature.ok ? '✓' : '✕'}
                    </div>
                    <span className={`text-sm ${
                      feature.ok ? 'text-gray-700' : 'text-gray-400'
                    }`}>
                      {feature.label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Action Button */}
              <button
                disabled={saving || active}
                onClick={() => selectPlan(card.plan, card.price)}
                className={`w-full py-3 px-4 rounded-xl font-semibold transition-all duration-200 ${
                  active
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700 transform hover:scale-105'
                } disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none`}
              >
                {saving ? (
                  <div className="flex items-center justify-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Processing...</span>
                  </div>
                ) : active ? (
                  <div className="flex items-center justify-center space-x-2">
                    <span>✓</span>
                    <span>Current Plan</span>
                  </div>
                ) : !kycEligible ? (
                  'Complete KYC to purchase'
                ) : (
                  'Select Plan'
                )}
              </button>
            </div>
          )
        })}
      </div>

      {/* Current Subscription Status */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Current Subscription</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-600">Plan:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.plan ? sub.plan.replace('_', ' ') : 'FREE'}
            </span>
          </div>
          <div>
            <span className="text-gray-600">Status:</span>
            <span className={`ml-2 font-medium ${
              sub?.status === 'ACTIVE' ? 'text-green-600' :
              sub?.status === 'CANCELED' ? 'text-red-600' :
              'text-yellow-600'
            }`}>
              {sub?.status || 'INACTIVE'}
            </span>
          </div>
          <div>
            <span className="text-gray-600">Renewal Date:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.currentPeriodEnd 
                ? new Date(sub.currentPeriodEnd).toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })
                : '—'
              }
            </span>
          </div>
          <div>
            <span className="text-gray-600">Billing Cycle:</span>
            <span className="ml-2 font-medium text-gray-900">
              {sub?.plan?.includes('PLUS') ? 'Annual' : 'Monthly'}
            </span>
          </div>
        </div>
      </div>

      {/* Messages */}
      {msg && (
        <div className={`mt-4 p-4 rounded-lg ${
          msg.includes('error') || msg.includes('Failed') 
            ? 'bg-red-50 text-red-700 border border-red-200'
            : 'bg-blue-50 text-blue-700 border border-blue-200'
        }`}>
          {msg}
        </div>
      )}

      {/* Additional Info */}
      <div className="mt-8 text-center text-sm text-gray-500">
        <p>All plans include 24/7 customer support and secure payment processing.</p>
        <p className="mt-1">Need help choosing? <a href="/account/contact" className="text-blue-600 hover:text-blue-700 underline">Contact our sales team</a></p>
      </div>
    </div>
  )
}