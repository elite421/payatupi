"use client"

import { useState, ChangeEvent } from 'react'
import { useRouter } from 'next/navigation'

export default function ContactSalesPage() {
  const router = useRouter()
  const [subject, setSubject] = useState('Sales Inquiry')
  const [message, setMessage] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [status, setStatus] = useState<string | null>(null)

  function onFileChange(e: ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] || null
    setFile(f)
  }

  async function submit() {
    setStatus(null)
    if (!message.trim()) { setStatus('Please describe your requirement.'); return }
    setSubmitting(true)
    try {
      const fd = new FormData()
      fd.append('subject', subject)
      fd.append('message', message.trim())
      if (file) fd.append('attachment', file)
      const r = await fetch('/api/support/tickets', { method: 'POST', body: fd })
      if (r.ok) {
        setStatus('Thanks! Our sales team will reach out shortly.')
        setMessage('')
        setFile(null)
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setStatus(d.error || 'Failed to submit request')
      }
    } catch (e) {
      setStatus('Network error. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto py-8">
      <h1 className="text-2xl font-semibold">Contact Sales</h1>
      <p className="mt-2 text-sm text-slate-600">Tell us about your business and needs. We will get back within 1 business day.</p>

      <div className="mt-6 rounded-xl border bg-white p-6 shadow-sm space-y-4">
        <div>
          <label className="mb-1 block text-sm text-slate-700">Subject</label>
          <input value={subject} onChange={e=>setSubject(e.target.value)} className="w-full rounded-md border px-3 py-2" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-slate-700">Message</label>
          <textarea value={message} onChange={e=>setMessage(e.target.value)} rows={6} className="w-full rounded-md border px-3 py-2" placeholder="Describe your use-case, expected volume, timelines, and contact details." />
        </div>
        <div>
          <label className="mb-1 block text-sm text-slate-700">Attachment (optional)</label>
          <input type="file" onChange={onFileChange} className="block w-full text-sm" />
        </div>

        <div className="flex items-center gap-2">
          <button onClick={()=>router.back()} className="rounded-md bg-slate-100 px-4 py-2">Back</button>
          <button disabled={submitting} onClick={submit} className="rounded-md bg-slate-900 text-white px-4 py-2 disabled:opacity-50">{submitting ? 'Submitting...' : 'Submit'}</button>
          {status && <span className="text-sm text-slate-600 ml-2">{status}</span>}
        </div>
      </div>
    </div>
  )
}
