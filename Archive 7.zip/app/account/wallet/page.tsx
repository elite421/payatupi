"use client"

import { useEffect, useState } from 'react'
import Link from 'next/link'

type Wallet = { id: string; balance: number }
type Entry = { id: string; type: 'CREDIT'|'DEBIT'|'ADJUST'; amount: number; reason?: string | null; txId?: string | null; createdAt: string }

export default function WalletPage(){
  const [wallet, setWallet] = useState<Wallet | null>(null)
  const [entries, setEntries] = useState<Entry[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const r = await fetch('/api/wallet', { 
          cache: 'default',
          next: { revalidate: 30 } // Revalidate every 30 seconds
        })
        if (!r.ok) throw new Error('Failed to load wallet')
        const d = await r.json()
        if (active) {
          setWallet(d.wallet)
          setEntries(d.entries || [])
        }
      } catch (e: any) {
        if (active) setError(e?.message || 'Failed to load wallet')
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [])

  return (
    <div className="max-w-3xl">
      <h1 className="text-2xl font-semibold">Wallet</h1>
      {loading ? (
        <div className="mt-4 text-slate-600">Loading…</div>
      ) : error ? (
        <div className="mt-4 rounded-md bg-red-50 text-red-700 border p-3 text-sm">{error}</div>
      ) : (
        <>
          <div className="mt-4 glass rounded-xl p-6 flex items-center justify-between">
            <div>
              <div className="text-sm text-slate-600">Current Balance</div>
              <div className="text-2xl font-semibold">₹ {wallet?.balance ? wallet.balance.toFixed(2) : '0.00'}</div>
            </div>
            <div>
              <Link href="/account/wallet/add" className="rounded-lg px-4 py-2 text-white" style={{ backgroundColor: '#366870' }}>Add Money</Link>
            </div>
          </div>

          <div className="mt-6 glass rounded-xl p-6">
            <div className="font-semibold mb-3">Recent Activity</div>
            {entries.length === 0 ? (
              <div className="text-sm text-slate-600">No activity yet.</div>
            ) : (
              <ul className="space-y-3">
                {entries.map(e => (
                  <li key={e.id} className="flex items-center justify-between rounded-lg border p-3 bg-white">
                    <div>
                      <div className="text-sm font-medium">{e.type} • ₹ {e.amount.toFixed(2)}</div>
                      {e.reason && <div className="text-xs text-slate-600 mt-0.5">{e.reason}</div>}
                      {e.txId && <div className="text-xs text-slate-500 mt-0.5">Tx: {e.txId}</div>}
                    </div>
                    <div className="text-xs text-slate-500">{new Date(e.createdAt).toLocaleString()}</div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </>
      )}
    </div>
  )
}
