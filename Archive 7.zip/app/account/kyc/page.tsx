"use client"

import { useEffect, useState, ChangeEvent } from 'react'
import { useRouter } from 'next/navigation'

type Kyc = { status?: 'NOT_SUBMITTED'|'PENDING'|'APPROVED'|'REJECTED'; documentUrl?: string | null; selfieUrl?: string | null }

export default function KycPage(){
  const router = useRouter()
  const [kyc, setKyc] = useState<Kyc | null>(null)
  const [loading, setLoading] = useState(true)
  const [docId, setDocId] = useState<File | null>(null)
  const [docAddr, setDocAddr] = useState<File | null>(null)
  const [msg, setMsg] = useState<string | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const r = await fetch('/api/kyc', { cache: 'no-store' })
        if (active) setKyc(r.ok ? await r.json() : null)
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [])

  function statusLabel(s?: string){
    if (s === 'APPROVED') return 'Verified'
    if (s === 'PENDING') return 'Pending'
    if (s === 'REJECTED') return 'Rejected'
    return 'Not Submitted'
  }

  async function onUpload(){
    setMsg(null)
    const fd = new FormData()
    if (docId) fd.append('document', docId)
    if (docAddr) fd.append('selfie', docAddr)
    try {
      const r = await fetch('/api/kyc', { method: 'POST', body: fd })
      if (r.ok) {
        const d = await r.json()
        setKyc(d)
        setMsg('KYC uploaded')
        setDocId(null)
        setDocAddr(null)
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setMsg(d.error || 'Failed')
      }
    } catch {
      setMsg('Failed')
    }
  }

  return (
    <>
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold">KYC Verification</h1>
        <p className="mt-2 text-slate-600">Upload your ID and address proof to get verified.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl border p-4">
          <div className="text-sm text-slate-600">Status</div>
          <div className="mt-1 font-medium">{loading ? 'Loading…' : statusLabel(kyc?.status)}</div>
          <div className="mt-4 text-sm text-slate-600">Documents</div>
          <div className="mt-2 grid grid-cols-2 gap-3">
            <div className="rounded-md border p-2">
              <div className="text-xs text-slate-500 mb-1">ID proof</div>
              {kyc?.documentUrl ? (
                /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(kyc.documentUrl) ? (
                  <img onClick={()=>setPreviewUrl(kyc.documentUrl!)} src={kyc.documentUrl} alt="Document" className="max-h-48 w-full object-contain cursor-zoom-in" />
                ) : (
                  <a href={kyc.documentUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 underline">Open document</a>
                )
              ) : (
                <div className="text-xs text-slate-500">Not uploaded</div>
              )}
            </div>
            <div className="rounded-md border p-2">
              <div className="text-xs text-slate-500 mb-1">Address/Selfie</div>
              {kyc?.selfieUrl ? (
                /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(kyc.selfieUrl) ? (
                  <img onClick={()=>setPreviewUrl(kyc.selfieUrl!)} src={kyc.selfieUrl} alt="Selfie" className="max-h-48 w-full object-contain cursor-zoom-in" />
                ) : (
                  <a href={kyc.selfieUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 underline">Open document</a>
                )
              ) : (
                <div className="text-xs text-slate-500">Not uploaded</div>
              )}
            </div>
          </div>
        </div>

        <div className="rounded-xl border p-4">
          <div className="text-sm font-medium">Upload / Update Documents</div>
          <div className="mt-3 space-y-3">
            <div>
              <label className="mb-1 block text-sm text-slate-700">ID proof</label>
              <input type="file" accept="image/*,application/pdf" onChange={(e: ChangeEvent<HTMLInputElement>)=>setDocId(e.target.files?.[0] || null)} className="block w-full text-sm" />
            </div>
            <div>
              <label className="mb-1 block text-sm text-slate-700">Address proof / Selfie</label>
              <input type="file" accept="image/*" onChange={(e: ChangeEvent<HTMLInputElement>)=>setDocAddr(e.target.files?.[0] || null)} className="block w-full text-sm" />
            </div>
            <div className="flex items-center gap-3">
              <button onClick={onUpload} className="rounded-md bg-slate-900 px-4 py-2 text-white">Upload</button>
              {msg && <span className="text-sm text-slate-600">{msg}</span>}
            </div>
          </div>
        </div>
      </div>
    </div>
    {previewUrl && (
      <div onClick={()=>setPreviewUrl(null)} className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
        <img src={previewUrl || ''} alt="" className="max-h-[90vh] max-w-[90vw] rounded shadow-lg" />
      </div>
    )}
    </>
  )
}
