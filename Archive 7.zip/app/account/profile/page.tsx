"use client"

import { useEffect, useRef, useState, FormEvent, ChangeEvent } from "react"
import { signOut } from 'next-auth/react'
import { useToast } from '@/components/Toast'

export default function ProfilePage(){
  const [data, setData] = useState<any>(null)
  const [settings, setSettings] = useState<any>(null)
  const [kyc, setKyc] = useState<any>(null)
  const [kycLoaded, setKycLoaded] = useState(false)
  const [sub, setSub] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [pmsg, setPmsg] = useState<string | null>(null)
  const [logoOpen, setLogoOpen] = useState(false)
  const [docsOpen, setDocsOpen] = useState(false)
  const [uploadOpen, setUploadOpen] = useState(false)
  const [logoFile, setLogoFile] = useState<File | null>(null)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const [docId, setDocId] = useState<File | null>(null)
  const [docAddr, setDocAddr] = useState<File | null>(null)
  const [secMsg, setSecMsg] = useState<string | null>(null)
  const { show } = useToast()
  const notifiedRef = useRef({ expire: false, kyc: false, sub: false })
  const prevKycRef = useRef<string | null>(null)

  useEffect(() => {
    ;(async () => {
      try {
        const [pr, st, ky, su] = await Promise.all([
          fetch('/api/profile'),
          fetch('/api/checkout-settings'),
          fetch('/api/kyc'),
          fetch('/api/subscription'),
        ])
        if (pr.ok) setData(await pr.json())
        if (st.ok) setSettings(await st.json())
        if (ky.ok) setKyc(await ky.json())
        if (su.ok) setSub(await su.json())
      } catch {}
      finally { setKycLoaded(true) }
    })()
  }, [])

  // Toast notifications: plan expiry and KYC/eligibility
  useEffect(() => {
    try {
      const days = daysRemaining(sub?.currentPeriodEnd)
      if (!notifiedRef.current.expire && days != null && days <= 7 && days >= 0) {
        notifiedRef.current.expire = true
        show({
          title: 'Plan expiring soon',
          description: `Your plan expires in ${days} day${days === 1 ? '' : 's'}.`,
          variant: 'warning',
          actionText: 'Manage plan',
          onAction: () => { window.location.href = '/account/subscription' },
        })
      }

      if (!notifiedRef.current.sub && sub && String(sub.status) !== 'ACTIVE') {
        notifiedRef.current.sub = true
        show({
          title: 'Subscription inactive',
          description: 'Choose a plan to activate your account.',
          variant: 'warning',
          actionText: 'Choose plan',
          onAction: () => { window.location.href = '/account/subscription' },
        })
      }

      const s = String(kyc?.status || 'NOT_SUBMITTED')
      if (kycLoaded && prevKycRef.current !== s) {
        if (s === 'NOT_SUBMITTED' || s === 'REJECTED') {
          show({
            title: 'KYC required',
            description: s === 'REJECTED' ? 'Your KYC was rejected. Please re-submit.' : 'Complete your KYC to unlock features.',
            variant: 'warning',
            actionText: 'Go to KYC',
            onAction: () => { window.location.href = '/account/kyc' },
          })
        } else if (s === 'PENDING') {
          show({
            title: 'KYC pending',
            description: 'Your KYC is under review. We will notify you once approved.',
            variant: 'info',
          })
        } else if (s === 'APPROVED') {
          show({
            title: 'KYC approved',
            description: 'Your KYC is approved. You can now accept payments.',
            variant: 'success',
            actionText: 'Go to Dashboard',
            onAction: () => { window.location.href = '/account' },
          })
        }
        prevKycRef.current = s
      }
    } catch {}
  }, [sub, kyc, kycLoaded, show])

  async function onSaveProfile(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    setMsg(null)
    const fd = new FormData(e.currentTarget)
    const payload = { name: String(fd.get('name') || ''), phone: String(fd.get('phone') || '') }
    const r = await fetch('/api/profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (r.ok) { setData(await r.json()); setMsg('Saved') } else { setMsg('Failed to save') }
  }

  async function onChangePassword(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setPmsg(null)
    const fd = new FormData(e.currentTarget)
    const payload = { currentPassword: String(fd.get('currentPassword') || ''), newPassword: String(fd.get('newPassword') || '') }
    const r = await fetch('/api/profile/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    if (r.ok) { setPmsg('Password changed') ; (e.target as HTMLFormElement).reset() } else { const d = await r.json().catch(()=>({error:'Failed'})); setPmsg(d.error || 'Failed') }
  }

  function formatDateTime(v?: string | Date | null) {
    if (!v) return '—'
    const d = new Date(v)
    const opts: any = { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }
    return d.toLocaleString(undefined, opts)
  }

  function daysRemaining(v?: string | Date | null) {
    if (!v) return null
    const end = new Date(v).getTime()
    const now = Date.now()
    const diff = Math.ceil((end - now) / (1000 * 60 * 60 * 24))
    return diff > 0 ? diff : 0
  }

  function kyStatusLabel(s?: string) {
    if (!s) return 'Not Submitted'
    if (s === 'APPROVED') return 'Verified'
    if (s === 'PENDING') return 'Pending'
    if (s === 'REJECTED') return 'Rejected'
    return 'Not Submitted'
  }

  function onSelectLogo(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] || null
    setLogoFile(file)
    setSecMsg(null)
    if (file) setLogoPreview(URL.createObjectURL(file))
    else setLogoPreview(null)
  }

  async function uploadLogo() {
    if (!logoFile) return
    setSecMsg(null)
    const fd = new FormData()
    fd.append('file', logoFile)
    const r = await fetch('/api/checkout-settings/logo-image', { method: 'POST', body: fd })
    if (r.ok) {
      const out = await r.json()
      setSettings(out.settings || out)
      setSecMsg('Logo updated')
      setLogoFile(null)
      setLogoPreview(null)
    } else {
      setSecMsg('Failed to update')
    }
  }

  async function onUploadKyc() {
    setSecMsg(null)
    const fd = new FormData()
    if (docId) fd.append('document', docId)
    if (docAddr) fd.append('selfie', docAddr)
    const r = await fetch('/api/kyc', { method: 'POST', body: fd })
    if (r.ok) {
      const d = await r.json()
      setKyc(d)
      setSecMsg('KYC uploaded')
      setDocId(null)
      setDocAddr(null)
    } else {
      const d = await r.json().catch(()=>({error:'Failed'}))
      setSecMsg(d.error || 'Failed')
    }
  }

  return (
    <div className="space-y-10">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Profile</h1>
          <p className="mt-2 text-slate-600">Update your personal and business information.</p>
        </div>
        <button onClick={() => signOut({ callbackUrl: '/login' })} className="text-sm text-slate-600 hover:text-slate-900 underline">Logout</button>
      </div>

      <section>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 text-sm glass rounded-xl p-6">
          <div className="text-slate-600">Created</div>
          <div className="font-medium">{formatDateTime(data?.createdAt)}</div>
          <div className="text-slate-600">Account ID</div>
          <div className="font-mono break-all">{data?.publicId || data?.id || '—'}</div>
          <div className="text-slate-600">Name</div>
          <div className="font-medium">{data?.name || '—'}</div>
          <div className="text-slate-600">Phone</div>
          <div className="font-medium">{data?.phone || '—'}</div>
          <div className="text-slate-600">Email</div>
          <div className="font-medium">{data?.email || '—'}</div>
          <div className="text-slate-600">Profile Picture</div>
          <div>
            <button className="link underline text-slate-900" onClick={()=>setLogoOpen(true)}>View logo</button>
          </div>
          <div className="text-slate-600">KYC Documents</div>
          <div className="space-x-3">
            <button className="link underline text-slate-900" onClick={()=>setDocsOpen(true)}>View document</button>
            <button className="link underline text-slate-900" onClick={()=>setUploadOpen(true)}>Upload</button>
          </div>
          <div className="text-slate-600">Validity</div>
          <div className="font-medium">{(() => { const d = daysRemaining(sub?.currentPeriodEnd); return d==null ? '—' : `${d} days remaining` })()}</div>
          <div className="text-slate-600">KYC Status</div>
          <div className="font-medium">{kyStatusLabel(kyc?.status)}</div>
          <div className="text-slate-600">Password</div>
          <div><a href="/account/change-password" className="link underline text-slate-900">Change now</a></div>
          <div className="text-slate-600">Status</div>
          <div className="font-medium">{sub?.status || '—'}</div>
        </div>
      </section>

      {/* <section>
        <h2 className="font-semibold">Account Info</h2>
        <form onSubmit={onSaveProfile} className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-slate-700">Name</label>
            <input name="name" defaultValue={data?.name || ''} className="mt-1 w-full rounded-lg border px-3 py-2" required />
          </div>
          <div>
            <label className="text-sm text-slate-700">Email</label>
            <input defaultValue={data?.email || ''} className="mt-1 w-full rounded-lg border px-3 py-2 bg-slate-100" disabled />
          </div>
          <div>
            <label className="text-sm text-slate-700">Phone</label>
            <input name="phone" defaultValue={data?.phone || ''} className="mt-1 w-full rounded-lg border px-3 py-2" required />
          </div>
          <div className="md:col-span-2">
            <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Saving...' : 'Save'}</button>
            {msg && <span className="ml-3 text-sm text-slate-600">{msg}</span>}
          </div>
        </form>
      </section> */}

      {/* <section id="change-password">
        <h2 className="font-semibold">Change Password</h2>
        <form onSubmit={onChangePassword} className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-slate-700">Current Password</label>
            <input name="currentPassword" type="password" className="mt-1 w-full rounded-lg border px-3 py-2" required />
          </div>
          <div>
            <label className="text-sm text-slate-700">New Password</label>
            <input name="newPassword" type="password" minLength={6} className="mt-1 w-full rounded-lg border px-3 py-2" required />
          </div>
          <div className="md:col-span-2">
            <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Change Password</button>
            {pmsg && <span className="ml-3 text-sm text-slate-600">{pmsg}</span>}
          </div>
        </form>
      </section> */}

      {/* Logo Modal */}
      {logoOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-lg bg-white p-4 shadow-lg">
            <div className="flex items-center justify-between -mx-4 -mt-4 px-4 py-3 border-b border-[#366870] bg-[#366870] text-white rounded-t-lg">
              <h3 className="text-lg font-semibold">Business Logo</h3>
              <button onClick={()=>{setLogoOpen(false); setLogoFile(null); setLogoPreview(null); setSecMsg(null)}} className="p-1 rounded hover:bg-white/10 text-white">×</button>
            </div>
            <div className="mt-4 space-y-4">
              <img className="mx-auto h-28 w-28 rounded-full object-cover" src={logoPreview || settings?.logoUrl || '/file.svg'} alt="Logo" />
              <div>
                <input type="file" accept="image/*" onChange={onSelectLogo} className="block w-full text-sm" />
              </div>
              <div className="flex items-center justify-between">
                <button onClick={uploadLogo} disabled={!logoFile} className="rounded-md bg-slate-900 px-4 py-2 text-white disabled:opacity-50">Update</button>
                {secMsg && <span className="text-sm text-slate-600">{secMsg}</span>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Documents Modal */}
      {docsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-2xl rounded-lg bg-white p-4 shadow-lg">
            <div className="flex items-center justify-between -mx-4 -mt-4 px-4 py-3 border-b border-[#366870] bg-[#366870] text-white rounded-t-lg">
              <h3 className="text-lg font-semibold">View Documents</h3>
              <button onClick={()=>setDocsOpen(false)} className="p-1 rounded hover:bg-white/10 text-white">×</button>
            </div>
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <img className="mx-auto max-h-80 object-contain" src={kyc?.documentUrl || ''} alt="Document" />
              </div>
              <div>
                <img className="mx-auto max-h-80 object-contain" src={kyc?.selfieUrl || ''} alt="Selfie" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Documents Modal */}
      {uploadOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md rounded-lg bg-white p-4 shadow-lg">
            <div className="flex items-center justify-between -mx-4 -mt-4 px-4 py-3 border-b border-[#366870] bg-[#366870] text-white rounded-t-lg">
              <h3 className="text-lg font-semibold">Upload Documents</h3>
              <button onClick={()=>{setUploadOpen(false); setDocId(null); setDocAddr(null); setSecMsg(null)}} className="p-1 rounded hover:bg-white/10 text-white">×</button>
            </div>
            <div className="mt-4 space-y-4">
              <div>
                <label className="mb-1 block text-sm text-slate-700">ID proof</label>
                <input type="file" accept="image/*,application/pdf" onChange={(e)=>setDocId(e.target.files?.[0] || null)} className="block w-full text-sm" />
              </div>
              <div>
                <label className="mb-1 block text-sm text-slate-700">Address proof / Selfie</label>
                <input type="file" accept="image/*" onChange={(e)=>setDocAddr(e.target.files?.[0] || null)} className="block w-full text-sm" />
              </div>
              <div className="flex items-center justify-between">
                <button onClick={onUploadKyc} className="rounded-md bg-slate-900 px-4 py-2 text-white">Upload</button>
                {secMsg && <span className="text-sm text-slate-600">{secMsg}</span>}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
