"use client"

import { useEffect, useMemo, useState } from "react"
import { useSearchParams } from "next/navigation"

type Payment = {
  id: string
  timestamp: string
  purpose: string
  amount: number
  utr?: string | null
  screenshot?: string | null
  status: 'Pending' | 'Success' | 'Failed'
  name?: string | null
  phone?: string | null
  email?: string | null
  payMode?: 'UPI' | 'BANK' | 'NA'
  payUpiId?: string | null
  payAccountNumber?: string | null
  payIfsc?: string | null
}

export default function PaymentsPage(){
  const params = useSearchParams()
  const i = (params.get('i') || '').toLowerCase()
  const [query, setQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const [items, setItems] = useState<Payment[]>([])

  useEffect(() => {
    let active = true
    setLoading(true)
    const src = i ? `/api/transactions?i=${encodeURIComponent(i)}` : '/api/transactions'
    fetch(src, { 
      cache: 'default',
      next: { revalidate: 60 } // Revalidate every minute
    }).then(async r => {
      if (!active) return
      if (r.ok) {
        const d = await r.json()
        setItems(d.items || [])
      }
      setLoading(false)
    })
    return () => { active = false }
  }, [i])

  const filtered = useMemo(() => {
    if (!query.trim()) return items
    const q = query.toLowerCase()
    return items.filter(p =>
      p.id.toLowerCase().includes(q) ||
      p.purpose.toLowerCase().includes(q) ||
      (p.utr || '').toLowerCase().includes(q)
    )
  }, [items, query])

  const title = i === 'today' ? "Today's Payments"
    : i === 'pending' ? 'Pending Payments'
    : i === 'success' ? 'Successful Payments'
    : i === 'failed' ? 'Failed Payments'
    : 'All Payments'

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{title}</h1>
        <div className="w-full max-w-xs">
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." className="w-full rounded-lg border px-3 py-2 focus:ring-2 focus:ring-[#366870] focus:border-[#366870]" />
        </div>
      </div>

      <div className="overflow-x-auto glass rounded-xl p-6">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-600">
              <th className="py-2 px-3">Timestamp</th>
              <th className="py-2 px-3">Payment ID</th>
              <th className="py-2 px-3">Purpose</th>
              <th className="py-2 px-3">Amount</th>
              <th className="py-2 px-3">Status</th>
              <th className="py-2 px-3">UTR</th>
              <th className="py-2 px-3">Screenshot</th>
              <th className="py-2 px-3">Name</th>
              <th className="py-2 px-3">Phone</th>
              <th className="py-2 px-3">Email</th>
              <th className="py-2 px-3">Mode</th>
              <th className="py-2 px-3">UPI ID</th>
              <th className="py-2 px-3">Account No.</th>
              <th className="py-2 px-3">IFSC</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr><td className="py-4 px-3" colSpan={14}>Loading...</td></tr>
            )}
            {!loading && filtered.length === 0 && (
              <tr><td className="py-4 px-3" colSpan={14}>No records</td></tr>
            )}
            {!loading && filtered.map(p => (
              <tr key={p.id} className="border-t">
                <td className="py-2 px-3">{p.timestamp}</td>
                <td className="py-2 px-3">{p.id}</td>
                <td className="py-2 px-3">{(() => { const t = String(p.purpose || ''); return t.replace(/^PID:[^|]+\s*\|\s*/i, ''); })()}</td>
                <td className="py-2 px-3">₹ {p.amount.toFixed(2)}</td>
                <td className="py-2 px-3">{p.status}</td>
                <td className="py-2 px-3">{p.utr || 'NA'}</td>
                <td className="py-2 px-3">{p.screenshot ? <a className="text-[#366870] underline" href={p.screenshot} target="_blank" rel="noreferrer">View</a> : 'NA'}</td>
                <td className="py-2 px-3">{p.name || 'NA'}</td>
                <td className="py-2 px-3">{p.phone || 'NA'}</td>
                <td className="py-2 px-3">{p.email || 'NA'}</td>
                <td className="py-2 px-3">{p.payMode || 'NA'}</td>
                <td className="py-2 px-3">{p.payUpiId || 'NA'}</td>
                <td className="py-2 px-3">{p.payAccountNumber || 'NA'}</td>
                <td className="py-2 px-3">{p.payIfsc || 'NA'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
