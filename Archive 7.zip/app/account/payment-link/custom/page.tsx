"use client"

import { useEffect, useState, FormEvent } from "react"

type Link = {
  id: string
  slug: string | null
  title: string
  description?: string | null
  amount?: number | null
  redirectUrl?: string | null
  active: boolean
  createdAt?: string
}

export default function CustomLinkPage(){
  const [links, setLinks] = useState<Link[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [q, setQ] = useState("")
  const [selected, setSelected] = useState<Link | null>(null)
  const [manageTitle, setManageTitle] = useState("")
  const [manageAmount, setManageAmount] = useState<string>("")
  const [manageStatus, setManageStatus] = useState<'Active'|'Inactive'|'Delete'>("Active")
  const [manageRedirectUrl, setManageRedirectUrl] = useState("")
  const [manageLink, setManageLink] = useState("")
  const [copied, setCopied] = useState(false)
  const [updating, setUpdating] = useState(false)

  async function load() {
    setLoading(true)
    const r = await fetch('/api/payment-links/custom')
    setLoading(false)
    if (r.ok) setLinks(await r.json())
  }

  useEffect(() => { load() }, [])

  useEffect(() => {
    if (selected) {
      setManageTitle(selected.title || "")
      setManageAmount(selected.amount != null ? String(selected.amount) : "")
      setManageStatus(selected.active ? 'Active' : 'Inactive')
      setManageRedirectUrl(selected.redirectUrl || "")
      const idOrSlug = selected.slug || selected.id
      const origin = typeof window !== 'undefined' ? window.location.origin : ''
      setManageLink((origin ? origin : '') + `/pay/${idOrSlug}`)
      setCopied(false)
    }
  }, [selected])

  function formatDateTime(v?: string) {
    if (!v) return "";
    const d = new Date(v)
    const day = String(d.getDate()).padStart(2, '0')
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const year = d.getFullYear()
    let h = d.getHours()
    const m = String(d.getMinutes()).padStart(2, '0')
    const s = String(d.getSeconds()).padStart(2, '0')
    const ampm = h >= 12 ? 'PM' : 'AM'
    h = h % 12; if (h === 0) h = 12
    const hh = String(h).padStart(2, '0')
    return `${day}-${month}-${year} ${hh}:${m}:${s} ${ampm}`
  }

  async function copyLink(){
    try {
      await navigator.clipboard.writeText(manageLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  async function onUpdate(){
    if (!selected) return
    if (manageStatus === 'Delete') {
      setUpdating(true)
      const r = await fetch(`/api/payment-links/${selected.id}`, { method: 'DELETE' })
      setUpdating(false)
      if (r.ok) {
        setSelected(null)
        await load()
      } else {
        const d = await r.json().catch(()=>({error:'Failed'}))
        setMsg(d.error || 'Failed')
      }
      return
    }
    setUpdating(true)
    const body: any = {
      title: manageTitle,
      amount: manageAmount ? Number(manageAmount) : null,
      redirectUrl: manageRedirectUrl || null,
      active: manageStatus === 'Active',
    }
    const res = await fetch(`/api/payment-links/${selected.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    setUpdating(false)
    if (res.ok) {
      setSelected(null)
      await load()
    } else {
      const d = await res.json().catch(()=>({error:'Failed'}))
      setMsg(d.error || 'Failed')
    }
  }

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    setMsg(null)
    const fd = new FormData(e.currentTarget)
    const payload = {
      title: String(fd.get('purpose') || ''),
      amount: fd.get('amount') ? Number(fd.get('amount')) : null,
      redirectUrl: String(fd.get('redirect_url') || '') || null,
      active: true,
    }
    const res = await fetch('/api/payment-links/custom', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (res.ok) {
      await load()
      ;(e.target as HTMLFormElement).reset()
      setMsg('Created')
    } else {
      const data = await res.json().catch(()=>({error:'Failed'}))
      setMsg(data.error || 'Failed')
    }
  }

  const filtered = links.filter(l => {
    const term = q.trim().toLowerCase()
    if (!term) return true
    return (
      (l.title || '').toLowerCase().includes(term) ||
      (l.slug || '').toLowerCase().includes(term)
    )
  })

  return (
    <div>
      <div className="text-xl font-semibold">Create Link</div>
      <div className="mt-6">
        <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-4 glass rounded-xl p-6">
          <div>
            <label className="text-sm text-slate-700">Purpose</label>
            <input name="purpose" id="purpose" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter purpose" autoComplete="off" required />
          </div>
          <div>
            <label className="text-sm text-slate-700">Amount</label>
            <input name="amount" id="amount" type="number" min={0} step="0.01" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter amount" autoComplete="off" />
          </div>
          <div>
            <label className="text-sm text-slate-700">Redirect URL</label>
            <input name="redirect_url" id="redirect_url" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter redirect URL" autoComplete="off" />
          </div>
          <div className="md:col-span-3">
            <button id="createPaymentLink" disabled={saving} className="dashboard_container_button rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Creating...' : 'Create'}</button>
            {msg && <span className="ml-3 text-sm text-slate-600">{msg}</span>}
          </div>
        </form>
      </div>
    <div className="glass rounded-xl gap-4 mt-10 p-6">
      <div className="mt-8 flex items-center justify-between">
        <div className="font-semibold">Links</div>
        <div className="w-64">
          <input value={q} onChange={e=>setQ(e.target.value)} className="w-full rounded-lg border px-3 py-2" placeholder="Search..." />
        </div>
      </div>

      <div className="mt-4 rounded-xl border overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-slate-50 text-left">
              <th className="px-4 py-2">Timestamp</th>
              <th className="px-4 py-2">Link ID</th>
              <th className="px-4 py-2">Purpose</th>
              <th className="px-4 py-2">Amount</th>
              <th className="px-4 py-2">Redirection</th>
              <th className="px-4 py-2">Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="px-4 py-3 text-slate-600" colSpan={6}>Loading...</td></tr>
            ) : filtered.length === 0 ? (
              <tr><td className="px-4 py-3 text-slate-600" colSpan={6}>No links</td></tr>
            ) : (
              filtered.map(l => (
                <tr key={l.id} className="border-t">
                  <td className="px-4 py-3">{formatDateTime(l.createdAt)}</td>
                  <td className="px-4 py-3">
                    <button
                      className="link_a text-slate-700 hover:underline"
                      onClick={() => setSelected(l)}
                    >{l.slug || l.id.slice(0,8)}</button>
                  </td>
                  <td className="px-4 py-3">{l.title}</td>
                  <td className="px-4 py-3">{l.amount != null ? Number(l.amount).toFixed(2) : '-'}</td>
                  <td className="px-4 py-3">{l.redirectUrl ? 'Enabled' : 'Not enabled'}</td>
                  <td className="px-4 py-3">{l.active ? 'Active' : 'Inactive'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-xl w-full max-w-2xl shadow-lg">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#366870] bg-[#366870] text-white">
              <div className="text-lg font-semibold">Manage Link</div>
              <button id="closeActionModal" onClick={() => setSelected(null)} className="p-1 rounded text-white hover:bg-white/10">×</button>
            </div>
            <div id="actionModalContent" className="p-4 space-y-4">
              <div>
                <label className="text-sm text-slate-700">Payment link</label>
                <div className="mt-1 flex gap-2">
                  <input value={manageLink} readOnly className="w-full rounded-lg border px-3 py-2" />
                  <button type="button" className="rounded-md bg-slate-900 text-white px-3 py-2 text-sm" onClick={copyLink}>{copied ? 'Copied' : 'Copy'}</button>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-700">Timestamp</label>
                  <input value={formatDateTime(selected.createdAt)} disabled className="mt-1 w-full rounded-lg border px-3 py-2" />
                </div>
                <div>
                  <label className="text-sm text-slate-700">Purpose</label>
                  <input value={manageTitle} onChange={e=>setManageTitle(e.target.value)} name="purpose" id="purpose" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter purpose" autoComplete="off" />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-slate-700">Amount</label>
                  <input value={manageAmount} onChange={e=>setManageAmount(e.target.value)} name="amount" id="amount" type="number" min={0} step="0.01" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter amount" autoComplete="off" />
                </div>
                <div>
                  <label className="text-sm text-slate-700">Status</label>
                  <select value={manageStatus} onChange={e=>setManageStatus(e.target.value as any)} className="mt-1 w-full rounded-lg border px-3 py-2" name="link_status" id="link_status">
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Delete">Delete</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm text-slate-700">Redirect URL</label>
                <input value={manageRedirectUrl} onChange={e=>setManageRedirectUrl(e.target.value)} name="redirect_url" id="redirect_url" className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter redirect URL" autoComplete="off" />
              </div>
              <div>
                <button id="updatePaymentLink" onClick={onUpdate} disabled={updating} className="dashboard_container_button rounded-lg bg-slate-900 px-4 py-2 text-white">{updating ? 'Updating...' : 'Update'}</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
