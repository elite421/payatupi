"use client"

import { useEffect, useState } from "react"

export default function DefaultLinkPage(){
  const [link, setLink] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [origin, setOrigin] = useState("")
  const [copied, setCopied] = useState(false)
  const [creating, setCreating] = useState(false)

  useEffect(() => {
    let mounted = true
    setOrigin(window.location.origin)
    fetch('/api/payment-links/default').then(async r => {
      if (!mounted) return
      setLoading(false)
      if (r.ok) setLink(await r.json())
      else setLink(null)
    }).catch(() => { if (mounted) { setLoading(false); setLink(null) } })
    return () => { mounted = false }
  }, [])

  const payUrl = link?.id ? `${origin}/pay/${link.slug || link.id}` : ""

  async function copyToClipboard() {
    if (!payUrl) return
    try {
      await navigator.clipboard.writeText(payUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      const temp = document.createElement('input')
      temp.value = payUrl
      document.body.appendChild(temp)
      temp.select()
      document.execCommand('copy')
      temp.remove()
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    }
  }

  function shareOnWhatsApp() {
    if (!payUrl) return
    const message = `Hello, you can now pay me via Payatupi. Click here to pay: ${payUrl}`
    window.open('https://api.whatsapp.com/send?text=' + encodeURIComponent(message), '_blank')
  }

  function shareOnFacebook() {
    if (!payUrl) return
    const message = `Hello, you can now pay me via Payatupi. Click here to pay: ${payUrl}`
    window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(payUrl) + '&quote=' + encodeURIComponent(message), '_blank')
  }

  function shareOnTwitter() {
    if (!payUrl) return
    const message = `Hello, you can now pay me via Payatupi. Click here to pay: ${payUrl}`
    window.open('https://twitter.com/intent/tweet?url=' + encodeURIComponent(payUrl) + '&text=' + encodeURIComponent(message), '_blank')
  }

  function shareOnTelegram() {
    if (!payUrl) return
    const message = `Hello, you can now pay me via Payatupi. Click here to pay: ${payUrl}`
    window.open('https://t.me/share/url?url=' + encodeURIComponent(payUrl) + '&text=' + encodeURIComponent(message), '_blank')
  }

  async function downloadQR() {
    if (!payUrl) return
    const imgUrl = `https://quickchart.io/qr?size=800&text=${encodeURIComponent(payUrl)}`
    try {
      const res = await fetch(imgUrl)
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'Payment-Link-QR.png'
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } catch {}
  }

  async function createDefault() {
    setCreating(true)
    try {
      const res = await fetch('/api/payment-links/default', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'Default Payment Link', description: '', amount: null, active: true }),
      })
      if (res.ok) {
        const data = await res.json()
        setLink(data)
      }
    } finally {
      setCreating(false)
    }
  }

  const qrSrc = payUrl ? `https://quickchart.io/qr?size=300&text=${encodeURIComponent(payUrl)}` : ""

  return (
    <div>
      <h1 className="text-2xl font-semibold">Default Link</h1>
      <p className="mt-2 text-slate-600">Share your default payment link and QR.</p>

      {loading ? (
        <div className="mt-6 text-sm text-slate-600">Loading...</div>
      ) : !link ? (
        <div className="mt-6">
          <div className="text-sm text-slate-600 mb-3">You haven't created a default link yet.</div>
          <button onClick={createDefault} disabled={creating} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{creating ? 'Creating...' : 'Create Default Link'}</button>
        </div>
      ) : (
        <>
          <div className="mt-6 flex gap-2 glass rounded-xl p-6">
            <input value={payUrl} readOnly className="w-full rounded-lg border px-3 py-2" />
            <button onClick={copyToClipboard} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{copied ? 'Copied' : 'Copy'}</button>
          </div>

          <div className="mt-4 flex gap-2 flex-wrap glass rounded-xl p-6">
            <button onClick={shareOnWhatsApp} className="rounded-md bg-emerald-500 hover:bg-emerald-600 text-white px-3 py-2 text-sm">WhatsApp</button>
            <button onClick={shareOnFacebook} className="rounded-md bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 text-sm">Facebook</button>
            <button onClick={shareOnTwitter} className="rounded-md bg-slate-800 hover:bg-black text-white px-3 py-2 text-sm">Twitter</button>
            <button onClick={shareOnTelegram} className="rounded-md bg-sky-500 hover:bg-sky-600 text-white px-3 py-2 text-sm">Telegram</button>
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between">
              <div className="font-semibold">Link QR</div>
              <button onClick={downloadQR} className="text-sm text-slate-700 hover:underline">Download</button>
            </div>
            <div className="mt-3 flex justify-center glass rounded-xl p-6">
              <div className="rounded-xl border p-4 text-center">
                {qrSrc && <img src={qrSrc} alt="Payment Link QR Code" className="mx-auto" />}
                <p className="mt-3 text-sm text-slate-700">Scan QR code to pay</p>
                <p className="text-xs text-slate-500">Powered by Payatupi</p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
