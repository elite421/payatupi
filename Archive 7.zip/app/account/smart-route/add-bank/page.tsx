"use client"

import { useEffect, useMemo, useState, FormEvent } from "react"

type Bank = { id: string; accountHolder: string; accountNumber: string; ifsc: string; bankName: string }

export default function AddBankPage(){
  const [items, setItems] = useState<Bank[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [query, setQuery] = useState("")

  async function load() {
    setLoading(true)
    const r = await fetch('/api/bank-accounts')
    setLoading(false)
    if (r.ok) setItems(await r.json())
  }

  useEffect(() => { load() }, [])

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    const fd = new FormData(e.currentTarget)
    const payload = {
      accountHolder: String(fd.get('accountHolder') || ''),
      accountNumber: String(fd.get('accountNumber') || ''),
      ifsc: String(fd.get('ifsc') || ''),
      bankName: String(fd.get('bankName') || ''),
    }
    const res = await fetch('/api/bank-accounts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (res.ok) {
      await load()
      ;(e.target as HTMLFormElement).reset()
    }
  }

  async function remove(id: string) {
    await fetch(`/api/bank-accounts/${id}`, { method: 'DELETE' })
    await load()
  }

  const filtered = useMemo(() => {
    if (!query.trim()) return items
    const q = query.toLowerCase()
    return items.filter(i => (
      i.accountHolder.toLowerCase().includes(q) ||
      i.accountNumber.toLowerCase().includes(q) ||
      i.ifsc.toLowerCase().includes(q) ||
      i.bankName.toLowerCase().includes(q)
    ))
  }, [items, query])

  return (
    <div>
      <h1 className="text-2xl font-semibold">Add Bank Account</h1>
      <p className="mt-2 text-slate-600">Link a bank account for settlements.</p>

      <form onSubmit={onSubmit} className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 glass rounded-xl p-6">
        <div>
          <label className="text-sm text-slate-700">Account Holder</label>
          <input name="accountHolder" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="text-sm text-slate-700">Account Number</label>
          <input name="accountNumber" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="text-sm text-slate-700">IFSC</label>
          <input name="ifsc" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="text-sm text-slate-700">Bank Name</label>
          <input name="bankName" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div className="md:col-span-2">
          <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Adding...' : 'Proceed'}</button>
        </div>
      </form>

      <div className="mt-8">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Saved Bank Accounts</h2>
          <div className="w-full max-w-xs">
            <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search..." className="w-full rounded-lg border px-3 py-2" />
          </div>
        </div>
        {loading ? (
          <div className="mt-3 text-sm text-slate-600">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="mt-3 text-sm text-slate-600">No bank accounts found.</div>
        ) : (
          <div className="mt-4 overflow-x-auto glass rounded-xl p-6">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-600">
                  <th className="py-2 px-3">Bank</th>
                  <th className="py-2 px-3">Account Holder</th>
                  <th className="py-2 px-3">Account Number</th>
                  <th className="py-2 px-3">IFSC</th>
                  <th className="py-2 px-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(i => (
                  <tr key={i.id} className="border-t">
                    <td className="py-2 px-3">{i.bankName}</td>
                    <td className="py-2 px-3">{i.accountHolder}</td>
                    <td className="py-2 px-3">{i.accountNumber}</td>
                    <td className="py-2 px-3">{i.ifsc}</td>
                    <td className="py-2 px-3 text-right"><button onClick={() => remove(i.id)} className="rounded-md bg-red-600 text-white px-3 py-1 text-sm">Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
