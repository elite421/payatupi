"use client"

import { useEffect, useState, FormEvent, ChangeEvent } from "react"

export default function CheckoutSettingsPage(){
  const [data, setData] = useState<any>(null)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [msgUser, setMsgUser] = useState<string | null>(null)
  const [msgMessage, setMsgMessage] = useState<string | null>(null)
  const [msgAd, setMsgAd] = useState<string | null>(null)
  const [msgMask, setMsgMask] = useState<string | null>(null)
  const [msgAutomation, setMsgAutomation] = useState<string | null>(null)

  useEffect(() => {
    fetch('/api/checkout-settings').then(async r => {
      if (r.ok) setData(await r.json())
      else setData({})
    }).catch(()=>setData({}))
  }, [])

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setSaving(true)
    setMsg(null)
    const fd = new FormData(e.currentTarget)
    const payload: any = {
      logoUrl: String(fd.get('logoUrl') || ''),
      themeColor: String(fd.get('themeColor') || ''),
      successRedirectUrl: String(fd.get('successRedirectUrl') || ''),
      enableTips: fd.get('enableTips') === 'on',
      enableNotes: fd.get('enableNotes') === 'on',
      currency: String(fd.get('currency') || 'INR')
    }
    const res = await fetch('/api/checkout-settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
    setSaving(false)
    if (res.ok) {
      setData(await res.json())
      setMsg('Saved')
    } else {
      setMsg('Failed to save')
    }
  }

  async function updateSettings(partial: any, setSectionMsg: (s: string|null)=>void) {
    setSectionMsg(null)
    const r = await fetch('/api/checkout-settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(partial) })
    if (r.ok) { setData(await r.json()); setSectionMsg('Updated') } else { setSectionMsg('Failed') }
  }

  async function onUpdateUserInput(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const valToBool = (v: unknown) => String(v || '').toLowerCase() === 'enable'
    const payload = {
      enablePurpose: valToBool(fd.get('purpose_field')),
      enableName: valToBool(fd.get('name_field')),
      enablePhone: valToBool(fd.get('phone_field')),
      enableEmail: valToBool(fd.get('email_field')),
    }
    await updateSettings(payload, setMsgUser)
  }

  async function onUpdateMessage(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const payload = { checkoutMessage: String(fd.get('checkout_text') || '') }
    await updateSettings(payload, setMsgMessage)
  }

  async function onResetMessage() {
    await updateSettings({ checkoutMessage: null }, setMsgMessage)
  }

  async function onUpdateProcessing(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const mode = String(fd.get('processing_mode') || '')
    const smsAutomation = mode === 'auto'
    await updateSettings({ smsAutomation }, setMsgAutomation)
  }

  async function onUploadAdFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setMsgAd(null)
    const fd = new FormData()
    fd.append('file', file)
    const r = await fetch('/api/checkout-settings/ad-image', { method: 'POST', body: fd })
    if (r.ok) { const out = await r.json(); setData(out.settings); setMsgAd('Ad image uploaded') } else { setMsgAd('Upload failed') }
    // clear the input
    e.target.value = ''
  }

  async function onUpdateAdLink(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    const payload = { advertisementLink: String(fd.get('checkout_ad_link') || '') }
    await updateSettings(payload, setMsgAd)
  }

  async function onRemoveAd() {
    await updateSettings({ advertisementImageUrl: null, advertisementLink: null }, setMsgAd)
  }

  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); setMsgAd('Copied'); setTimeout(()=>setMsgAd(null), 1500) } catch {}
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">Checkout Settings</h1>
      <p className="mt-2 text-slate-600">Configure your checkout experience and preferences.</p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4 glass rounded-xl p-6">
        <div>
          <label className="text-sm text-slate-700">Logo URL</label>
          <input name="logoUrl" defaultValue={data?.logoUrl || ''} className="mt-1 w-full rounded-lg border px-3 py-2" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-sm text-slate-700">Theme Color</label>
            <input name="themeColor" type="text" placeholder="#3c74f6" defaultValue={data?.themeColor || ''} className="mt-1 w-full rounded-lg border px-3 py-2" />
          </div>
          <div>
            <label className="text-sm text-slate-700">Currency</label>
            <input name="currency" defaultValue={data?.currency || 'INR'} className="mt-1 w-full rounded-lg border px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="text-sm text-slate-700">Success Redirect URL</label>
          <input name="successRedirectUrl" defaultValue={data?.successRedirectUrl || ''} className="mt-1 w-full rounded-lg border px-3 py-2" />
        </div>
        <div className="flex items-center gap-6">
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input name="enableTips" type="checkbox" defaultChecked={!!data?.enableTips} className="h-4 w-4" /> Enable Tips
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-700">
            <input name="enableNotes" type="checkbox" defaultChecked={data?.enableNotes ?? true} className="h-4 w-4" /> Enable Notes
          </label>
        </div>
        <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white">{saving ? 'Saving...' : 'Save'}</button>
        {msg && <span className="ml-3 text-sm text-slate-600">{msg}</span>}
      </form>

      {/* User Input (Purpose/Name/Phone/Email) */}
      <div className="mt-10">
        <h2 className="font-semibold">User Input</h2>
        <form onSubmit={onUpdateUserInput} className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4 glass rounded-xl p-6">
          <div>
            <label className="text-sm text-slate-700">Purpose</label>
            <select name="purpose_field" defaultValue={data?.enablePurpose ? 'Enable' : 'Disable'} className="mt-1 w-full rounded-lg border px-3 py-2">
              <option value="Enable">Enable</option>
              <option value="Disable">Disable</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-700">Name</label>
            <select name="name_field" defaultValue={data?.enableName ? 'Enable' : 'Disable'} className="mt-1 w-full rounded-lg border px-3 py-2">
              <option value="Enable">Enable</option>
              <option value="Disable">Disable</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-700">Phone</label>
            <select name="phone_field" defaultValue={data?.enablePhone ? 'Enable' : 'Disable'} className="mt-1 w-full rounded-lg border px-3 py-2">
              <option value="Enable">Enable</option>
              <option value="Disable">Disable</option>
            </select>
          </div>
          <div>
            <label className="text-sm text-slate-700">Email</label>
            <select name="email_field" defaultValue={data?.enableEmail ? 'Enable' : 'Disable'} className="mt-1 w-full rounded-lg border px-3 py-2">
              <option value="Enable">Enable</option>
              <option value="Disable">Disable</option>
            </select>
          </div>
          <div className="md:col-span-4">
            <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Update</button>
            {msgUser && <span className="ml-3 text-sm text-slate-600">{msgUser}</span>}
          </div>
        </form>
      </div>

      {/* Payment Processing */}
      <div className="mt-10">
        <h2 className="font-semibold">Payment Processing</h2>
        <form key={data?.smsAutomation ? 'auto' : 'manual'} onSubmit={onUpdateProcessing} className="mt-4 glass rounded-xl p-6 space-y-4">
          <div className="flex flex-col sm:flex-row gap-6">
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="radio" name="processing_mode" value="manual" defaultChecked={!data?.smsAutomation} className="h-4 w-4" />
              Manual (merchant updates status)
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input type="radio" name="processing_mode" value="auto" defaultChecked={!!data?.smsAutomation} className="h-4 w-4" />
              Automated via Android SMS App
            </label>
          </div>
          <div>
            <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Update</button>
            {msgAutomation && <span className="ml-3 text-sm text-slate-600">{msgAutomation}</span>}
          </div>
        </form>
      </div>


      {/* Checkout Message */}
      <div className="mt-10">
        <h2 className="font-semibold">Checkout Message</h2>
        <form onSubmit={onUpdateMessage} className="mt-4 space-y-4 glass rounded-xl p-6">
          <div>
            <label className="text-sm text-slate-700">Message</label>
            <textarea name="checkout_text" defaultValue={data?.checkoutMessage || ''} className="mt-1 w-full rounded-lg border px-3 py-2" rows={4} placeholder="Enter message" />
          </div>
          <div className="flex items-center gap-3">
            <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Update</button>
            <button type="button" onClick={onResetMessage} className="rounded-lg bg-slate-100 px-4 py-2">Remove</button>
            {msgMessage && <span className="text-sm text-slate-600">{msgMessage}</span>}
          </div>
        </form>
      </div>

      {/* Checkout Advertisement */}
      <div className="mt-10">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">Checkout Advertisement</h2>
        </div>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 glass rounded-xl p-6">
          <div>
            <label className="text-sm text-slate-700">Advertisement image</label>
            <input
              type="file"
              onChange={onUploadAdFile}
              accept="image/*"
              className="mt-1 block w-full text-sm rounded-md border px-3 py-2 bg-white text-slate-800 cursor-pointer file:mr-3 file:rounded-md file:border-0 file:bg-slate-900 file:text-white file:px-3 file:py-2 file:cursor-pointer"
            />
            {data?.advertisementImageUrl && (
              <div className="mt-3">
                <img src={data.advertisementImageUrl} alt="Ad" className="max-h-40 rounded border" />
              </div>
            )}
          </div>
          <form onSubmit={onUpdateAdLink} className="md:col-span-2">
            <label className="text-sm text-slate-700">Advertisement link</label>
            <input name="checkout_ad_link" defaultValue={data?.advertisementLink || ''} className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter advertisement link" />
            <div className="mt-3 flex items-center gap-3">
              <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Update</button>
              {data?.advertisementLink && (
                <button type="button" onClick={()=>copy(data.advertisementLink)} className="rounded-lg bg-slate-100 px-4 py-2">Copy</button>
              )}
              <button type="button" onClick={onRemoveAd} className="rounded-lg bg-red-600 text-white px-4 py-2">Remove</button>
              {msgAd && <span className="text-sm text-slate-600">{msgAd}</span>}
            </div>
          </form>
        </div>
      </div>

      {/* Merchant Identity */}
      <div className="mt-10">
        <h2 className="font-semibold">Merchant Identity</h2>
        <form
          onSubmit={async (e) => {
            e.preventDefault()
            const fd = new FormData(e.currentTarget as HTMLFormElement)
            const payload = {
              maskMerchantName: (fd.get('maskMerchantName') === 'on'),
              maskedMerchantName: String(fd.get('maskedMerchantName') || ''),
            }
            await updateSettings(payload, setMsgMask)
          }}
          className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4 glass rounded-xl p-6"
        >
        
          <div className="md:col-span-1 flex items-center gap-2">
            <label className="text-sm text-slate-700 flex items-center gap-2">
              <input name="maskMerchantName" type="checkbox" defaultChecked={!!data?.maskMerchantName} className="h-4 w-4" /> Display Name
            </label>
          </div>
          <div className="md:col-span-2">
            <label className="text-sm text-slate-700">Display Name</label>
            <input name="maskedMerchantName" defaultValue={data?.maskedMerchantName || ''} className="mt-1 w-full rounded-lg border px-3 py-2" placeholder="Enter name to display (e.g. ABC Store)" />
          </div>
          <div className="md:col-span-3">
            <button className="rounded-lg bg-slate-900 px-4 py-2 text-white">Update</button>
            {msgMask && <span className="ml-3 text-sm text-slate-600">{msgMask}</span>}
          </div>
        
          
        </form>
      </div>
    </div>
  )
}
