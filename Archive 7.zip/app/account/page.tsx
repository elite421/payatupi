"use client"

import { useEffect, useMemo, useState } from "react"

type Payment = {
  id: string
  displayId?: string
  timestamp: string
  purpose: string
  amount: number
  utr?: string | null
  screenshot?: string | null
  status: 'Pending' | 'Success' | 'Failed'
  statusSource?: string | null
  name?: string | null
  phone?: string | null
  email?: string | null
  payMode?: 'UPI' | 'BANK' | 'NA'
  payUpiId?: string | null
  payAccountNumber?: string | null
  payIfsc?: string | null
}

export default function Dashboard(){
  const [query, setQuery] = useState("")
  const [modalOpen, setModalOpen] = useState(false)
  const [selected, setSelected] = useState<Payment | null>(null)
  const [payments, setPayments] = useState<Payment[]>([])
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [stats, setStats] = useState({ 
    todayTotal: 0, 
    pendingTotal: 0, 
    successTotal: 0, 
    failedTotal: 0 
  })
  const [imgOpen, setImgOpen] = useState(false)
  const [imgSrc, setImgSrc] = useState<string | null>(null)

  useEffect(() => {
    let active = true
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)
        const r = await fetch('/api/dashboard', { 
          cache: 'default',
          next: { revalidate: 30 } // Revalidate every 30 seconds
        })
        if (!r.ok) throw new Error('Failed to fetch data')
        const d = await r.json()
        if (!active) return
        const recent = Array.isArray(d.recent) ? d.recent : []
        const filtered = recent.filter((t: any) => !/^subscription\s/i.test(String(t.purpose || '')))
        setPayments(filtered)
        setStats({
          todayTotal: d.todayTotal || 0,
          pendingTotal: d.pendingTotal || 0,
          successTotal: d.successTotal || 0,
          failedTotal: d.failedTotal || 0,
        })
      } catch (err) {
        if (active) {
          setError('Failed to load dashboard data')
          console.error('Dashboard fetch error:', err)
        }
      } finally {
        if (active) setLoading(false)
      }
    }
    
    fetchData()
    return () => { active = false }
  }, [])

  const filtered = useMemo(() => {
    if (!query.trim()) return payments
    const q = query.toLowerCase()
    return payments.filter(p =>
      (p.displayId || p.id).toLowerCase().includes(q) ||
      p.purpose.toLowerCase().includes(q) ||
      (p.utr || '').toLowerCase().includes(q) ||
      (p.name || '').toLowerCase().includes(q) ||
      (p.email || '').toLowerCase().includes(q)
    )
  }, [payments, query])

  const { todayTotal, pendingTotal, successTotal, failedTotal } = stats

  function openModal(p: Payment){ 
    setSelected(p)
    setModalOpen(true) 
  }
  
  function closeModal(){ 
    setModalOpen(false)
    setSelected(null) 
  }

  async function updateStatus(id: string, status: Payment['status']){
    try {
      setUpdating(true)
      setError(null)
      const r = await fetch(`/api/transactions/${encodeURIComponent(id)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })
      if (!r.ok) throw new Error('Failed to update status')
      
      setPayments(prev => prev.map(p => p.id === id ? { ...p, status, statusSource: 'MANUAL' } : p))
      closeModal()
    } catch (err) {
      setError('Failed to update payment status')
      console.error('Update status error:', err)
    } finally {
      setUpdating(false)
    }
  }

  const getStatusColor = (status: Payment['status']) => {
    switch (status) {
      case 'Success': return 'bg-green-100 text-green-800 border-green-200'
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200'
      case 'Failed': return 'bg-red-100 text-red-800 border-red-200'
      default: return 'bg-gray-100 text-gray-800 border-gray-200'
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#366870] mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50/30 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Payment Dashboard</h1>
        <p className="mt-2 text-gray-600">Monitor and manage all payment transactions</p>
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700">
          <div className="flex items-center">
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            {error}
          </div>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Today's Collection</p>
              <p className="mt-2 text-2xl font-bold text-gray-900">{formatCurrency(todayTotal)}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2">
  <path
    strokeLinecap="round"
    strokeLinejoin="round"
    d="M6 4h12M6 8h12M10 4c4 0 6 2.5 6 5s-2 5-6 5H6l8 6"
  />
</svg>
            </div>
          </div>
          <a href="/account/payments?i=today" className="mt-4 inline-flex items-center text-sm text-[#366870] hover:text-[#2f5b62] font-medium">
            View all
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Pending Payments</p>
              <p className="mt-2 text-2xl font-bold text-yellow-600">{formatCurrency(pendingTotal)}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <a href="/account/payments?i=pending" className="mt-4 inline-flex items-center text-sm text-[#366870] hover:text-[#2f5b62] font-medium">
            View all
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Successful Payments</p>
              <p className="mt-2 text-2xl font-bold text-green-600">{formatCurrency(successTotal)}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <a href="/account/payments?i=success" className="mt-4 inline-flex items-center text-sm text-[#366870] hover:text-[#2f5b62] font-medium">
            View all
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Failed Payments</p>
              <p className="mt-2 text-2xl font-bold text-red-600">{formatCurrency(failedTotal)}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
          </div>
          <a href="/account/payments?i=failed" className="mt-4 inline-flex items-center text-sm text-[#366870] hover:text-[#2f5b62] font-medium">
            View all
            <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>

      {/* Recent Payments Card */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Recent Payments</h2>
              <p className="text-sm text-gray-600 mt-1">
                {payments.length} payment{payments.length !== 1 ? 's' : ''} found
              </p>
            </div>
            <div className="relative w-full sm:w-64">
              <input 
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search payments..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#366870] focus:border-[#366870]"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {['Date & Time', 'Payment ID', 'Purpose', 'Amount', 'UTR', 'Screenshot', 'Status'].map((header) => (
                  <th key={header} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center">
                    <div className="text-gray-500">
                      <svg className="w-12 h-12 mx-auto text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="mt-4 text-lg font-medium">No payments found</p>
                      <p className="mt-1 text-sm">
                        {query ? 'Try adjusting your search terms' : 'No payments available'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map(payment => (
                  <tr key={payment.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm text-gray-900">
                      <div className="font-medium">{payment.timestamp.split(' ')[0]}</div>
                      <div className="text-gray-500 text-xs">{payment.timestamp.split(' ').slice(1).join(' ')}</div>
                    </td>
                    <td className="px-6 py-4">
                      <button 
                        onClick={() => openModal(payment)}
                        className="text-[#366870] hover:text-[#2f5b62] font-medium text-sm text-left"
                      >
                        {payment.displayId || payment.id}
                      </button>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">
                      {(() => { const t = String(payment.purpose || ''); return t.replace(/^PID:[^|]+\s*\|\s*/i, ''); })()}
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {formatCurrency(payment.amount)}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-gray-600">
                      {payment.utr || (
                        <span className="text-gray-400 italic">Not available</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {payment.screenshot ? (
                        <button
                          type="button"
                          onClick={() => { setImgSrc(payment.screenshot!); setImgOpen(true) }}
                          className="inline-flex items-center text-[#366870] hover:text-[#2f5b62] text-sm font-medium"
                        >
                          <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                          View
                        </button>
                      ) : (
                        <span className="text-gray-400 text-sm italic">Not available</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(payment.status)}`}>
                        {payment.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Detail Modal */}
      {modalOpen && selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-[#366870] bg-[#366870] text-white">
              <div>
                <h2 className="text-xl font-semibold text-white">Payment Details</h2>
                <p className="text-sm text-white/80 mt-1">Manage payment status and view details</p>
              </div>
              <button 
                onClick={closeModal}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                disabled={updating}
              >
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Basic Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
                <div className="text-gray-600">Date</div>
                <div className="text-gray-900">{selected.timestamp.split(' ')[0]}</div>
                <div className="text-gray-600">Time</div>
                <div className="text-gray-900">{selected.timestamp.split(' ').slice(1).join(' ')}</div>
                <div className="text-gray-600">Purpose</div>
                <div className="text-gray-900">{(() => { const t = String(selected.purpose || ''); return t.replace(/^PID:[^|]+\s*\|\s*/i, ''); })()}</div>
                <div className="text-gray-600">Payment ID</div>
                <div className="text-gray-900 font-mono break-all">{selected.displayId || selected.id}</div>
                <div className="text-gray-600">Payment Mode</div>
                <div className="text-gray-900">{selected.payMode || 'Not specified'}</div>
                <div className="text-gray-600">UPI ID</div>
                <div className="text-gray-900 font-mono break-all">{selected.payUpiId || '—'}</div>
                <div className="text-gray-600">Amount</div>
                <div className="text-gray-900 font-semibold">{formatCurrency(selected.amount)}</div>
                <div className="text-gray-600">UTR</div>
                <div className="text-gray-900 font-mono break-all">{selected.utr || 'Not available'}</div>
                <div className="text-gray-600">Status</div>
                <div className="text-gray-900">{selected.status}</div>
              </div>

              {/* Customer Information */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Customer Information</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
                  <div className="text-gray-600">Name</div>
                  <div className="text-gray-900">{selected.name || 'Not available'}</div>
                  <div className="text-gray-600">Phone</div>
                  <div className="text-gray-900 break-all">{selected.phone || 'Not available'}</div>
                  <div className="text-gray-600">Email</div>
                  <div className="text-gray-900 break-all">{selected.email || 'Not available'}</div>
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Payment Method</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
                  {selected.payMode === 'BANK' && (
                    <>
                      <div className="text-gray-600">Account Number</div>
                      <div className="text-gray-900 font-mono break-all">{selected.payAccountNumber}</div>
                      <div className="text-gray-600">IFSC Code</div>
                      <div className="text-gray-900 font-mono break-all">{selected.payIfsc}</div>
                    </>
                  )}
                </div>
              </div>

              {/* Transaction Details */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Transaction Details</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6 text-sm">
                  <div className="text-gray-600">UTR</div>
                  <div className="text-gray-900 font-mono break-all">{selected.utr || 'Not available'}</div>
                  <div className="text-gray-600">Screenshot</div>
                  <div>
                    {selected.screenshot ? (
                      <button
                        type="button"
                        onClick={() => { setImgSrc(selected.screenshot!); setImgOpen(true) }}
                        className="inline-flex items-center text-[#366870] hover:text-[#2f5b62] text-sm font-medium"
                      >
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                        View Screenshot
                      </button>
                    ) : (
                      <span className="text-gray-400 italic">Not available</span>
                    )}
                  </div>
                  <div className="text-gray-600">Status Source</div>
                  <div className="text-gray-900">
                    {selected.statusSource ? (selected.statusSource === 'SMS' ? 'Automated (SMS)' : selected.statusSource) : '—'}
                  </div>
                </div>
              </div>

              {/* Status Update */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Update Status</label>
                <select 
                  value={selected.status}
                  onChange={e => setSelected(prev => prev ? { ...prev, status: e.target.value as Payment['status'] } : prev)}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-[#366870] focus:ring-[#366870]"
                  disabled={updating}
                >
                  <option value="Pending">Pending</option>
                  <option value="Success">Success</option>
                  <option value="Failed">Failed</option>
                </select>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end space-x-3 p-6 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
              <button
                onClick={closeModal}
                className="px-6 py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-[#366870] transition-colors"
                disabled={updating}
              >
                Cancel
              </button>
              <button
                onClick={() => updateStatus(selected.id, selected.status)}
                disabled={updating}
                className="px-6 py-2.5 bg-[#366870] text-white rounded-lg hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
              >
                {updating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Updating...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Image Lightbox */}
      {imgOpen && imgSrc && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-4" onClick={()=>{setImgOpen(false); setImgSrc(null)}}>
          <div className="relative max-w-4xl w-full" onClick={(e)=>e.stopPropagation()}>
            <button
              className="absolute -top-10 right-0 text-white text-2xl"
              onClick={()=>{setImgOpen(false); setImgSrc(null)}}
              aria-label="Close"
            >
              ×
            </button>
            <img src={imgSrc} alt="Receipt" className="w-full h-auto rounded-lg shadow-2xl" />
          </div>
        </div>
      )}
    </div>
  )
}