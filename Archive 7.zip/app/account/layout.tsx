import Sidebar from '@/components/Sidebar'
import AccountGate from '@/components/AccountGate'

export default function AccountLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="container flex gap-20">
      <Sidebar />
      <div className="flex-1">
        <AccountGate>
          <div className="rounded-xl p-6 min-h-screen min-w-auto">
            {children}
          </div>
        </AccountGate>
      </div>
    </div>
  )
}
