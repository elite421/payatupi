"use client"

import { useState, FormEvent } from "react"

export default function ChangePasswordPage(){
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [err, setErr] = useState<string | null>(null)

  async function onSubmit(e: FormEvent<HTMLFormElement>){
    e.preventDefault()
    setSaving(true)
    setMsg(null)
    setErr(null)
    const fd = new FormData(e.currentTarget)
    const currentPassword = String(fd.get('currentPassword') || '')
    const newPassword = String(fd.get('newPassword') || '')
    const confirmPassword = String(fd.get('confirmPassword') || '')
    if (!currentPassword || !newPassword) { setErr('Both current and new password are required'); setSaving(false); return }
    if (newPassword.length < 6) { setErr('New password must be at least 6 characters'); setSaving(false); return }
    if (newPassword !== confirmPassword) { setErr('New password and confirm password do not match'); setSaving(false); return }
    try {
      const r = await fetch('/api/profile/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ currentPassword, newPassword }) })
      if (r.ok) {
        setMsg('Password changed successfully')
        ;(e.target as HTMLFormElement).reset()
      } else {
        const d = await r.json().catch(()=>({ error: 'Failed to change password' }))
        setErr(d.error || 'Failed to change password')
      }
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-md mx-auto py-10 px-4">
      <h1 className="text-2xl font-semibold">Change Password</h1>
      <p className="mt-2 text-slate-600">Update your account password securely.</p>

      <form onSubmit={onSubmit} className="mt-6 space-y-4">
        <div>
          <label className="block text-sm text-slate-700">Current Password</label>
          <input name="currentPassword" type="password" className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="block text-sm text-slate-700">New Password</label>
          <input name="newPassword" type="password" minLength={6} className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <div>
          <label className="block text-sm text-slate-700">Confirm New Password</label>
          <input name="confirmPassword" type="password" minLength={6} className="mt-1 w-full rounded-lg border px-3 py-2" required />
        </div>
        <button disabled={saving} className="rounded-lg bg-slate-900 px-4 py-2 text-white disabled:opacity-50">{saving ? 'Saving...' : 'Change Password'}</button>
        {(msg || err) && (
          <div className={`mt-2 text-sm ${msg ? 'text-green-700' : 'text-red-700'}`}>{msg || err}</div>
        )}
      </form>

      <div className="mt-6">
        <a href="/account/profile" className="text-sm text-slate-700 underline">Back to Profile</a>
      </div>
    </div>
  )
}
