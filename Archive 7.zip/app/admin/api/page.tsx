"use client"

import { useEffect, useState } from 'react'

type ApiKeyRow = {
  id: string
  prefix: string
  revoked: boolean
  createdAt: string
  lastUsedAt?: string | null
  user?: { id: string; name: string; email: string }
}

type ApiLogRow = {
  id: string
  endpoint: string
  method: string
  status: string
  code: number
  reason?: string | null
  createdAt: string
  user?: { id: string; name: string; email: string }
  apiKey?: { id: string; prefix: string }
}

export default function AdminApiPage(){
  const [keys, setKeys] = useState<ApiKeyRow[]>([])
  const [logs, setLogs] = useState<ApiLogRow[]>([])
  const [keysLoading, setKeysLoading] = useState(false)
  const [logsLoading, setLogsLoading] = useState(false)
  const [keyQ, setKeyQ] = useState('')
  const [revoked, setRevoked] = useState<'all'|'true'|'false'>('all')
  const [logQ, setLogQ] = useState('')
  const [status, setStatus] = useState<'all'|'OK'|'ERROR'>('all')
  const [code, setCode] = useState<string>('')
  const [endpoint, setEndpoint] = useState('')
  const [prefix, setPrefix] = useState('')
  const [userId, setUserId] = useState('')
  const [take, setTake] = useState<number>(100)
  const [msg, setMsg] = useState<string|null>(null)

  async function loadKeys(){
    setKeysLoading(true)
    const url = new URL('/api/admin/api-keys', window.location.origin)
    if (keyQ.trim()) url.searchParams.set('q', keyQ.trim())
    if (revoked !== 'all') url.searchParams.set('revoked', revoked)
    url.searchParams.set('take', String(take))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setKeysLoading(false)
    if (r.ok) setKeys(await r.json())
  }

  async function loadLogs(){
    setLogsLoading(true)
    const url = new URL('/api/admin/api-logs', window.location.origin)
    if (logQ.trim()) url.searchParams.set('q', logQ.trim())
    if (status !== 'all') url.searchParams.set('status', status)
    if (code.trim()) url.searchParams.set('code', code.trim())
    if (endpoint.trim()) url.searchParams.set('endpoint', endpoint.trim())
    if (prefix.trim()) url.searchParams.set('prefix', prefix.trim())
    if (userId.trim()) url.searchParams.set('userId', userId.trim())
    url.searchParams.set('take', String(take))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setLogsLoading(false)
    if (r.ok) setLogs(await r.json())
  }

  async function revokeKey(id: string){
    setMsg(null)
    const r = await fetch(`/api/admin/api-keys/${encodeURIComponent(id)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ revoke: true }) })
    if (r.ok) { setMsg('Key revoked'); await loadKeys() } else { setMsg('Failed to revoke key') }
  }

  useEffect(() => { 
    loadKeys()
    loadLogs()
  }, [])
  
  useEffect(() => { 
    const timer = setTimeout(() => loadKeys(), 300) // Debounce
    return () => clearTimeout(timer)
  }, [revoked, take])
  
  useEffect(() => { 
    const timer = setTimeout(() => loadLogs(), 300) // Debounce
    return () => clearTimeout(timer)
  }, [status, take])

  const okCount = logs.filter(l => l.status === 'OK').length
  const errCount = logs.filter(l => l.status !== 'OK').length

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">API Management</h1>
        <p className="text-slate-600 mt-1">View API keys and usage logs</p>
      </div>

      {msg && <div className="px-4 py-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-sm">{msg}</div>}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Keys */}
        <div className="xl:col-span-1 space-y-4">
          <div className="bg-white rounded-xl border p-4">
            <div className="text-lg font-semibold mb-3">API Keys</div>
            <div className="flex flex-col gap-3">
              <input value={keyQ} onChange={e=>setKeyQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') loadKeys()}} placeholder="Search by prefix/name/email" className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
              <div className="flex gap-2">
                <select value={revoked} onChange={e=>setRevoked(e.target.value as any)} className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3">
                  <option value="all">All</option>
                  <option value="false">Active</option>
                  <option value="true">Revoked</option>
                </select>
                <select value={String(take)} onChange={e=>setTake(parseInt(e.target.value)||100)} className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3">
                  <option value="50">50</option>
                  <option value="100">100</option>
                  <option value="200">200</option>
                </select>
                <button onClick={loadKeys} className="px-4 py-2 rounded-lg bg-blue-600 text-white">Refresh</button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    {['Created','Prefix','User','Status','Last Used','Action'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {keysLoading ? (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">Loading...</td></tr>
                  ) : keys.length === 0 ? (
                    <tr><td colSpan={6} className="px-4 py-8 text-center text-slate-500">No keys</td></tr>
                  ) : (
                    keys.map(k => (
                      <tr key={k.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 text-sm">{new Date(k.createdAt).toLocaleString()}</td>
                        <td className="px-4 py-3 text-sm font-mono">{k.prefix}</td>
                        <td className="px-4 py-3 text-sm">{k.user?.name || '—'}<div className="text-xs text-slate-500">{k.user?.email}</div></td>
                        <td className="px-4 py-3 text-sm">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${k.revoked ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'}`}>{k.revoked ? 'Revoked' : 'Active'}</span>
                        </td>
                        <td className="px-4 py-3 text-sm">{k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString() : '—'}</td>
                        <td className="px-4 py-3 text-sm">
                          {!k.revoked && (
                            <button onClick={()=>revokeKey(k.id)} className="px-2 py-1 text-xs rounded bg-rose-600 text-white">Revoke</button>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Logs */}
        <div className="xl:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border p-4">
            <div className="text-lg font-semibold mb-3">API Usage</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input value={logQ} onChange={e=>setLogQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter') loadLogs()}} placeholder="Search endpoint/name/email/reason" className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
              <div className="flex gap-2">
                <select value={status} onChange={e=>setStatus(e.target.value as any)} className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3">
                  <option value="all">All</option>
                  <option value="OK">OK</option>
                  <option value="ERROR">ERROR</option>
                </select>
                <input value={code} onChange={e=>setCode(e.target.value)} placeholder="HTTP code" className="w-28 rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
                <input value={endpoint} onChange={e=>setEndpoint(e.target.value)} placeholder="/api/..." className="flex-1 rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
              </div>
              <div className="flex gap-2">
                <input value={prefix} onChange={e=>setPrefix(e.target.value)} placeholder="Key prefix" className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
                <input value={userId} onChange={e=>setUserId(e.target.value)} placeholder="User ID" className="flex-1 rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3" />
                <select value={String(take)} onChange={e=>setTake(parseInt(e.target.value)||100)} className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3">
                  <option value="50">50</option>
                  <option value="100">100</option>
                  <option value="200">200</option>
                </select>
                <button onClick={loadLogs} className="px-4 py-2 rounded-lg bg-blue-600 text-white">Refresh</button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border overflow-hidden">
            <div className="p-4 grid grid-cols-2 gap-4 border-b bg-slate-50">
              <div className="text-sm">OK: <span className="font-semibold text-emerald-700">{okCount}</span></div>
              <div className="text-sm">Errors: <span className="font-semibold text-rose-700">{errCount}</span></div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b">
                  <tr>
                    {['Time','Code','Status','Endpoint','User','Key','Reason'].map(h => (
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {logsLoading ? (
                    <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">Loading...</td></tr>
                  ) : logs.length === 0 ? (
                    <tr><td colSpan={7} className="px-4 py-8 text-center text-slate-500">No logs</td></tr>
                  ) : (
                    logs.map(l => (
                      <tr key={l.id} className="hover:bg-slate-50">
                        <td className="px-4 py-3 text-sm">{new Date(l.createdAt).toLocaleString()}</td>
                        <td className="px-4 py-3 text-sm">{l.code}</td>
                        <td className="px-4 py-3 text-sm">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${l.status === 'OK' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>{l.status}</span>
                        </td>
                        <td className="px-4 py-3 text-sm font-mono">{l.method} {l.endpoint}</td>
                        <td className="px-4 py-3 text-sm">{l.user?.name || '—'}<div className="text-xs text-slate-500">{l.user?.email}</div></td>
                        <td className="px-4 py-3 text-sm font-mono">{l.apiKey?.prefix || '—'}</td>
                        <td className="px-4 py-3 text-sm">{l.reason || '—'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
