"use client"

import { useEffect, useState } from 'react'
import Link from 'next/link'

type Item = {
  id: string
  status: 'NOT_SUBMITTED'|'PENDING'|'APPROVED'|'REJECTED'
  proofType?: string | null
  documentUrl?: string | null
  selfieUrl?: string | null
  adminNote?: string | null
  updatedAt: string
  createdAt: string
  user: { id: string; name: string; email: string; phone?: string | null }
}

export default function AdminKycListPage(){
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(false)
  const [status, setStatus] = useState<string>('PENDING')
  const [q, setQ] = useState('')
  const [take, setTake] = useState<number>(100)
  const [msg, setMsg] = useState<string | null>(null)

  async function load(){
    setLoading(true)
    const url = new URL('/api/admin/kyc', window.location.origin)
    if (status && status !== 'all') url.searchParams.set('status', status)
    if (q.trim()) url.searchParams.set('q', q.trim())
    if (take) url.searchParams.set('take', String(take))
    const r = await fetch(url.toString(), { cache: 'no-store' })
    setLoading(false)
    if (r.ok) setItems(await r.json())
  }

  async function updateSubStatus(userId: string, newStatus: 'ACTIVE'|'CANCELED'|'PAST_DUE'){
    try {
      setMsg(null)
      const r = await fetch(`/api/admin/subscriptions/${encodeURIComponent(userId)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })
      if (r.ok) {
        setMsg('User subscription status updated')
        await load()
      } else {
        setMsg('Failed to update user subscription')
      }
    } catch {
      setMsg('Failed to update user subscription')
    }
  }

  useEffect(() => { 
    const timer = setTimeout(() => load(), 100) // Debounce
    return () => clearTimeout(timer)
  }, [])
  
  useEffect(() => { 
    const timer = setTimeout(() => load(), 300) // Debounce with longer delay for filters
    return () => clearTimeout(timer)
  }, [status, take])

  async function updateKyc(userId: string, newStatus: 'NOT_SUBMITTED'|'PENDING'|'APPROVED'|'REJECTED'){
    try {
      setMsg(null)
      const r = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/kyc`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      })
      if (r.ok) {
        setMsg('KYC updated')
        await load()
      } else {
        setMsg('Failed to update KYC')
      }
    } catch {
      setMsg('Failed to update KYC')
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">KYC Submissions</h1>
        <p className="text-slate-600 mt-1">Review and update KYC statuses</p>
      </div>

      {msg && (
        <div className="px-4 py-2 rounded-lg bg-blue-50 border border-blue-200 text-blue-700 text-sm">{msg}</div>
      )}

      <div className="bg-white rounded-xl border p-4">
        <div className="flex flex-col md:flex-row gap-3">
          <input
            value={q}
            onChange={e => setQ(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') load() }}
            placeholder="Search by name, email, or phone"
            className="flex-1 rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3"
          />
          <select
            value={status}
            onChange={e => setStatus(e.target.value)}
            className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3"
          >
            <option value="all">All</option>
            <option value="PENDING">PENDING</option>
            <option value="APPROVED">APPROVED</option>
            <option value="REJECTED">REJECTED</option>
            <option value="NOT_SUBMITTED">NOT_SUBMITTED</option>
          </select>
          <select
            value={String(take)}
            onChange={e => setTake(parseInt(e.target.value) || 100)}
            className="rounded-lg border-slate-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 py-2 px-3"
          >
            <option value="50">50</option>
            <option value="100">100</option>
            <option value="200">200</option>
          </select>
          <button onClick={load} className="px-4 py-2 rounded-lg bg-blue-600 text-white">Refresh</button>
        </div>
      </div>

      <div className="bg-white rounded-xl border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b">
              <tr>
                {['Updated', 'User', 'Email', 'Phone', 'Status', 'Docs', 'Action'].map(h => (
                  <th key={h} className="px-6 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y">
              {loading ? (
                <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-500">Loading...</td></tr>
              ) : items.length === 0 ? (
                <tr><td colSpan={7} className="px-6 py-12 text-center text-slate-500">No submissions</td></tr>
              ) : (
                items.map(it => (
                  <tr key={it.id} className="hover:bg-slate-50">
                    <td className="px-6 py-3 text-sm">{new Date(it.updatedAt).toLocaleString()}</td>
                    <td className="px-6 py-3 text-sm font-medium">{it.user?.name || '—'}</td>
                    <td className="px-6 py-3 text-sm">{it.user?.email || '—'}</td>
                    <td className="px-6 py-3 text-sm">{it.user?.phone || '—'}</td>
                    <td className="px-6 py-3 text-sm">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-800">{it.status}</span>
                    </td>
                    <td className="px-6 py-3 text-sm">
                      <div className="flex gap-2">
                        {it.documentUrl && <a className="text-blue-600 hover:underline" href={it.documentUrl} target="_blank" rel="noreferrer">ID</a>}
                        {it.selfieUrl && <a className="text-blue-600 hover:underline" href={it.selfieUrl} target="_blank" rel="noreferrer">Selfie</a>}
                      </div>
                    </td>
                    <td className="px-6 py-3 text-sm space-y-1">
                      <div className="flex flex-wrap gap-2 items-center">
                        <Link href={`/admin/kyc/${encodeURIComponent(it.user.id)}`} className="text-blue-600 hover:underline">Review</Link>
                        <button onClick={() => updateKyc(it.user.id, 'APPROVED')} className="px-2 py-1 text-xs rounded bg-emerald-600 text-white">Approve</button>
                        <button onClick={() => updateKyc(it.user.id, 'REJECTED')} className="px-2 py-1 text-xs rounded bg-rose-600 text-white">Reject</button>
                        <button onClick={() => updateKyc(it.user.id, 'PENDING')} className="px-2 py-1 text-xs rounded bg-amber-600 text-white">Pending</button>
                      </div>
                      <div className="flex flex-wrap gap-2 items-center">
                        <span className="text-xs text-slate-500 mr-1">User status:</span>
                        <button onClick={() => updateSubStatus(it.user.id, 'ACTIVE')} className="px-2 py-1 text-xs rounded bg-slate-800 text-white">Set Active</button>
                        <button onClick={() => updateSubStatus(it.user.id, 'CANCELED')} className="px-2 py-1 text-xs rounded bg-slate-200 text-slate-800">Cancel</button>
                        <button onClick={() => updateSubStatus(it.user.id, 'PAST_DUE')} className="px-2 py-1 text-xs rounded bg-amber-100 text-amber-800">Past Due</button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
