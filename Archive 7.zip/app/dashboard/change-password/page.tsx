"use client"

import { useState, FormEvent } from "react"
import { useSession } from "next-auth/react"
import Head from "next/head"
import { useEffect } from "react"
import Navbar from "@/components/Navbaar"

export default function ChangePasswordPage(){
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState<string | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [mounted, setMounted] = useState(false)
  const { data: session } = useSession()

  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(id)
  }, [])

  async function onSubmit(e: FormEvent<HTMLFormElement>){
    e.preventDefault()
    setSaving(true)
    setMsg(null)
    setErr(null)
    const fd = new FormData(e.currentTarget)
    const currentPassword = String(fd.get('currentPassword') || '')
    const newPassword = String(fd.get('newPassword') || '')
    const confirmPassword = String(fd.get('confirmPassword') || '')
    if (!currentPassword || !newPassword) { setErr('Both current and new password are required'); setSaving(false); return }
    if (newPassword.length < 6) { setErr('New password must be at least 6 characters'); setSaving(false); return }
    if (newPassword !== confirmPassword) { setErr('New password and confirm password do not match'); setSaving(false); return }
    try {
      const r = await fetch('/api/profile/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ currentPassword, newPassword }) })
      if (r.ok) {
        setMsg('Password changed successfully')
        ;(e.target as HTMLFormElement).reset()
      } else {
        const d = await r.json().catch(()=>({ error: 'Failed to change password' }))
        setErr(d.error || 'Failed to change password')
      }
    } finally {
      setSaving(false)
    }
  }

  const displayName = (session?.user?.name || 'User').trim()

  return (
    <>
      <Head>
        <title>Change Password - Payatupi</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
      </Head>
      <Navbar/>

      <div className={`min-h-screen bg-gradient-to-br from-[#f5f7fa] to-[#e4edf5] font-sans transition-opacity duration-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
        <main className="max-w-7xl mx-auto px-6 py-8">
          <section className="mb-8">
            <div className="welcome-section mb-6">
              <div className="text-xl font-extrabold animate-[fadeGlow_3s_ease_infinite]" style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Welcome, {displayName}
              </div>
              <h4 className="text-gray-600 mt-1 font-medium">Change Password</h4>
            </div>

            <div className="max-w-md">
              <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4" style={{ borderTopColor: "#50bd49" }}>
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-gray-800">Change Password</h1>
                  <p className="mt-2 text-gray-600">Update your account password securely.</p>
                </div>

                <form onSubmit={onSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-gray-700">Current Password</label>
                    <input 
                      name="currentPassword" 
                      type="password" 
                      className="w-full rounded-xl border-2 border-gray-200 px-4 py-3 focus:border-[#50bd49] focus:ring-2 focus:ring-[#50bd49]/20 transition-all duration-200" 
                      required 
                      placeholder="Enter current password"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-gray-700">New Password</label>
                    <input 
                      name="newPassword" 
                      type="password" 
                      minLength={6} 
                      className="w-full rounded-xl border-2 border-gray-200 px-4 py-3 focus:border-[#50bd49] focus:ring-2 focus:ring-[#50bd49]/20 transition-all duration-200" 
                      required 
                      placeholder="Enter new password (min. 6 characters)"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="block text-sm font-semibold text-gray-700">Confirm New Password</label>
                    <input 
                      name="confirmPassword" 
                      type="password" 
                      minLength={6} 
                      className="w-full rounded-xl border-2 border-gray-200 px-4 py-3 focus:border-[#50bd49] focus:ring-2 focus:ring-[#50bd49]/20 transition-all duration-200" 
                      required 
                      placeholder="Confirm new password"
                    />
                  </div>

                  <button 
                    disabled={saving} 
                    className="group relative w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full font-medium text-white overflow-hidden transition-transform hover:-translate-y-0.5 disabled:translate-y-0 disabled:opacity-50"
                    style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)" }}
                  >
                    <i className={`fas ${saving ? 'fa-spinner animate-spin' : 'fa-key'}`}></i>
                    <span className="relative z-10">{saving ? 'Changing Password...' : 'Change Password'}</span>
                    <span className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </button>

                  {(msg || err) && (
                    <div className={`p-4 rounded-xl text-sm font-medium ${msg ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                      <div className="flex items-center gap-2">
                        <i className={`fas ${msg ? 'fa-check-circle' : 'fa-exclamation-triangle'}`}></i>
                        {msg || err}
                      </div>
                    </div>
                  )}
                </form>

                <div className="mt-6 pt-6 border-t border-gray-200">
                  <a 
                    href="/dashboard/profile" 
                    className="group inline-flex items-center gap-2 text-gray-600 hover:text-[#50bd49] transition-colors duration-200"
                  >
                    <i className="fas fa-arrow-left"></i>
                    Back to Profile
                  </a>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      <style jsx global>{`
        @keyframes fadeGlow {
          0% { filter: brightness(1); }
          50% { filter: brightness(1.15); }
          100% { filter: brightness(1); }
        }
      `}</style>
    </>
  )
}