"use client"

import { Activity, useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import Head from "next/head"
import Navbar from "@/components/Navbaar"

type Activity = {
  id: string
  type: string
  message?: string | null
  metadata?: any
  createdAt: string
}

export default function ActivityPage(){
  const [items, setItems] = useState<Activity[]>([])
  const [loading, setLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const { data: session } = useSession()

  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true))
    return () => cancelAnimationFrame(id)
  }, [])

  useEffect(() => {
    let active = true
    ;(async () => {
      try {
        const r = await fetch('/api/activity?take=50', { cache: 'no-store' })
        if (r.ok) {
          const d = await r.json()
          if (active) setItems(d.items || d)
        }
      } finally {
        if (active) setLoading(false)
      }
    })()
    return () => { active = false }
  }, [])

  const displayName = (session?.user?.name || 'User').trim()

  function formatActivityType(type: string) {
    return type.split(/(?=[A-Z])/).join(' ').replace(/\b\w/g, l => l.toUpperCase())
  }

  function getActivityIcon(type: string) {
    if (type.toLowerCase().includes('login')) return 'fa-sign-in-alt'
    if (type.toLowerCase().includes('logout')) return 'fa-sign-out-alt'
    if (type.toLowerCase().includes('password')) return 'fa-key'
    if (type.toLowerCase().includes('profile')) return 'fa-user'
    if (type.toLowerCase().includes('create')) return 'fa-plus-circle'
    if (type.toLowerCase().includes('update')) return 'fa-edit'
    return 'fa-history'
  }

  function getActivityColor(type: string) {
    if (type.toLowerCase().includes('login')) return 'from-green-500 to-green-600'
    if (type.toLowerCase().includes('logout')) return 'from-gray-500 to-gray-600'
    if (type.toLowerCase().includes('password')) return 'from-blue-500 to-blue-600'
    if (type.toLowerCase().includes('profile')) return 'from-purple-500 to-purple-600'
    return 'from-[#3193f7] to-[#50bd4b]'
  }

  return (
    <>
      <Head>
        <title>Login Activity - Payatupi</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="icon" href="/favicon.ico" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet" />
      </Head>
      <Navbar/>
      <div className={`min-h-screen bg-gradient-to-br from-[#f5f7fa] to-[#e4edf5] font-sans transition-opacity duration-500 ${mounted ? 'opacity-100' : 'opacity-0'}`}>
        <main className="max-w-7xl mx-auto px-6 py-8">
          <section className="mb-8">
            <div className="welcome-section mb-6">
              <div className="text-xl font-extrabold animate-[fadeGlow_3s_ease_infinite]" style={{ background: "linear-gradient(90deg,#3193f7,#50bd4b)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Welcome, {displayName}
              </div>
              <h4 className="text-gray-600 mt-1 font-medium">Login Activity</h4>
            </div>

            <div className="max-w-4xl">
              <div className="bg-white rounded-2xl shadow-lg p-8 border-t-4" style={{ borderTopColor: "#50bd49" }}>
                <div className="mb-6">
                  <h1 className="text-2xl font-bold text-gray-800">Login Activity</h1>
                  <p className="mt-2 text-gray-600">Recent actions recorded for your account.</p>
                </div>

                {loading ? (
                  <div className="flex justify-center items-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#50bd49]"></div>
                  </div>
                ) : items.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                      <i className="fas fa-history text-gray-400 text-2xl"></i>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-600">No activity yet</h3>
                    <p className="text-gray-500 mt-1">Your account activity will appear here</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {items.map((a) => (
                      <div key={a.id} className="rounded-xl border border-gray-200 bg-white p-6 hover:shadow-md transition-shadow duration-200">
                        <div className="flex items-start gap-4">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white bg-gradient-to-br ${getActivityColor(a.type)} flex-shrink-0`}>
                            <i className={`fas ${getActivityIcon(a.type)}`}></i>
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h3 className="font-bold text-gray-800 text-lg">{formatActivityType(a.type)}</h3>
                              <div className="text-sm text-gray-500 bg-gray-50 px-3 py-1 rounded-full">
                                {new Date(a.createdAt).toLocaleString()}
                              </div>
                            </div>
                            
                            {a.message && (
                              <p className="mt-2 text-gray-600">{a.message}</p>
                            )}
                            
                            {a.metadata && (
                              <div className="mt-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                                <details className="cursor-pointer">
                                  <summary className="text-sm font-medium text-gray-700">View Details</summary>
                                  <pre className="mt-2 whitespace-pre-wrap break-words text-xs text-gray-600 bg-white p-3 rounded border">
                                    {JSON.stringify(a.metadata, null, 2)}
                                  </pre>
                                </details>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </section>
        </main>
      </div>

      <style jsx global>{`
        @keyframes fadeGlow {
          0% { filter: brightness(1); }
          50% { filter: brightness(1.15); }
          100% { filter: brightness(1); }
        }
      `}</style>
    </>
  )
}