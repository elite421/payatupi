const lowMem = process.env.LOW_MEM_BUILD === '1'

const nextConfig = {
  output: 'standalone',
  compress: true,
  poweredByHeader: false,
  reactStrictMode: process.env.NODE_ENV === 'production',
  swcMinify: !lowMem,
  experimental: {
    optimizeCss: !lowMem,
  },
  compiler: {
    removeConsole: process.env.NODE_ENV === 'production' ? {
      exclude: ['error', 'warn'],
    } : false,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    formats: ['image/avif', 'image/webp'],
    minimumCacheTTL: 60,
  },
  headers: async () => {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
        ],
      },
    ]
  },
  turbopack: {
    root: __dirname,
  },
  webpack: (config: any, { dev }: any) => {
    if (dev) {
      config.watchOptions = config.watchOptions || {}
      const extraIgnores = [
        '**/meesage reading apk/**',
        '**/*.zip',
        '**/*.apk',
        '**/versions/**',
      ]
      const ignored = (config.watchOptions as any).ignored
      if (Array.isArray(ignored)) {
        ;(config.watchOptions as any).ignored = [...ignored, ...extraIgnores]
      } else if (ignored) {
        ;(config.watchOptions as any).ignored = [ignored, ...extraIgnores]
      } else {
        ;(config.watchOptions as any).ignored = extraIgnores
      }
    }
    return config
  },
};

export default nextConfig;
