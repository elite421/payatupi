"use client"

import { useState, ChangeEvent, useEffect, useRef } from 'react'
import Image from "next/image"

export default function UpiModal({
  paymentId,
  displayName,
  upiId,
  amount,
  linkIdOrSlug,
  buyerName,
  buyerPhone,
  buyerEmail,
  purpose,
  adImageUrl,
  adLink,
  redirectUrl,
  themeColor,
}: {
  paymentId: string
  displayName: string
  upiId: string
  amount: number
  linkIdOrSlug: string
  buyerName?: string
  buyerPhone?: string
  buyerEmail?: string
  purpose?: string
  adImageUrl?: string | null
  adLink?: string | null
  redirectUrl?: string | null
  themeColor?: string
}) {
  const [utr, setUtr] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [errors, setErrors] = useState({ utr: '', file: '' })
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [mode, setMode] = useState<'upi' | 'bank'>('upi')
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Handle URL hash changes
  useEffect(() => {
    const updateModalState = () => {
      try {
        if (typeof window !== 'undefined') {
          const hash = window.location.hash || ''
          const isUpi = hash === '#upi-modal' || hash === '#upi-modal-upi'
          const isBank = hash === '#upi-modal-bank'
          
          setIsOpen(isUpi || isBank)
          setMode(isBank ? 'bank' : 'upi')
        } else {
          setIsOpen(false)
        }
      } catch {
        setIsOpen(false)
      }
    }

    const handleHashChange = () => updateModalState()
    
    // Initial check
    updateModalState()

    // Add event listener
    if (typeof window !== 'undefined') {
      window.addEventListener('hashchange', handleHashChange)
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('hashchange', handleHashChange)
      }
    }
  }, [])

  // Handle file selection with preview
  function onFileChange(e: ChangeEvent<HTMLInputElement>) {
    const selectedFile = e.target.files?.[0] || null
    setFile(selectedFile)
    setErrors(prev => ({ ...prev, file: '' }))
    setMessage(null)

    // Create preview URL
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
    }
    
    if (selectedFile) {
      const url = URL.createObjectURL(selectedFile)
      setPreviewUrl(url)
    } else {
      setPreviewUrl(null)
    }
  }

  // Remove selected file
  function removeFile() {
    setFile(null)
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl)
      setPreviewUrl(null)
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  // Validate UTR number
  function validateUtr(utrNumber: string): boolean {
    const trimmedUtr = utrNumber.trim()
    // UTR is typically 12-16 digits, but can vary by bank
    return trimmedUtr.length >= 6
  }

  // Validate file
  function validateFile(selectedFile: File | null): boolean {
    // Optional: if no file provided, it's valid
    if (!selectedFile) {
      return true
    }
    
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif']
    const maxSize = 5 * 1024 * 1024 // 5MB
    
    if (!validTypes.includes(selectedFile.type)) {
      setErrors(prev => ({ ...prev, file: 'Please upload a valid image (JPEG, PNG, WebP, GIF)' }))
      return false
    }
    
    if (selectedFile.size > maxSize) {
      setErrors(prev => ({ ...prev, file: 'Image size should be less than 5MB' }))
      return false
    }
    
    return true
  }

  // Handle form submission
  async function onConfirm() {
    // Reset states
    setErrors({ utr: '', file: '' })
    setMessage(null)

    // Validate UTR
    if (!validateUtr(utr)) {
      setErrors(prev => ({ ...prev, utr: 'Please enter a valid UTR number (minimum 6 digits)' }))
      return
    }

    // Validate screenshot only if provided (optional)
    if (file && !validateFile(file)) return

    setSubmitting(true)

    try {
      const formData = new FormData()
      formData.append('link', linkIdOrSlug)
      formData.append('amount', String(amount))
      formData.append('buyerName', buyerName || '')
      if ((buyerPhone || '').trim()) formData.append('buyerPhone', String(buyerPhone))
      if ((buyerEmail || '').trim()) formData.append('buyerEmail', String(buyerEmail))
      formData.append('paymentId', paymentId)
      formData.append('payMode', mode)
      formData.append('utr', utr.trim())
      if ((purpose || '').trim()) {
        formData.append('purpose', (purpose as string).trim())
      }
      
      if (file) {
        formData.append('screenshot', file)
      }

      const response = await fetch('/api/payments/confirm', {
        method: 'POST',
        body: formData,
      })

      if (response.ok) {
        const data = await response.json().catch(() => ({}))
        
        // Handle redirect
        const rawRedirectUrl = data.redirectUrl || redirectUrl
        let targetUrl = typeof rawRedirectUrl === 'string' ? rawRedirectUrl.trim() : ''
        
        if (targetUrl) {
          // Ensure URL has proper scheme
          const hasScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(targetUrl)
          if (!hasScheme) {
            if (targetUrl.startsWith('//')) {
              targetUrl = 'https:' + targetUrl
            } else if (/^[\w.-]+\.[A-Za-z]{2,}(:\d+)?(\/.*)?$/.test(targetUrl)) {
              targetUrl = 'https://' + targetUrl
            }
          }
          
          if (/^https?:\/\//i.test(targetUrl)) {
            try {
              if (typeof window !== 'undefined' && window.sessionStorage) {
                window.sessionStorage.setItem(`payatupi:redirect:${paymentId}`, targetUrl)
              }
            } catch {}
            if (typeof window !== 'undefined') {
              window.location.href = `/bill/${encodeURIComponent(paymentId)}`
              return
            }
          }
        }
        // No redirect URL or non-http(s): show in-app receipt page
        if (typeof window !== 'undefined') {
          window.location.href = `/bill/${encodeURIComponent(paymentId)}`
          return
        }
      } else {
        const errorData = await response.json().catch(() => ({ error: 'Submission failed' }))
        setMessage({ text: errorData.error || 'Failed to submit payment details', type: 'error' })
      }
    } catch (error) {
      console.error('Submission error:', error)
      setMessage({ text: 'Network error. Please try again.', type: 'error' })
    } finally {
      setSubmitting(false)
    }
  }

  // Close modal
  function closeModal() {
    setIsOpen(false)
    if (typeof window !== 'undefined') {
      window.location.hash = ''
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b text-white" style={{ backgroundColor: (themeColor || '#366870'), borderColor: (themeColor || '#366870') }}>
          <div>
            <h2 className="text-xl font-semibold text-white">
              {mode === 'bank' ? 'Bank Transfer Details' : 'UPI Payment Details'}
            </h2>
            <p className="text-sm text-white/80 mt-1">
              Confirm your payment by providing transaction details
            </p>
          </div>
          <button
            onClick={closeModal}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            disabled={submitting}
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Payment Information */}
        <div className="p-6 space-y-4">

          {/* Instructions */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <div className="flex items-start space-x-2">
              <svg className="w-5 h-5 text-gray-600 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <p className="text-sm text-gray-700">
                  Please complete the payment and submit the 12-digit UTR number. Uploading a screenshot is optional but can speed up verification. We'll confirm your payment after validation.
                </p>
              </div>
            </div>
          </div>

          {/* Hidden Fields */}
          <input type="hidden" id="pay_mode" value={mode} />
          <input type="hidden" id="payment_id" value={paymentId} />

          {/* UTR Input */}
          <div>
            <label htmlFor="utr_upi" className="block text-sm font-medium text-gray-700 mb-2">
              UTR Number <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="utr_upi"
              className={`w-full rounded-lg border px-4 py-3 focus:ring-2 focus:border-blue-500 ${
                errors.utr ? 'border-red-300 focus:ring-red-500' : 'border-gray-300 focus:ring-blue-500'
              }`}
              placeholder="Enter 12-digit UTR number"
              autoComplete="off"
              value={utr}
              onChange={(e) => {
                setUtr(e.target.value)
                if (errors.utr) setErrors(prev => ({ ...prev, utr: '' }))
                setMessage(null)
              }}
              disabled={submitting}
            />
            {errors.utr && (
              <p className="mt-1 text-sm text-red-600 flex items-center">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                {errors.utr}
              </p>
            )}
          </div>

          {/* Screenshot Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Payment Screenshot (optional)
            </label>
            
            {!file ? (
              <div className="flex items-center justify-center w-full">
                <label
                  htmlFor="screenshot_upi"
                  className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
                    errors.file 
                      ? 'border-red-300 bg-red-50 hover:bg-red-100' 
                      : 'border-gray-300 bg-gray-50 hover:bg-gray-100'
                  } ${submitting ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <svg className="w-8 h-8 mb-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p className="mb-1 text-sm text-gray-500">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                    <p className="text-xs text-gray-500">PNG, JPG, GIF (MAX. 5MB)</p>
                  </div>
                  <input
                    ref={fileInputRef}
                    id="screenshot_upi"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={onFileChange}
                    disabled={submitting}
                  />
                </label>
              </div>
            ) : (
              <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-gray-700">Selected file</span>
                  <button
                    type="button"
                    onClick={removeFile}
                    className="text-red-600 hover:text-red-700 text-sm font-medium"
                    disabled={submitting}
                  >
                    Remove
                  </button>
                </div>
                {previewUrl && (
                  <div className="mb-3">
                    <img
                      src={previewUrl}
                      alt="Screenshot preview"
                      className="max-h-40 rounded-lg border border-gray-300 mx-auto"
                    />
                  </div>
                )}
                <p className="text-sm text-gray-600 break-all">{file.name}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {(file.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            )}
            
            {errors.file && (
              <p className="mt-1 text-sm text-red-600 flex items-center">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                {errors.file}
              </p>
            )}
          </div>

          {/* Status Message */}
          {message && (
            <div className={`p-3 rounded-lg border ${
              message.type === 'success' 
                ? 'bg-green-50 border-green-200 text-green-700'
                : 'bg-red-50 border-red-200 text-red-700'
            }`}>
              <div className="flex items-center">
                <svg className={`w-4 h-4 mr-2 ${
                  message.type === 'success' ? 'text-green-600' : 'text-red-600'
                }`} fill="currentColor" viewBox="0 0 20 20">
                  {message.type === 'success' ? (
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  ) : (
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  )}
                </svg>
                {message.text}
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex space-x-3 p-6 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
          <button
            onClick={closeModal}
            className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 transition-colors font-medium"
            disabled={submitting}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={submitting || !utr.trim()}
            className="flex-1 px-4 py-3 bg-[#366870] text-white rounded-lg hover:bg-[#2f5b62] focus:ring-2 focus:ring-[#366870] disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium flex items-center justify-center"
          >
            {submitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Submitting...
              </>
            ) : (
              'Confirm Payment'
            )}
          </button>
        </div>

        {/* Advertisement */}
        {adImageUrl && (
          <div className="p-4 border-t border-gray-200">
            <div className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-2">Sponsored</div>
            {adLink ? (
              <a href={adLink} target="_blank" rel="noopener noreferrer" className="block">
                <img 
                  src={adImageUrl} 
                  alt="Advertisement" 
                  className="w-full h-auto rounded-lg border border-gray-200 hover:opacity-90 transition-opacity"
                />
              </a>
            ) : (
              <img 
                src={adImageUrl} 
                alt="Advertisement" 
                className="w-full h-auto rounded-lg border border-gray-200"
              />
            )}
          </div>
        )}
      </div>
      <div className="fixed bottom-3 right-3 text-xs">
        <span className="rounded-full bg-slate-900/90 text-white px-3 py-1 shadow-lg">
          powered by <span className="font-semibold">Payatupi</span>
        </span>
      </div>
    </div>
  )
}