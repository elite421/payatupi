"use client"

import { PropsWithChildren, useEffect, useState } from 'react'

export default function HideDuringUtr({ children }: PropsWithChildren) {
  const [hide, setHide] = useState(false)
  useEffect(() => {
    const check = () => {
      try {
        const h = typeof window !== 'undefined' ? (window.location.hash || '') : ''
        setHide(h === '#upi-modal-upi' || h === '#upi-modal-bank' || h === '#upi-modal')
      } catch { setHide(false) }
    }
    check()
    const onHash = () => check()
    if (typeof window !== 'undefined') window.addEventListener('hashchange', onHash)
    return () => { if (typeof window !== 'undefined') window.removeEventListener('hashchange', onHash) }
  }, [])
  return <div className={hide ? 'hidden' : ''}>{children}</div>
}
