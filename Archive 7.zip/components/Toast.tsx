"use client"

import { createContext, useCallback, useContext, useMemo, useState } from 'react'

type ToastItem = {
  id: number
  title?: string
  description?: string
  variant?: 'info' | 'success' | 'warning' | 'error'
  actionText?: string
  onAction?: () => void
  durationMs?: number
}

const ToastContext = createContext<{ show: (t: Omit<ToastItem, 'id'>) => void } | null>(null)

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([])

  const show = useCallback((t: Omit<ToastItem, 'id'>) => {
    const id = Date.now() + Math.floor(Math.random() * 1000)
    const item: ToastItem = { id, durationMs: 5000, variant: 'info', ...t }
    setItems((prev) => [...prev, item])
    const ms = item.durationMs || 5000
    if (ms > 0) {
      setTimeout(() => {
        setItems((prev) => prev.filter((x) => x.id !== id))
      }, ms)
    }
  }, [])

  const ctx = useMemo(() => ({ show }), [show])

  return (
    <ToastContext.Provider value={ctx}>
      {children}
      <div className="fixed right-4 top-4 z-[1000] space-y-2">
        {items.map((t) => (
          <div
            key={t.id}
            className={`min-w-[260px] max-w-sm rounded-lg border p-3 shadow-md text-sm bg-white ${
              t.variant === 'success' ? 'border-green-200' : t.variant === 'warning' ? 'border-yellow-200' : t.variant === 'error' ? 'border-red-200' : 'border-gray-200'
            }`}
          >
            {t.title && <div className="font-medium mb-0.5">{t.title}</div>}
            {t.description && <div className="text-slate-700">{t.description}</div>}
            {t.actionText && (
              <div className="mt-2">
                <button
                  onClick={() => {
                    if (t.onAction) t.onAction()
                    setItems((prev) => prev.filter((x) => x.id !== t.id))
                  }}
                  className="rounded-md bg-slate-900 text-white px-3 py-1 text-xs"
                >
                  {t.actionText}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast() {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast must be used within ToastProvider')
  return ctx
}
