"use client"

import { useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useToast } from '@/components/Toast'

export default function LoginToastOnce(){
  const { data: session, status } = useSession()
  const { show } = useToast()

  useEffect(() => {
    if (status !== 'authenticated') return
    const uid = (session?.user as any)?.id || 'anon'
    const key = `pt_login_toast_shown_${uid}`
    if (typeof window === 'undefined') return
    if (localStorage.getItem(key)) return
    localStorage.setItem(key, '1')
    show({
      title: 'Welcome back!',
      description: 'Check Developer page for your Account ID and Secret Key. See API docs in Help > API.',
      variant: 'info',
      durationMs: 6000,
    })
  }, [status, session, show])

  return null
}
