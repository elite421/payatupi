"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import RefreshButton from "./RefreshButton"

export default function AutoRefreshBill({
  createdAt,
  status,
  intervalMs = 5000,
}: {
  createdAt: string
  status: "Pending" | "Success" | "Failed"
  intervalMs?: number
}) {
  const router = useRouter()
  const createdMs = useMemo(() => {
    try { return new Date(createdAt).getTime() } catch { return Date.now() }
  }, [createdAt])
  const settings = useMemo(() => {
    if (typeof window === 'undefined') return { enabled: true, intervalMs, windowMinutes: 8 }
    try {
      const en = localStorage.getItem('payatupi:autoRefresh:enabled')
      const i = localStorage.getItem('payatupi:autoRefresh:intervalMs')
      const w = localStorage.getItem('payatupi:autoRefresh:windowMinutes')
      const enabled = en == null ? true : en === '1'
      const iMs = Math.max(2500, Math.min(15000, Number(i) || intervalMs))
      const wMin = Math.max(5, Math.min(30, Number(w) || 8))
      return { enabled, intervalMs: iMs, windowMinutes: wMin }
    } catch {
      return { enabled: true, intervalMs, windowMinutes: 8 }
    }
  }, [intervalMs])
  const deadline = createdMs + (settings.windowMinutes * 60 * 1000)
  const [now, setNow] = useState<number>(() => Date.now())
  const [tick, setTick] = useState(0)
  const refreshTimer = useRef<ReturnType<typeof setInterval> | null>(null)
  const clockTimer = useRef<ReturnType<typeof setInterval> | null>(null)

  const remaining = Math.max(0, deadline - now)
  const expired = remaining <= 0
  const pending = status === "Pending"

  useEffect(() => {
    // 1s clock tick for countdown display
    if (clockTimer.current) {
      clearInterval(clockTimer.current as any)
      clockTimer.current = null
    }
    if (pending && !expired) {
      clockTimer.current = setInterval(() => {
        setNow(Date.now())
      }, 1000) as any
    }
    return () => {
      if (clockTimer.current) {
        clearInterval(clockTimer.current as any)
        clockTimer.current = null
      }
    }
  }, [pending, expired])

  useEffect(() => {
    if (!pending || expired || !settings.enabled) {
      if (refreshTimer.current) {
        clearInterval(refreshTimer.current as any)
        refreshTimer.current = null
      }
      return
    }
    // Auto-refresh every few seconds while pending and within 8 minutes
    if (refreshTimer.current) {
      clearInterval(refreshTimer.current as any)
      refreshTimer.current = null
    }
    const interval = Math.max(5000, settings.intervalMs) // Increased minimum to 5s to reduce load
    refreshTimer.current = setInterval(() => {
      try { 
        router.refresh() 
        setTick(t => t + 1)
      } catch {}
    }, interval) as any
    return () => {
      if (refreshTimer.current) {
        clearInterval(refreshTimer.current as any)
        refreshTimer.current = null
      }
    }
  }, [pending, expired, settings.enabled, settings.intervalMs, router])

  const mm = Math.floor(remaining / 60000)
  const ss = Math.floor((remaining % 60000) / 1000)
  const pad = (n: number) => String(n).padStart(2, "0")

  if (!pending) {
    return <RefreshButton />
  }

  if (expired || !settings.enabled) {
    return <RefreshButton />
  }

  return (
    <div className="flex items-center gap-2 text-white">
      <div className="flex items-center rounded-lg border border-white/30 bg-white/0 px-2 py-1 text-xs">
        <svg className="w-4 h-4 mr-1 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M4 4v6h6M20 20v-6h-6"/></svg>
        Auto-refreshing {pad(mm)}:{pad(ss)}
      </div>
    </div>
  )
}
