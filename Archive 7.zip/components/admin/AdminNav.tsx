"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const items = [
  { href: '/account', label: 'Home' },
  { href: '/admin/dashboard', label: 'Dashboard' },
  { href: '/admin/users', label: 'Users' },
  { href: '/admin/manage', label: 'Manage' },
  { href: '/admin/kyc', label: 'KYC' },
  { href: '/admin/api', label: 'API' },
  { href: '/admin/callbacks', label: 'Callbacks' },
  { href: '/admin/transactions', label: 'Transactions' },
  { href: '/admin/wallet', label: 'Wallet' },
  { href: '/admin/support', label: 'Support' },
]

export default function AdminNav(){
  const pathname = usePathname()
  return (
    <nav className="bg-white border rounded-xl p-2 sm:p-3 flex flex-wrap gap-2">
      {items.map((it) => {
        const active = pathname?.startsWith(it.href)
        return (
          <Link
            key={it.href}
            href={it.href}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              active ? 'bg-[#366870] text-white shadow-sm' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
            }`}
          >
            {it.label}
          </Link>
        )
      })}
    </nav>
  )
}
