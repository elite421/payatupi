"use client";

import React, { useEffect, useRef, useState } from "react";
import { useSession, signOut } from 'next-auth/react'
import Image from "next/image";

function useClickOutside<T extends HTMLElement>(handler: () => void) {
    const ref = useRef<T | null>(null);
    useEffect(() => {
        function onDoc(e: MouseEvent) {
            if (!ref.current) return;
            if (!ref.current.contains(e.target as Node)) handler();
        }
        document.addEventListener("mousedown", onDoc);
        return () => document.removeEventListener("mousedown", onDoc);
    }, [handler]);
    return ref;
}

const Navbar: React.FC = () => {
    const [openUser, setOpenUser] = useState(false);
    const [openNotif, setOpenNotif] = useState(false);
    const [ready, setReady] = useState(false);
    const [badgeBounce, setBadgeBounce] = useState(true);
    const userRef = useClickOutside<HTMLDivElement>(() => setOpenUser(false));
    const notifRef = useClickOutside<HTMLDivElement>(() => setOpenNotif(false));
    const { data: session, status } = useSession();
    const [profile, setProfile] = useState<{ id: string; name: string; email: string } | null>(null)

    // small helper for keyboard accessibility
    useEffect(() => {
        function onKey(e: KeyboardEvent) {
            if (e.key === "Escape") {
                setOpenUser(false);
                setOpenNotif(false);
            }
        }
        document.addEventListener("keydown", onKey);
        return () => document.removeEventListener("keydown", onKey);
    }, []);

    // mount animations: navbar drop-in & badge bounce
    useEffect(() => {
        const id = requestAnimationFrame(() => setReady(true));
        const t = setTimeout(() => setBadgeBounce(false), 3000);
        return () => {
            cancelAnimationFrame(id);
            clearTimeout(t);
        };
    }, []);

    // fetch authentic profile from DB
    useEffect(() => {
        let active = true
        async function load() {
            try {
                const r = await fetch('/api/profile', { 
                  cache: 'default',
                  next: { revalidate: 300 } // Revalidate every 5 minutes
                })
                if (!r.ok) return
                const d = await r.json()
                if (active) setProfile({ id: d.id, name: d.name, email: d.email })
            } catch { }
        }
        if (status === 'authenticated') load()
        return () => { active = false }
    }, [status])

    // redirect unauthenticated to login
    useEffect(() => {
        if (status === 'unauthenticated') {
            try { window.location.href = '/login' } catch { }
        }
    }, [status])

    const displayName = (profile?.name || session?.user?.name || 'User').trim()
    const displayEmail = (profile?.email || session?.user?.email || '').trim()
    const initials = (() => {
        const src = displayName || displayEmail
        const parts = src.split(/\s+/).filter(Boolean)
        const first = parts[0]?.[0] || ''
        const last = parts[1]?.[0] || ''
        return (first + last || src[0] || 'U').toUpperCase()
    })()

    return (
        <nav className={`w-full bg-[linear-gradient(0deg,#f5f8fc,#f5f8fc)] shadow-[0_2px_15px_rgba(0,0,0,0.08)] border-b border-gray-200 transform transition-all duration-500 ${ready ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}>
           <div className="max-w-7xl mx-auto px-6 py-3 flex items-center gap-6">
                           
           
                           <a
                               className="flex items-center gap-3 text-2xl font-extrabold bg-clip-text text-transparent"
                               href="/dashboard"
                           >
                               <i className="fas fa-robot"></i>
                               <span className="ml-1">
                                   <Image
                                       src="/logo.jpg"
                                       alt="PayAtUpi Logo"
                                       width={160}
                                       height={160}
                                   />
                               </span>
                           </a>


                <div className="ml-auto flex items-center gap-3">
                    {/* User dropdown */}
                    <div ref={userRef} className="relative">
                        <button
                            onMouseDown={(e) => e.preventDefault()}
                            onClick={() => setOpenUser((s) => !s)}
                            aria-expanded={openUser}
                            aria-haspopup="true"
                            className="flex items-center gap-3 px-3 py-2 rounded-xl bg-white border-2 border-transparent hover:border-[#50bd49] transition-transform transform hover:-translate-y-0.5 shadow-sm"
                        >
                            <div className="w-10 h-10 rounded-full flex items-center justify-center font-semibold text-white" style={{ background: "linear-gradient(135deg,#50bd49,#3da336)" }}>
                                {initials}
                            </div>
                            <div className="hidden md:block text-left">
                                <div className="font-semibold text-sm text-[#2d3748]">{displayName}</div>
                                <div className="text-xs text-[#718096]">{displayEmail || '—'}</div>
                            </div>
                            <i className={`fas fa-chevron-down text-[#50bd49] ml-2 transition-transform duration-200 ${openUser ? 'rotate-180' : ''}`}></i>
                        </button>

                        {/* Dropdown panel */}
                        <div
                            className={`absolute right-0 mt-3 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 transition-opacity transform origin-top-right z-50 ${openUser ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"}`}
                            style={{ transitionDuration: "220ms" }}
                        >
                            <div className="p-4 border-b border-gray-100 flex items-start gap-3">
                                <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-white" style={{ background: "linear-gradient(135deg,#50bd49,#3da336)" }}>{initials}</div>
                                <div className="flex-1">
                                    <div className="font-bold text-sm text-[#2d3748]">{displayName}</div>
                                    <div className="text-xs text-[#718096]">{displayEmail || '—'}</div>
                                </div>
                                <div className="text-[#50bd49] p-2 rounded-md"><i className="fa-solid fa-gear"></i></div>
                            </div>

                            <div className="py-2">
                                <a href="/dashboard/profile" className="flex items-center gap-3 px-4 py-2 hover:bg-[#f0fdf4] text-sm text-[#2d3748]"><i className="fas fa-user w-5"></i>View Profile</a>
                                <a href="/dashboard/change-password" className="flex items-center gap-3 px-4 py-2 hover:bg-[#f0fdf4] text-sm text-[#2d3748]"><i className="fas fa-key w-5"></i>Change Password</a>
                                <a href="/dashboard/two-factor" className="flex items-center gap-3 px-4 py-2 hover:bg-[#f0fdf4] text-sm text-[#2d3748]"><i className="fas fa-shield-alt w-5"></i>2 Factor Authentication</a>
                                <a href="/dashboard/activity" className="flex items-center gap-3 px-4 py-2 hover:bg-[#f0fdf4] text-sm text-[#2d3748]"><i className="fas fa-history w-5"></i>Login Activity</a>
                                <div className="border-t border-gray-100 my-2"></div>
                                <button onClick={() => signOut({ callbackUrl: '/login' })} className="w-full text-left flex items-center gap-3 px-4 py-2 hover:bg-[#fff5f5] text-sm text-red-600">
                                    <i className="fas fa-sign-out-alt w-5"></i>Sign out
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Notification dropdown */}
                    {/* <div ref={notifRef} className="relative">
                        <button
                            onClick={() => setOpenNotif((s) => !s)}
                            className="relative p-3 rounded-xl bg-white border-2 border-transparent hover:border-[#50bd49]"
                        >
                            <i className="fas fa-bell" style={{ color: "#50bd49" }}></i>
                            <span className={`absolute -top-1 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white rounded-full ${badgeBounce ? 'animate-bounce' : ''}`} style={{ background: "#50bd49", border: "2px solid white" }}>3</span>
                        </button>

                        <div className={`absolute right-0 mt-3 w-[22rem] max-w-[26rem] bg-white rounded-2xl shadow-2xl border border-gray-100 z-50 ${openNotif ? "opacity-100 scale-100" : "opacity-0 scale-95 pointer-events-none"}`} style={{ transitionDuration: "220ms" }}>
                            <div className="p-4 bg-[linear-gradient(135deg,#f8fff8,#f0f8f0)] rounded-t-2xl sticky top-0">
                                <div className="flex items-center justify-between">
                                    <h6 className="font-bold text-sm text-[#2d3748]">Notifications</h6>
                                    <button className="text-sm px-3 py-1 rounded-full border border-[#50bd49] text-[#50bd49] font-semibold">Mark All as Read</button>
                                </div>
                            </div>

                            <div className="divide-y divide-gray-100 max-h-[20rem] overflow-y-auto">
                                <a href="#" className="flex gap-3 items-start p-4 hover:bg-[#f0fff0]">
                                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg,#25D366,#128C7E)", color: "white" }}>
                                        <i className="fab fa-whatsapp"></i>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold text-sm text-[#2d3748]">Join WhatsApp Channel</div>
                                        <div className="text-xs text-[#50bd49] break-all">https://whatsapp.com/channel/0029VbAVha4BVJl9zOrmc20i</div>
                                        <div className="text-xs text-[#718096] mt-1">3 months ago</div>
                                    </div>
                                </a>

                                <a href="#" className="flex gap-3 items-start p-4 hover:bg-[#f0fff0]">
                                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg,#FF6B6B,#FF8E53)", color: "white" }}>
                                        <i className="fas fa-tag"></i>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold text-sm text-[#2d3748]">Big sale 25% off on One year Subscription 19th and 20th nov</div>
                                        <div className="text-xs text-[#718096] mt-1">2 years ago</div>
                                    </div>
                                </a>

                                <a href="#" className="flex gap-3 items-start p-4 hover:bg-[#f0fff0]">
                                    <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg,#4ECDC4,#44A08D)", color: "white" }}>
                                        <i className="fas fa-sync-alt"></i>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="font-bold text-sm text-[#2d3748]">System Update Completed</div>
                                        <div className="text-xs text-[#718096] mt-1">1 year ago</div>
                                    </div>
                                </a>
                            </div>

                            <div className="p-4 text-center bg-[linear-gradient(90deg,#f8fff8,#f0f8f0)] rounded-b-2xl">
                                <a href="/account/notifications" className="font-semibold text-sm text-[#111827]">View All</a>
                            </div>
                        </div>
                    </div> */}

                </div>
            </div>
        </nav>
    );
};

export default Navbar;