import { prisma } from '@/lib/prisma'

export async function createActivity(userId: string, type: string, message?: string, metadata?: any) {
  try {
    await (prisma as any).activityLog.create({
      data: {
        userId,
        type: type as any,
        message,
        metadata: metadata ? (metadata as any) : undefined,
      },
    })
  } catch (err) {
    // best-effort logging; ignore
  }
}
