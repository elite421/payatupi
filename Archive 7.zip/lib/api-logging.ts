import { prisma } from '@/lib/prisma'

export async function logApiRequest(opts: {
  userId?: string | null
  apiKeyId?: string | null
  endpoint: string
  method: string
  code: number
  status: 'OK' | 'ERROR'
  reason?: string | null
  req: Request
  metadata?: any
}) {
  try {
    const ip = opts.req.headers.get('x-forwarded-for') || undefined
    const ua = opts.req.headers.get('user-agent') || undefined
    await (prisma as any).apiRequestLog.create({
      data: {
        userId: opts.userId || null,
        apiKeyId: opts.apiKeyId || null,
        endpoint: opts.endpoint,
        method: opts.method,
        code: opts.code,
        status: opts.status,
        reason: opts.reason || null,
        ip,
        ua,
        metadata: opts.metadata || undefined,
      }
    })
    if (opts.apiKeyId) {
      await prisma.apiKey.update({ where: { id: opts.apiKeyId }, data: { lastUsedAt: new Date() } })
    }
  } catch {
  }
}
