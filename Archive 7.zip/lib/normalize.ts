export function normalizeUtr(s: string): string {
  return String(s || '').replace(/[\s-]+/g, '').toUpperCase()
}
