import { prisma } from '@/lib/prisma'
import { normalizeUtr } from '@/lib/normalize'
import { createActivity } from '@/lib/activity'
import { createHmac } from 'crypto'

const ALLOWED: Array<'Pending' | 'Success' | 'Failed'> = ['Pending', 'Success', 'Failed']

function getAny(o: any, keys: string[]): any {
  if (!o || typeof o !== 'object') return undefined
  const map = new Map<string, any>()
  for (const k of Object.keys(o)) map.set(k.toLowerCase(), (o as any)[k])
  for (const key of keys) {
    const v = map.get(key.toLowerCase())
    if (v !== undefined) return v
  }
  return undefined
}

function extractAmountFromText(txt: string): number | undefined {
  const t = String(txt || '')
  const m = t.match(/(?:rs|inr|amount|amt)[^\d]{0,5}(\d+(?:\.\d{1,2})?)/i) || t.match(/\b(\d+(?:\.\d{1,2})?)\b\s*(?:rs|inr)\b/i)
  if (m) {
    const n = Number(String(m[1]).replace(/[\,\s]/g, ''))
    if (!Number.isNaN(n)) return Math.round(n)
  }
  return undefined
}

/**
 * Attempts to match a callback log with a transaction and update it if matched.
 * Returns true if matched and updated, false otherwise.
 */
export async function matchCallbackLogToTransaction(
  log: { id: string; userId: string | null; utr: string; status: string; amount: number | null; createdAt: Date }
): Promise<{ matched: boolean; txId?: string; reason?: string }> {
  if (!log.userId) {
    return { matched: false, reason: 'no_user_id' }
  }

  const utrIn = normalizeUtr(log.utr)
  const statusIn = log.status as 'Pending' | 'Success' | 'Failed'
  let amountIn = log.amount != null ? Math.round(log.amount) : null

  // Validate status
  if (!statusIn || !ALLOWED.includes(statusIn)) {
    return { matched: false, reason: 'invalid_status' }
  }

  // If amount is missing/suspiciously small, try to parse from raw.message/body stored in the log
  try {
    if (amountIn == null || Number.isNaN(amountIn) || amountIn <= 5) {
      const full = await prisma.smsCallbackLog.findUnique({ where: { id: log.id } }) as any
      const raw = full?.raw || null
      const msg = getAny(raw || {}, ['message','body','content','text','msg'])
      if (msg) {
        const parsed = extractAmountFromText(String(msg))
        if (typeof parsed === 'number' && Number.isFinite(parsed) && parsed > (amountIn || 0)) {
          amountIn = parsed
        }
      }
    }
  } catch {}

  // Try to find transaction by UTR first (most accurate)
  let tx = await prisma.transaction.findFirst({
    where: { userId: log.userId, utr: utrIn },
    orderBy: { createdAt: 'desc' },
  })

  // If not found by UTR, try matching by amount within a reasonable time window
  if (!tx && amountIn != null && amountIn > 0) {
    // Look for pending transactions with matching amount within last 72 hours
    const since = new Date(log.createdAt.getTime() - 72 * 60 * 60 * 1000)
    const candidates = await prisma.transaction.findMany({
      where: {
        userId: log.userId,
        status: 'Pending',
        amount: amountIn,
        OR: [{ utr: null }, { utr: '' }],
        createdAt: { gte: since },
      },
      orderBy: { createdAt: 'desc' },
      take: 5, // Get more candidates for better matching
    })

    // If exactly one candidate, use it
    if (candidates.length === 1) {
      tx = await prisma.transaction.findUnique({ where: { id: candidates[0].id } })
      if (tx && (!tx.utr || tx.utr === '')) {
        // Attach UTR for future idempotency
        await prisma.transaction.update({ where: { id: tx.id }, data: { utr: utrIn } })
      }
    } else if (candidates.length > 1) {
      // Multiple candidates - try to match by time proximity (within 1 hour)
      const logTime = log.createdAt.getTime()
      let bestMatch: { tx: any; diff: number } | null = null
      
      for (const candidate of candidates) {
        const txTime = candidate.createdAt.getTime()
        const diff = Math.abs(logTime - txTime)
        // Prefer transactions created within 6 hours of callback
        if (diff <= 6 * 60 * 60 * 1000) {
          if (!bestMatch || diff < bestMatch.diff) {
            bestMatch = { tx: candidate, diff }
          }
        }
      }

      if (bestMatch) {
        tx = await prisma.transaction.findUnique({ where: { id: bestMatch.tx.id } })
        if (tx && (!tx.utr || tx.utr === '')) {
          await prisma.transaction.update({ where: { id: tx.id }, data: { utr: utrIn } })
        }
      }
    }
  }

  if (!tx) {
    return { matched: false, reason: 'no_matching_transaction' }
  }

  // Verify amount matches if not matched by UTR
  const matchedByUtr = !!(tx.utr && normalizeUtr(tx.utr) === utrIn)
  if (!matchedByUtr && amountIn != null && amountIn > 0) {
    if (Math.abs((tx.amount || 0) - amountIn) > 0) {
      return { matched: false, reason: 'amount_mismatch' }
    }
  }

  // If already in the requested status, just update statusSource if needed
  if (tx.status === statusIn) {
    if (tx.statusSource !== 'SMS') {
      await prisma.transaction.update({ where: { id: tx.id }, data: { statusSource: 'SMS' } })
    }
    return { matched: true, txId: tx.id }
  }

  // Check if SMS automation is enabled
  const cs = await prisma.checkoutSettings.findUnique({ where: { userId: log.userId } }).catch(() => null) as any
  if (!(cs && cs.smsAutomation)) {
    return { matched: false, reason: 'automation_disabled' }
  }

  // Update transaction status
  try {
    // Charge automation fee and handle wallet operations in a single transaction
    let updated: any = null
    try {
      updated = await prisma.$transaction(async (db) => {
        // Get or create wallet
        let wallet = await (db as any).wallet.findUnique({ where: { userId: log.userId! } })
        if (!wallet) {
          wallet = await (db as any).wallet.create({ data: { userId: log.userId!, balance: 0 } })
        }

        // Charge automation fee (1 rupee) if not already charged
        if (!(tx as any).automationFeeCharged) {
          // Check if wallet has sufficient balance (for non-topup transactions)
          const isWalletTopup = String(tx.mode || '').toUpperCase() === 'WALLET_TOPUP'
          if (!isWalletTopup && wallet.balance < 1) {
            throw new Error('INSUFFICIENT_WALLET')
          }
          
          // Deduct automation fee
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { decrement: 1 } } })
          await (db as any).walletEntry.create({ 
            data: { walletId: wallet.id, type: 'DEBIT', amount: 1, reason: `Automation fee for ${tx.id}`, txId: tx.id } 
          })
        }

        // Update transaction status
        const u = await (db as any).transaction.update({ 
          where: { id: tx.id }, 
          data: { status: statusIn, statusSource: 'SMS', automationFeeCharged: true } 
        })

        // Handle wallet top-up auto-credit (after fee deduction)
        if (statusIn === 'Success' && String(u.mode || '').toUpperCase() === 'WALLET_TOPUP' && !(u as any).walletCredited) {
          // Credit the full transaction amount to wallet
          await (db as any).wallet.update({ where: { id: wallet.id }, data: { balance: { increment: u.amount } } })
          await (db as any).walletEntry.create({ 
            data: { walletId: wallet.id, type: 'CREDIT', amount: u.amount, reason: `Wallet top-up via ${u.id}`, txId: u.id } 
          })
          await (db as any).transaction.update({ where: { id: u.id }, data: { walletCredited: true } })
        }

        return u
      })
    } catch (e: any) {
      if (e && typeof e.message === 'string' && e.message === 'INSUFFICIENT_WALLET') {
        return { matched: false, reason: 'insufficient_wallet' }
      }
      throw e
    }

    // Handle subscription activation
    try {
      if (statusIn === 'Success' && String(updated.mode).toUpperCase() === 'SUBSCRIPTION') {
        const allowed = ['INDIVIDUAL','ENTERPRISE','INDIVIDUAL_PLUS','ENTERPRISE_PLUS'] as const
        const m = String(updated.purpose || '').match(/Subscription\s+([A-Z_]+)/i)
        const planIn = (m?.[1] || '').toUpperCase()
        if ((allowed as readonly string[]).includes(planIn)) {
          const now = new Date()
          let periodEnd: Date | null = null
          if (planIn === 'INDIVIDUAL' || planIn === 'ENTERPRISE') {
            periodEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)
          } else if (planIn === 'INDIVIDUAL_PLUS' || planIn === 'ENTERPRISE_PLUS') {
            periodEnd = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
          }
          await prisma.subscription.upsert({
            where: { userId: updated.userId },
            update: { plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
            create: { userId: updated.userId, plan: planIn as any, status: 'ACTIVE', currentPeriodEnd: periodEnd },
          })
          await createActivity(updated.userId, 'SUBSCRIPTION_CHANGED', 'Subscription activated from SMS callback', { plan: planIn, periodEnd })
        }
      }
    } catch {}

    // Fire webhooks
    try {
      const hooks = await prisma.webhook.findMany({ where: { userId: updated.userId } })
      if (hooks.length > 0) {
        const payload = {
          event: 'transaction.updated',
          data: {
            id: updated.id,
            status: statusIn,
            purpose: updated.purpose,
            amount: updated.amount,
            mode: updated.mode,
            utr: updated.utr,
            createdAt: updated.createdAt,
          },
          userId: updated.userId,
        }
        const body = JSON.stringify(payload)
        for (const h of hooks as any[]) {
          const headers: Record<string,string> = { 'Content-Type': 'application/json', 'X-Payatupi-Event': 'transaction.updated' }
          if (h.secret) {
            const sig = createHmac('sha256', h.secret).update(body).digest('hex')
            headers['X-Payatupi-Signature'] = sig
          }
          const controller = new AbortController()
          const to = setTimeout(() => controller.abort(), 5000)
          try {
            await fetch(h.url, { method: 'POST', headers, body, redirect: 'manual' as any, signal: controller.signal })
          } catch {}
          finally {
            clearTimeout(to)
          }
        }
      }
    } catch {}

    await createActivity(updated.userId, 'PAYMENT_CONFIRMED', 'Payment marked via SMS callback', { txId: updated.id, utr: utrIn, status: statusIn })

    return { matched: true, txId: updated.id }
  } catch (error) {
    console.error('Error matching callback log to transaction:', error)
    return { matched: false, reason: 'update_failed' }
  }
}

