import { prisma } from '@/lib/prisma'

export async function isKycApproved(userId: string): Promise<boolean> {
  try {
    const kyc = await (prisma as any).kycSubmission.findUnique({ where: { userId } })
    return !!(kyc && kyc.status === 'APPROVED')
  } catch {
    return false
  }
}
